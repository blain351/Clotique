class ApiEndPoint {
  //static const String baseUrl = 'https://6807e560cdb4.ngrok-free.app/api'; /// borshon vai endpoint
  static const String baseUrl = 'https://21e94bbc17fe.ngrok-free.app'; /// touhid vai endpoint
  static const String feedImageBaseUrl = 'https://541024ef53a4.ngrok-free.app';
  static const String baseUrl2 = 'https://541024ef53a4.ngrok-free.app';
  static const String socketUrl = 'wss://0ab1ee0cbf64.ngrok-free.app';
  static const String aiImageBaseUrl = 'http://192.168.4.58:3000/public';


  /// auth
  static const String login = '$baseUrl/api/auth/login';
  static const String loginWith2faOtp = '$baseUrl/api/auth/twofactor';
  static const String register = '$baseUrl/api/auth/register';
  static const String checkMe = '$baseUrl/api/auth/me';
  static const String updateUser = '$baseUrl/api/auth/update';
  static const String forgotPassword = '$baseUrl/api/auth/forgot-password';
  static const String enable2faOtpVerify = '$baseUrl/api/auth/2fa/verify';
  static const String enable2faOtpRequest = '$baseUrl/api/auth/2fa/request';
  static String feed(int page, int limit) =>
      '$baseUrl/api/social-media/usersfeed?limit=$limit&page=$page';
  static String likePost(String postId) =>
      '$baseUrl/api/social-media/likepost/$postId';
  static String getLikePost(String postId) =>
      '$baseUrl/api/social-media/likepost/$postId';
  static String createComment(String postId) =>
      '$baseUrl/api/social-media/comment/$postId';
  static String getAllCommentsById(String postId) =>
      '$baseUrl/api/social-media/post/$postId';
  static String postShareById(String postId) =>
      '$baseUrl/api/social-media/sharepost/$postId';
  static const String getUserAllPost =
      '$baseUrl/api/social-media/getposts';
  static String deleteUserPostByPostId(String postId) =>
      '$baseUrl/api/social-media/deletepost/$postId';
  static String editUserPostByPostId(String postId) =>
      '$baseUrl/api/social-media/updatepost/$postId';

  static const String otpVerifyAndResetPassword =
      '$baseUrl/api/auth/reset-password';

  /// home
  static String dailyWeatherByPlaceName(String place) =>
      '$baseUrl/api/aigenerateimage/daily-weather/$place';

  static String makeEventPostFavorite(String postId) =>
      '$baseUrl/api/aigenerateimage/dailyevent/favrouite/$postId';
  static String makeSmartPostFavorite(String postId) =>
      '$baseUrl/api/aigenerateimage/smartlook/favrouite/$postId';

  //wardrobe
  static const String insertCloth = '$baseUrl/api/wardrobe/createitem';
  static const String getAllWardrobe = '$baseUrl/api/wardrobe/items';

  static String getAllFavouriteOutfit(int page, int limit) =>
      '$baseUrl/api/home/fav-all-outfit?page=$page&pageSize=$limit';
  static String deleteOneFavouriteOutfitById(String outfitId) =>
      '$baseUrl/api/home/fav-outfit-delete/$outfitId';

  static const String dailyEventOutfit =
      '$baseUrl/api/aigenerateimage/bydate/random-outfits/event';
  static const String dailySmartOutfit =
      '$baseUrl/api/aigenerateimage/bydate/random-outfits';

  // social media
  static const String createPost = '$baseUrl/api/social-media/createpost';
  static const String notificationUrl = '$baseUrl/api/social-media/notifications';

  // friends suggestions
  static const String suggestion = '$baseUrl/api/friendships/suggestion-friends';
  static const String search = '$baseUrl/api/search';
  static String requests(String postId) =>
      '$baseUrl/api/friendships/request/$postId';
  static const String pendings = '$baseUrl/api/friendships/pending';
  static const String pendingRequests = '$baseUrl/api/friendships/pending';
  static String accept(String postId) => '$baseUrl/api/friendships/respond/$postId';
  static const String all = '$baseUrl/api/friendships/friends';
  static const String blocklist = '$baseUrl/api/blocks';
  static String unblock(String postId) => '$baseUrl/api/blocks/$postId';
  static String oneUserDetails(String postId) =>
      '$baseUrl/api/friendships/user-profile/$postId';
  static String reject(String postId) => '$baseUrl/api/friendships/respond/$postId';
  static String block(String postId) => '$baseUrl/api/blocks/$postId';

  static String requester(String postId) =>'$baseUrl/friendships/pending/$postId';




  //payment
  static const String paymentMonthly =
      'https://541024ef53a4.ngrok-free.app/api/subscription/create/stripe/monthly';
  static const String paymentYearly =
      'https://541024ef53a4.ngrok-free.app/api/subscription/create/stripe/yearly';

  // Ai Generate Image
  static String aiGenerateImage = '$baseUrl/api/aigenerateimage/aigenerate';
  static String saveAiGenerateImage(String postId) => '$baseUrl/api/aigenerateimage/save-outfit/$postId';

}

