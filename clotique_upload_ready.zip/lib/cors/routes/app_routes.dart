import 'package:clotique/cors/routes/routes_name.dart';
import 'package:clotique/views/ai_generator/screen/ai_generator_screen.dart';
import 'package:clotique/views/all_outfit/screens/all_outfit_screen.dart';
import 'package:clotique/views/auth/2fa_verify_otp/verify_2fa_otp_screen.dart';
import 'package:clotique/views/feed/screen/feed_screen.dart';
import 'package:clotique/views/feed/screens/comment/comment_screen.dart';
import 'package:clotique/views/feed/screens/profile/screen/profile_screen.dart';
import 'package:clotique/views/feed/screens/profile/screens/edit_profile_screen.dart';
import 'package:clotique/views/feed/screens/profile/screens/update_post_screen.dart';
import 'package:clotique/views/notification/screen/notification_screen.dart';
import 'package:clotique/views/search/screen/search_screen.dart';
import 'package:clotique/views/settings/screen/account_settings/screen/account_settings_screen.dart';
import 'package:clotique/views/settings/subscription_screen/subscription_screen.dart';
import 'package:flutter/material.dart';
import '../../views/auth/forgot_password/for_got_password.dart';
import '../../views/auth/login/login_screen.dart';
import '../../views/auth/login_or_signup/login_or_signup.dart';
import '../../views/auth/otp_screen/otp_screen.dart';
import '../../views/auth/set_password/set_password.dart';
import '../../views/auth/signup/sign_up_screen.dart';
import '../../views/feed/screens/all_friends_profile/all_friends.dart';
import '../../views/feed/screens/comapre_outfit/screen/compare_outfit_screen.dart';
import '../../views/feed/screens/create_post/screen/create_post.dart';
import '../../views/feed/screens/friend_profile/screen/friends_profile_screen.dart';
import '../../views/feed/screens/friends/screen/friends_screen.dart';
import '../../views/feed/screens/friends/tab/all_friends_tab.dart';
import '../../views/feed/screens/friends/tab/blocked_users_tab.dart';
import '../../views/feed/screens/report/report_intellectual.dart';
import '../../views/feed/screens/report/report_user_page.dart';
import '../../views/feed/screens/friends/tab/blocked_users_tab.dart';
import '../../views/feed/screens/report/report_intellectual.dart';
import '../../views/feed/screens/report/report_user_page.dart';
import '../../views/home/screen/home_screen.dart';
import '../../views/onboarding/onboarding_screen.dart';
import '../../views/parent_screen/screen/parent_screen.dart';
import '../../views/settings/payment_screen/payment_screen.dart';
import '../../views/splash/screen/splash_screen.dart';

class AppRoutes {
  static Map<String, WidgetBuilder> routes = {
    '/': (context) => SplashScreen(),
    RouteName.homeScreen: (context) => const HomeScreen(),
    RouteName.parentScreen: (context) => const ParentScreen(),
    RouteName.onboardingScreen: (context) => const OnboardingScreen(),
    RouteName.loginOrSignup: (context) => const LoginOrSignup(),
    RouteName.signUpScreen: (context) => const SignUpScreen(),
    RouteName.loginScreen: (context) => const LoginScreen(),
    RouteName.forgotPassword: (context) => const ForgotPassword(),
    RouteName.confirmOtpScreen: (context) => ConfirmOtpScreen(),
    RouteName.verify2faOtpScreen: (context) => Verify2faOtpScreen(),
    RouteName.setPassword: (context) => const SetPassword(),

    RouteName.createPostScreen: (context) => const CreatePostScreen(),
    RouteName.compareOutfitScreen: (context) => const CompareOutfitScreen(),
    RouteName.friendsScreen: (context) => const FriendsScreen(),
    RouteName.friendsProfileScreen: (context) => const FriendsProfileScreen(),

    RouteName.aiGenerator: (context) => const AiGeneratorScreen(),
    RouteName.accountSettingsScreen: (context) => const AccountSettingsScreen(),
    RouteName.allOutfitScreen: (context) => const AllOutfitScreen(),
    RouteName.notificationScreen: (context) => const NotificationScreen(),
    RouteName.commentScreen: (context) => const CommentScreen(),
    RouteName.searchScreen: (context) => const SearchScreen(),
    RouteName.feedScreen: (context) => const FeedScreen(),
    RouteName.profileScreen: (context) => const ProfileScreen(),
    RouteName.editProfileScreen: (context) => EditProfileScreen(),
    RouteName.editPostScreen: (context) => UpdatePostScreen(),

    RouteName.reportUserPage: (context) => ReportUserPage(),
    RouteName.reportUserDetailPage: (context) => ReportUserDetailPage(),
    RouteName.friendsScreen: (context) => FriendsScreen(),
    RouteName.blockedUsersTab: (context) => BlockedUsersTab(),

    RouteName.paymentScreen: (context) => PaymentScreen(),
    RouteName.subscriptionScreen: (context) => SubscriptionScreen(),
    RouteName.reportUserPage: (context) => ReportUserPage(),
    RouteName.reportUserDetailPage: (context) => ReportUserDetailPage(),
    RouteName.friendsScreen: (context) => FriendsScreen(),
    RouteName.blockedUsersTab: (context) => BlockedUsersTab(),
    RouteName.allFriends: (context) => AllFriends(),
    RouteName.friendsProfileScreen: (context) => FriendsProfileScreen(),



  };
}