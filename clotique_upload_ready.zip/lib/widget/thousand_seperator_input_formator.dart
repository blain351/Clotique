// import 'package:flutter/services.dart';
// import 'package:intl/intl.dart';
//
// class ThousandSeparatorInputFormatter extends TextInputFormatter {
//   final NumberFormat _formatter = NumberFormat.decimalPattern();
//
//   @override
//   TextEditingValue formatEditUpdate(
//       TextEditingValue oldValue, TextEditingValue newValue) {
//     String newText = newValue.text.replaceAll(',', '');
//
//     if (newText.isEmpty) {
//       return newValue.copyWith(text: '');
//     }
//
//     int? number = int.tryParse(newText);
//     if (number == null) return oldValue;
//
//     String newString = _formatter.format(number);
//
//     return TextEditingValue(
//       text: newString,
//       selection: TextSelection.collapsed(offset: newString.length),
//     );
//   }
// }
