import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrimaryOutlineButton extends StatelessWidget {
  final String text;
  final Color? borderColor;
  final Color? textColor;
  final VoidCallback? onPressed;
  const PrimaryOutlineButton({
    super.key,
    required this.text,
    this.borderColor = const Color(0xff0069C0),
    this.textColor = Colors.black,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        padding: EdgeInsets.symmetric(vertical: 16.h),
        side: BorderSide(width: 2,color: const Color(0xff9C7DF5)),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16), // Set the border radius here
        ),
      ),
      onPressed: onPressed ?? () {},
      child: Text(
        text,
        style: TextStyle(color: textColor ?? Colors.black),
      ),
    );
  }
}
