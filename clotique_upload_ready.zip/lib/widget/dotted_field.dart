import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';

class DottedBorderExample extends StatelessWidget {
  const DottedBorderExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dotted Border Example')),
      body: Center(
        child: DottedBorder(
          borderType: BorderType.RRect, // Use rounded rectangle border
          radius: Radius.circular(8), // Match the design's rounded corners
          padding: const EdgeInsets.all(8),
          color: Colors.purple,
          strokeWidth: 2,
          dashPattern: const [10, 5], // Dash length, gap length
          child: Container(
            width: 300, // Adjustable width
            height: 200, // Adjustable height
            padding: const EdgeInsets.all(16),
            alignment: Alignment.center,
            child: const Text(
              'Upload Image',
              style: TextStyle(
                color: Colors.purple,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }
}