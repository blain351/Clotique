import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ToggleInputField extends StatelessWidget {
  final String? textIcon;
  final TextEditingController? controller;
  final List<TextInputFormatter>? inputFormatters;

  const ToggleInputField({
    super.key,
    this.textIcon,
    this.controller,
    this.inputFormatters,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(right: 7),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.blue.shade100),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              controller: controller,
              inputFormatters: inputFormatters,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                contentPadding: EdgeInsets.symmetric(horizontal: 16),
                border: InputBorder.none,
                hintText: '',
              ),
            ),
          ),
          Text(
            textIcon ?? '',
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.w800,
              color: const Color(0xff1D1F2C),
            ),
          ),
          SizedBox(width: 8.w),
          Image.asset("assets/icons/refresh.png"),
        ],
      ),
    );
  }
}
