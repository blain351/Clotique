import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class PincodeTextField extends StatelessWidget {
  final void Function(String)? onChanged;
  final TextEditingController otpController;

  const PincodeTextField({super.key, this.onChanged, required this.otpController});

  @override
  Widget build(BuildContext context) {

    const borderColor = Color(0xffE9E9EA);

    return PinCodeTextField(
      appContext: context,
      length: 6,
      controller: otpController,
      obscureText: false,
      animationDuration: const Duration(milliseconds: 200),
      backgroundColor: Colors.transparent,
      enableActiveFill: true,
      onChanged: onChanged ?? (_) {},

      pinTheme: PinTheme(
        shape: PinCodeFieldShape.box,
        borderRadius: BorderRadius.circular(8.r),
        fieldHeight: 48.h,
        fieldWidth: 40.w,
        activeBorderWidth: 1,
        selectedBorderWidth: 1.4,
        inactiveBorderWidth: 1,
        activeColor: Colors.grey,
        inactiveColor: borderColor,
        selectedColor: Colors.grey,
        activeFillColor: Colors.white,
        selectedFillColor: Colors.white,
        inactiveFillColor: Colors.white,
      ),

      textStyle: TextStyle(
        color: Colors.deepPurple,
        fontSize: 18.sp,
        fontWeight: FontWeight.w600,
      ),
    );
  }
}
