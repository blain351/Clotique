import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomHeader extends StatelessWidget {
  final VoidCallback onPressed;
  final String title;

  const CustomHeader({super.key, required this.onPressed, required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      height:132.h ,
      padding: EdgeInsets.only(
        top: 50.h,
        left: 20.w,
        right: 20.w,
        bottom: 20.h,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(24.r),
          bottomRight: Radius.circular(24.r),
        ),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Center(
            child: Text(
              title,
              style: TextStyle(
                fontSize: 20.sp,
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          Align(
            alignment: Alignment.centerLeft,
            child: GestureDetector(

              onTap: onPressed,

              child: Container(
                padding: EdgeInsets.all(6),
                decoration: BoxDecoration(color: Colors.white,shape: BoxShape.circle),
                child: Icon(Icons.arrow_back_ios_new, color: Colors.black),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
