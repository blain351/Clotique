// import 'package:finance_calculator/presentaion/widget/custom_header.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
//
// class MonthlyEMI {
//   final String monthNum;
//   final String month;
//   final double principalPercent;
//   final double interestPercent;
//   final double emi;
//   final double balance;
//
//   MonthlyEMI({
//     required this.monthNum,
//     required this.month,
//     required this.principalPercent,
//     required this.interestPercent,
//     required this.emi,
//     required this.balance,
//   });
// }
//
// class EMIHistoryTable extends StatelessWidget {
//   EMIHistoryTable({super.key});
//
//   final List<MonthlyEMI> data = [
//     MonthlyEMI(
//       monthNum: '#1',
//       month: 'May 2025',
//       principalPercent: 0.80,
//       interestPercent: 1.25,
//       emi: 2.38,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#2',
//       month: 'Jun 2025',
//       principalPercent: 0.80,
//       interestPercent: 1.55,
//       emi: 2.86,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#3',
//       month: 'Jul 2025',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#4',
//       month: 'Aug 2025',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#5',
//       month: 'Sep 2025',
//       principalPercent: 0.80,
//       interestPercent: 19.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#6',
//       month: 'Oct 2025',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#7',
//       month: 'Nov 2025',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#8',
//       month: 'Dec 2025',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#9',
//       month: 'Jan 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#10',
//       month: 'Feb 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#11',
//       month: 'Mar 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#12',
//       month: 'Apr 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#13',
//       month: 'May 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#14',
//       month: 'Jun 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#15',
//       month: 'Jul 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#16',
//       month: 'Aug 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#17',
//       month: 'Sep 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#18',
//       month: 'Oct 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//     MonthlyEMI(
//       monthNum: '#19',
//       month: 'Nov 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 2.65,
//       balance: 554.20,
//     ),
//     MonthlyEMI(
//       monthNum: '#20',
//       month: 'Dec 2026',
//       principalPercent: 0.80,
//       interestPercent: 1.85,
//       emi: 1.85,
//       balance: 69.82,
//     ),
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             CustomHeader(
//               onPressed: () {
//                 Navigator.pop(context);
//               },
//               title: "Amortization Table",
//             ),
//             Padding(
//               padding:  EdgeInsets.symmetric(horizontal: 16.w),
//               child: Transform.translate(
//                 offset: Offset(0, -13),
//                 child: ListView(
//                   shrinkWrap: true,
//                   physics: NeverScrollableScrollPhysics(),
//                   children: [
//                     ClipRRect(
//                       borderRadius: BorderRadius.circular(10), // Rounded corners
//                       child: DataTable(
//                         // Add outline border to the table
//                         border: const TableBorder(
//                           top: BorderSide(width: 1, color: Colors.grey),
//                           bottom: BorderSide(width: 1, color: Colors.grey),
//                           left: BorderSide(width: 1, color: Colors.grey),
//                           right: BorderSide(width: 1, color: Colors.grey),
//                         ),
//                         dividerThickness: 0,
//                         columnSpacing: 10,
//                         headingRowColor: MaterialStateProperty.all(Color(0xff0069C0)),
//                         headingTextStyle: const TextStyle(color: Colors.white),
//                         columns: const [
//                           DataColumn(label: Text("#Month \nDate")),
//                           DataColumn(label: Text("Principal\n P%")),
//                           DataColumn(label: Text("Interest\n I%")),
//                           DataColumn(label: Text("(P+I)\n EMI")),
//                           DataColumn(label: Text("Balance")),
//                         ],
//                         rows: List.generate(data.length, (index) {
//                           final item = data[index];
//                           Color rowColor =
//                           (index % 2 == 0)
//                               ? Colors.white
//                               : const Color(0xFFF0F8FF); // Light blue for odd rows
//
//                           return DataRow(
//                             color: MaterialStateProperty.all(rowColor),
//                             cells: [
//                               DataCell(
//                                 Flexible(
//                                   child: Text(
//                                     '${item.monthNum}\n${item.month}',
//                                     softWrap: true,
//                                   ),
//                                 ),
//                               ),
//                               DataCell(Text(item.principalPercent.toString())),
//                               DataCell(Text(item.interestPercent.toString())),
//                               DataCell(Text(item.emi.toString())),
//                               DataCell(Text(item.balance.toString())),
//                             ],
//                           );
//                         }),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
