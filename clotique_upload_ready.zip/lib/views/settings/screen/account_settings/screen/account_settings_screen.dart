import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../widgets/account_settings_top_bar.dart';
import '../widgets/danger_zone_settings_section.dart';
import '../widgets/private_account_settings_item.dart';
import '../widgets/security_settings_section.dart';

class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAF9F6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            AccountSettingsTopBar(),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
              child: Align(
                alignment: Alignment.centerLeft,  // Aligns the text to the left
                child: Text(
                  "General",
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade600,
                  ),
                ),
              ),
            ),
            PrivateAccountSettingsItem(),

            SizedBox(height: 16,),

            SecuritySettingsSection(),

            SizedBox(height: 16,),

            DangerZoneSettingsSection(),

          ],
        ),
      ),
    );
  }
}
