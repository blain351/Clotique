import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pin_code_fields/pin_code_fields.dart'; // You'll need this package for the OTP fields

// Add this to your pubspec.yaml under dependencies:
// pin_code_fields: ^8.0.1 (or the latest version)

void showVerifyCodeDialog(BuildContext context) {
  TextEditingController textEditingController = TextEditingController();
  // String currentText = ""; // You can use this to store the entered code if needed

  showDialog(
    context: context,
    builder: (BuildContext dialogContext) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.r),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.all(20.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Verify Code', // As per the image
                    style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: () {
                      Navigator.of(dialogContext).pop();
                    },
                  ),
                ],
              ),
              SizedBox(height: 30.h), // Increased spacing for better look
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.w), // Adjust padding as needed
                child: PinCodeTextField(
                  appContext: dialogContext,
                  length: 4, // 4 digits as per the image
                  obscureText: false,
                  animationType: AnimationType.fade,
                  pinTheme: PinTheme(
                    shape: PinCodeFieldShape.box,
                    borderRadius: BorderRadius.circular(10.r),
                    fieldHeight: 60.w, // Adjust size as needed
                    fieldWidth: 60.w,  // Adjust size as needed
                    activeFillColor: Colors.white,
                    inactiveFillColor: Colors.white,
                    selectedFillColor: Colors.white,
                    activeColor: const Color(0xFF6359FF), // Border color when active
                    inactiveColor: Colors.grey.shade300, // Border color when inactive
                    selectedColor: const Color(0xFF6359FF), // Border color when selected
                  ),
                  cursorColor: Colors.black,
                  animationDuration: const Duration(milliseconds: 300),
                  textStyle: TextStyle(fontSize: 20.sp, height: 1.6),
                  backgroundColor: Colors.transparent,
                  enableActiveFill: true,
                  controller: textEditingController,
                  onCompleted: (v) {
                    print("Completed: $v");
                    // You can add auto-verification logic here if the code is 4 digits
                  },
                  onChanged: (value) {
                    print(value);
                    // currentText = value;
                  },
                  beforeTextPaste: (text) {
                    print("Allowing to paste $text");
                    return true;
                  },
                ),
              ),
              SizedBox(height: 20.h),
              Align(
                alignment: Alignment.centerLeft,
                child: Text.rich(
                  TextSpan(
                    text: 'Resend: ',
                    style: TextStyle(
                      fontSize: 16.sp,
                      color: Colors.black87,
                    ),
                    children: [
                      TextSpan(
                        text: '59s', // This would typically be dynamic with a timer
                        style: TextStyle(
                          fontSize: 16.sp,
                          color: const Color(0xFF6359FF),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 24.h),
              Container(
                width: double.infinity,
                height: 50.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.r),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6359FF), Color(0xFF5A4BFF)], // Gradient from the image
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
                child: MaterialButton(
                  onPressed: () {
                    // Handle Verify button press (e.g., send OTP to server)
                    print('Verify button tapped with code: ${textEditingController.text}');
                    Navigator.of(dialogContext).pop(); // Close this dialog
                    // You might then navigate to a success screen or further steps
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  padding: EdgeInsets.zero,
                  child: Text(
                    'Verify',
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}