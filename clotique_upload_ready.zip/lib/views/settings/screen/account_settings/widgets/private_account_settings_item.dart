import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class PrivateAccountSettingsItem extends StatefulWidget {
  const PrivateAccountSettingsItem({super.key});

  @override
  State<PrivateAccountSettingsItem> createState() => _PrivateAccountSettingsItemState();
}

class _PrivateAccountSettingsItemState extends State<PrivateAccountSettingsItem> {
  bool _isPrivateAccount = false; // State for the toggle switch

  @override
  Widget build(BuildContext context) {

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.w), // Match the horizontal padding from the full list
      child: Container(
        padding: EdgeInsets.fromLTRB(20.w, 16.h, 10.w, 16.h), // Consistent padding inside the card
        decoration: BoxDecoration(
          color: Colors.white, // White background as per image
          borderRadius: BorderRadius.circular(16.r), // Rounded corners as per image
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.05),
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, 5), // Subtle shadow
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8.w),
              decoration: BoxDecoration(
                color: Colors.grey.shade100, // Light grey background for icon
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.person_outline, // Person with shield icon
                color: Colors.grey.shade700, // Darker grey icon color
                size: 24.sp,
              ),
            ),
            SizedBox(width: 16.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Private Account', // Title text
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87, // Dark text color
                    ),
                  ),
                  SizedBox(height: 4.h), // Adds space between the title and subtitle
                  Text(
                    'Your posts will only be visible to followers.', // Subtitle text
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.grey.shade500, // Lighter grey for subtitle
                    ),
                  ),
                ],
              ),
            ),
            Transform.scale(
              scale: 0.8, // Adjust scale to make the switch smaller
              child: Switch(
                value: _isPrivateAccount, // Current state of the switch
                onChanged: (bool newValue) {
                  setState(() {
                    _isPrivateAccount = newValue; // Update the state on toggle
                  });
                  print('Private Account toggled to: $newValue');
                },
                activeColor: const Color(0xFF5A4BFF), // Active color from previous UI (purple)
                activeTrackColor: const Color(0xFF5A4BFF).withOpacity(0.5), // Lighter track for active
                inactiveThumbColor: Colors.white, // White thumb for inactive
                inactiveTrackColor: Colors.grey.shade300, // Grey track for inactive
              ),
            ),
          ],
        ),
      ),
    );
  }
}
