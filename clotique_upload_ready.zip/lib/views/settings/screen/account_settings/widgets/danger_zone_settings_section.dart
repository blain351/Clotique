import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class DangerZoneSettingsSection extends StatelessWidget {
  const DangerZoneSettingsSection({super.key});

  @override
  Widget build(BuildContext context) {

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section Header
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.w),
          child: Text(
            'Danger Zone',
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade600,
            ),
          ),
        ),
        SizedBox(height: 12.h),

        // Disable Account Item
        _buildNavigationSettingsItem(
          context,
          icon: Icons.person_off_outlined, // Icon for disable
          title: 'Disable Account',
          isDanger: true, // Apply danger styling
          onTap: () {
            print('Disable Account tapped');
            // Show confirmation dialog for disable
          },
        ),
        SizedBox(height: 12.h),

        // Delete Account Item
        _buildNavigationSettingsItem(
          context,
          icon: Icons.delete_outline, // Trash can icon
          title: 'Delete Account',
          isDanger: true, // Apply danger styling
          onTap: () {
            print('Delete Account tapped');
            // Show confirmation dialog for delete
          },
        ),
      ],
    );
  }

  // Helper method for settings items that navigate (copied and slightly adapted from previous responses)
  Widget _buildNavigationSettingsItem(
      BuildContext context, {
        required IconData icon,
        required String title,
        required VoidCallback onTap,
        bool isDanger = false, // For danger zone styling
      }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 16.w),
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16.r),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.05),
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8.w),
              decoration: BoxDecoration(
                color: isDanger ? const Color(0xFFFD3D54).withOpacity(0.1) : Colors.grey.shade100, // Red background for danger icons
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: isDanger ? const Color(0xFFFD3D54) : Colors.grey.shade700, // Red icon for danger
                size: 24.sp,
              ),
            ),
            SizedBox(width: 16.w),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w500,
                  color: isDanger ? const Color(0xFFFD3D54) : Colors.black87, // Red text for danger
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            // The danger zone items do not have an arrow icon in the screenshot, so it's omitted.
          ],
        ),
      ),
    );
  }
}