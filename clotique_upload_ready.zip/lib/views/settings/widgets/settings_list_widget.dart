import 'package:clotique/cors/routes/routes_name.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../view_model/auth/login_logout_provider/login_logout_provider.dart';

class SettingsListWidget extends StatelessWidget {
  const SettingsListWidget({super.key});

  @override
  Widget build(BuildContext context) {

    return Container(
      color: const Color(0xFFFBF8F6), // Background color from the screenshot
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 24.h),
      child: Column(
        children: [
          _buildSettingsItem(
            context,
            icon: Icons.settings_outlined,
            title: 'Account Settings',
            onTap: () {
              Navigator.pushNamed(context, RouteName.accountSettingsScreen);
              print('Account Settings tapped');
              // Navigate to Account Settings screen
            },
          ),
          SizedBox(height: 12.h),
          _buildSettingsItem(
            context,
            icon: Icons.credit_card_outlined, // Icon resembling subscription/payment
            title: 'Subscription & Payment',
            onTap: () {

              Navigator.pushNamed(context, RouteName.subscriptionScreen);
              print('Subscription & Payment tapped');
              // Navigate to Subscription & Payment screen
            },
          ),
          SizedBox(height: 12.h),
          _buildSettingsItem(
            context,
            icon: Icons.notifications_none_outlined,
            title: 'Notifications & Reminders',
            onTap: () {
              print('Notifications & Reminders tapped');
              // Navigate to Notifications & Reminders screen
            },
          ),
          SizedBox(height: 12.h),
          _buildSettingsItem(
            context,
            icon: Icons.cloud_outlined, // Weather icon
            title: 'Weather Settings',
            onTap: () {
              print('Weather Settings tapped');
              // Navigate to Weather Settings screen
            },
          ),
          SizedBox(height: 12.h),
          _buildSettingsItem(
            context,
            icon: Icons.headset_mic_outlined, // Support icon
            title: 'Support & Feedback',
            onTap: () {
              print('Support & Feedback tapped');
              // Navigate to Support & Feedback screen
            },
          ),
          SizedBox(height: 12.h),
          _buildSettingsItem(
            context,
            icon: Icons.info_outline, // About icon, or a custom one if available
            title: 'About Clotique',
            onTap: () {
              print('About Clotique tapped');
              // Navigate to About Clotique screen
            },
          ),
          SizedBox(height: 12.h),
          _buildSettingsItem(
            context,
            icon: Icons.logout,
            title: 'Log out',
            isLogout: true, // Indicate this is the logout button for different styling
            onTap: () => onTapLogOut(context),
          ),
        ],
      ),
    );
  }

  void onTapLogOut(context) {
    final loginLogoutProvider = Provider.of<LoginLogoutProvider>(context, listen: false);
    Navigator.pushNamedAndRemoveUntil(
      context,
      RouteName.loginScreen,
          (route) => false,
    );
    loginLogoutProvider.logOut();
  }
  Widget _buildSettingsItem(
      BuildContext context, {
        required IconData icon,
        required String title,
        required VoidCallback onTap,
        bool isLogout = false,
      }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 18.h),
        decoration: BoxDecoration(
          color: isLogout ? const Color(0xFFFEE4E6) : Colors.white, // Red background for logout
          borderRadius: BorderRadius.circular(16.r),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.05),
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, 5), // subtle shadow
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8.w),
              decoration: BoxDecoration(
                color: isLogout ? const Color(0xFFFD3D54).withOpacity(0.1) : Colors.grey.shade100, // Icon background color
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: isLogout ? const Color(0xFFFD3D54) : Colors.grey.shade700, // Icon color
                size: 24.sp,
              ),
            ),
            SizedBox(width: 16.w),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w500,
                  color: isLogout ? const Color(0xFFFD3D54) : Colors.black87, // Text color
                ),
              ),
            ),
            if (!isLogout) // Don't show arrow for logout
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: Colors.grey.shade400,
                size: 20.sp,
              ),
          ],
        ),
      ),
    );
  }
}