import 'package:clotique/data/model/wardrobe/delete_one_favourite_outfit_provider.dart';
import 'package:clotique/widget/custom_header.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../cors/constant/api_end_point.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../data/model/wardrobe/all_favourite_outfit_provider.dart';

class AllOutfitScreen extends StatelessWidget {
  const AllOutfitScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final allFavouriteOutfitProvider = context.watch<AllFavouriteOutfitProvider>();
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            CustomHeader(onPressed: () {
              Navigator.pushReplacementNamed(context, RouteName.parentScreen);
            }, title: 'All Favorite',),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(
                spacing: 16.h,
                children: List.generate(allFavouriteOutfitProvider.favouriteOutfitList.length, (index) {
                  final imageUrl = '${ApiEndPoint.baseUrl}/public${allFavouriteOutfitProvider.favouriteOutfitList[index].imageUrl}';
                  return Container(
                    height: 300.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16.r),
                      color: Colors.grey.shade200,
                    ),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16.r),
                          child: Image.network(
                            imageUrl,
                            fit: BoxFit.fill,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Center(
                                child: CircularProgressIndicator(
                                  value: loadingProgress.expectedTotalBytes != null
                                      ? loadingProgress.cumulativeBytesLoaded /
                                      loadingProgress.expectedTotalBytes!
                                      : null,
                                  color: const Color(0xFF6359FF),
                                ),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) {
                              return Center(
                                child: Icon(
                                  Icons.broken_image,
                                  size: 50.sp,
                                  color: Colors.grey.shade400,
                                ),
                              );
                            },
                          ),
                        ),
                        Positioned(
                          top: 16.h,
                          right: 16.w,
                          child: Consumer<DeleteOneFavouriteOutfitProvider>(
                            builder: (_, deleteOneFavouriteOutfitProvider, __) {
                              return GestureDetector(
                                onTap: () async {
                                  final isDeleted = await deleteOneFavouriteOutfitProvider.deleteOneFavouriteOutfit(allFavouriteOutfitProvider.favouriteOutfitList[index].id);
                                  if (isDeleted) {
                                    await context.read<AllFavouriteOutfitProvider>().refreshFavouriteOutfits();
                                  }
                                },
                                child: Container(
                                  height: 40.h,
                                  width: 40.w,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12.r),
                                    color: Colors.white
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Image.asset('assets/icons/delete.png'),
                                  ),
                                ),
                              );
                            }
                          ),
                        )
                      ],
                    ),
                  );
                },),
              ),
            ),
            SizedBox(height: 32.h,)
          ],
        ),
      )
    );
  }
}
