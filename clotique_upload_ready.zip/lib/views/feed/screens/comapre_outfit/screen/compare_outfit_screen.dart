import 'dart:io';

import 'package:clotique/widget/primary_button.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';

import '../widget/outfit_dialog.dart'; // Import ImagePicker package

class CompareOutfitScreen extends StatefulWidget {
  const CompareOutfitScreen({super.key});

  @override
  State<CompareOutfitScreen> createState() => _CompareOutfitScreenState();
}

class _CompareOutfitScreenState extends State<CompareOutfitScreen> {
  String? _selectedImagePath;

  // Initialize ImagePicker
  final ImagePicker _picker = ImagePicker();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Compare Outfit'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 20.r,
                  backgroundImage: AssetImage(
                    'assets/images/user2.png', // Matching Courtney Henry's avatar
                  ),
                ),
                SizedBox(width: 12.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Courtney Henry',
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '10 min ago',
                      style: TextStyle(fontSize: 12.sp, color: Colors.grey),
                    ),
                  ],
                ),
                const Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: Color(0xffF2F0FF),
                    borderRadius: BorderRadius.circular(4.r),
                  ),
                  child: Text(
                    'Friends outfit',
                    style: TextStyle(fontSize: 12.sp, color: Colors.black),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16.h),
            Container(
              width: double.infinity,
              height: 200.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.r),
                image: DecorationImage(
                  image: AssetImage(
                    "assets/images/post1.png",
                  ), // Corrected to AssetImage
                  fit: BoxFit.cover,
                ),
              ),
            ),

            SizedBox(height: 12.h),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: Color(0xffF2F0FF),
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Text(
                  'Upload your outfit',
                  style: TextStyle(fontSize: 12.sp, color: Colors.black),
                ),
              ),
            ),

            SizedBox(height: 16.h),
            DottedBorder(
              borderType: BorderType.RRect,
              radius: Radius.circular(8.r),
              padding: EdgeInsets.all(8.w),
              color: Color(0xffDFE1E7),
              strokeWidth: 1,
              dashPattern: const [10, 2],
              child: GestureDetector(
                onTap: _pickImage, // Trigger image picker on tap
                child: Container(
                  width: double.infinity,
                  height: 140.h,
                  color: Color(0xffFFFFFF),
                  alignment: Alignment.center,
                  child: Stack(
                    children: [
                      if (_selectedImagePath != null)
                        Image.file(
                          File(_selectedImagePath!), // Show selected image
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                        ) ,
                      if (_selectedImagePath == null)
                        Positioned(
                          bottom: 8.h,
                          right: 8.w,
                          child: Image.asset("assets/icons/dotted.png"),
                        ),
                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 16.h),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.9,
              child: PrimaryButton(
                text: "Compare Outfit  >|<",
                onPressed: () {
                  showCompareDialog(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(
      source: ImageSource.gallery,
    );
    if (pickedFile != null) {
      setState(() {
        _selectedImagePath = pickedFile.path;
      });
    }
  }
}
