import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

void showCompareDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.r),
        ),
        child: SizedBox(
          width: 300.w, // Adjust width as needed
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Dialog Header
              Container(
                padding: EdgeInsets.all(8.w),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(12.r),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Compare outfit',
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 20),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              // Compare Section
              SizedBox(
                height: 300.h, // Adjust height as needed
                child: Stack(
                  children: [
                    // Left Outfit Image
                    Image.asset(
                      'assets/images/post1.png', // Replace with your left outfit image
                      width: 300.w,
                      height: 300.h,
                      fit: BoxFit.cover,
                    ),
                    // Right Outfit Image with Label
                    Row(
                      children: [
                        Expanded(child: Container()),
                        Container(
                          width: 150.w, // Half width for right side
                          height: 300.h,
                          child: Stack(
                            children: [
                              Image.asset(
                                'assets/images/post2.png', // Replace with your right outfit image
                                width: 150.w,
                                height: 300.h,
                                fit: BoxFit.cover,
                              ),
                              Positioned(
                                top: 8.h,
                                right: 8.w,
                                child: Text(
                                  'Your outfit',
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.white,
                                    backgroundColor: Colors.black.withOpacity(
                                      0.5,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    // Slider for Comparison
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        thumbColor: Colors.purple,
                        activeTrackColor: Colors.transparent,
                        inactiveTrackColor: Colors.transparent,
                        trackHeight: 300.h,
                        thumbShape: const RoundSliderThumbShape(
                          enabledThumbRadius: 8.0,
                        ),
                      ),
                      child: Slider(
                        value: 0.5, // Initial position (middle)
                        min: 0.0,
                        max: 1.0,
                        onChanged: (value) {},
                      ),
                    ),
                  ],
                ),
              ),
              // Note
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.r),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 5,
                      offset: Offset(0, 2), // Subtle shadow effect
                    ),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 16.w,
                    vertical: 12.h,
                  ),
                  child: Text(
                    'Note: Drag left or right to compare outfits side by side and choose your perfect look easily.',
                    style: TextStyle(fontSize: 12.sp, color: Colors.grey[700]),
                    textAlign: TextAlign.center, // Center-aligned text
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
