import 'dart:io';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fluttertoast/fluttertoast.dart';  // Import fluttertoast

import '../../../../../view_model/feed/create_post_viewmodel.dart';

class CreatePostScreen extends StatefulWidget {
  const CreatePostScreen({super.key});

  @override
  State<CreatePostScreen> createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> {
  final TextEditingController _captionController = TextEditingController();
  String? _selectedImagePath;
  String _audience = 'Friends'; // Default audience
  final ImagePicker _picker = ImagePicker();

  late CreatePostViewModel _viewModel;

  @override
  void initState() {
    super.initState();
    _viewModel = CreatePostViewModel();
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImagePath = pickedFile.path; // Update the selected image path
      });
      _viewModel.setSelectedImage(_selectedImagePath!); // Update the ViewModel with the selected image
    }
  }

  @override
  void dispose() {
    _captionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFAF9F6),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Create Post'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 20.r,
                  backgroundImage: const NetworkImage(
                    'https://placehold.co/100x100/A74802/FFFFFF/png',
                  ),
                ),
                SizedBox(width: 12.w),
                Text(
                  'Black Marvin',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 8.w,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey[300]!),
                    borderRadius: BorderRadius.circular(30.r),
                  ),
                  child: DropdownButton<String>(
                    value: _audience,
                    items: <String>['Friends', 'All'].map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _audience = newValue!;
                      });
                    },
                    iconEnabledColor: Colors.black,
                    dropdownColor: Colors.white,
                    underline: Container(),
                  ),
                ),
              ],
            ),

            SizedBox(height: 16.h),
            TextField(
              controller: _captionController,
              decoration: InputDecoration(
                hintText: 'What was today\'s look?',
                hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14.sp),
                border: InputBorder.none,
                focusedBorder: InputBorder.none,
                filled: true,
                fillColor: Color(0xffFFFFFF),
                contentPadding: EdgeInsets.all(12.w),
                suffixIcon: Icon(
                  Icons.emoji_emotions_outlined,
                  color: Colors.black,
                ),
              ),
              maxLines: 1,
            ),

            SizedBox(height: 16.h),
            DottedBorder(
              borderType: BorderType.RRect,
              radius: Radius.circular(8.r),
              padding: EdgeInsets.all(8.w),
              color: Color(0xffDFE1E7),
              strokeWidth: 1,
              dashPattern: const [10, 2],
              child: GestureDetector(
                onTap: _pickImage, // Trigger image picker on tap
                child: Container(
                  width: double.infinity,
                  height: 140.h,
                  color: Color(0xffFFFFFF),
                  alignment: Alignment.center,
                  child: Stack(
                    children: [
                      if (_selectedImagePath != null)
                        Image.file(
                          File(_selectedImagePath!),
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                        ),
                      if (_selectedImagePath == null)
                        Positioned(
                          bottom: 8.h,
                          right: 8.w,
                          child: Image.asset("assets/icons/dotted.png"),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            if (_selectedImagePath != null) ...[
              SizedBox(height: 8.h),
              Text(
                'Leslie Alexander, 10 min ago',
                style: TextStyle(fontSize: 12.sp, color: Colors.grey),
              ),
              Text(
                'My today\'s outfit!',
                style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold),
              ),
            ],

            SizedBox(height: 16.h),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xff202A37),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.r),
                ),
              ),
              onPressed: () {
                if (_captionController.text.isNotEmpty) {
                  // Call the ViewModel's method to create the post
                  _viewModel.createPost(context, _captionController.text, _viewModel.selectedImagePath);
                } else {
                  Fluttertoast.showToast(msg: 'Please enter a caption', gravity: ToastGravity.BOTTOM);
                }
              },
              child: _viewModel.isLoading
                  ? CircularProgressIndicator(color: Colors.white)
                  : Text("Post", style: TextStyle(color: Color(0xffFFFFFF))),
            ),
          ],
        ),
      ),
    );
  }
}
