import 'package:clotique/view_model/profile/edit_post_provider.dart';
import 'package:clotique/view_model/profile/get_user_post_provider.dart';
import 'package:clotique/views/feed/screens/profile/widgets/user_post_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../../../../cors/constant/api_end_point.dart';
import '../../../../../cors/routes/routes_name.dart';
import '../../../../../view_model/auth/check_me/user_details_provider.dart';
import '../../../../../view_model/parent_screen_provider.dart';
import '../../../../../view_model/profile/delete_post_provider.dart';
import '../../../../../widget/custom_header.dart';
import '../../../widget/create_post_header.dart';
import '../widgets/profile_image_section.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  
  @override
  void initState() {
    super.initState();
    context.read<GetUserPostProvider>().getUserPost();
  }

  void _onPostDelete(BuildContext context, String postId) async {
    final deletePostProvider = context.read<DeletePostProvider>();
    final result = await deletePostProvider.deletePost(postId);
    if (result) {
      await context.read<GetUserPostProvider>().getUserPost();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Post deleted successfully')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(deletePostProvider.errorMessage ?? 'Failed to delete post')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final userModel = context.watch<UserDetailsProvider>().userModel;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, __) async {
        await Navigator.pushReplacementNamed(context, RouteName.parentScreen);
        await context.read<ParentScreensProvider>().gotoFeedScreen();
      },
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
            children: [
              CustomHeader(title: 'Profile', onPressed: () => Navigator.pop(context),),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Column(
                  children: [
                    ProfileImageSection(isEditable: false),
                    SizedBox(height: 8.h),
                    ListTile(
                        title: Text(
                          userModel?.name ?? 'Name',
                          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w600),
                        ),
                        subtitle: Text(
                          userModel?.username ?? 'Username',
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildActionButton(
                                icon: 'assets/icons/edit_profile.svg',
                                onTap: (){ Navigator.pushNamed(context, RouteName.editProfileScreen); }
                            ),
                            SizedBox(width: 8.w),
                            _buildActionButton(icon: 'assets/icons/settings.svg', onTap: () {}),
                          ],
                        )
                    ),
                    SizedBox(height: 8.h),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      padding: EdgeInsets.all(8.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('About', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w600)),
                          SizedBox(height: 8.h),
                          Text(
                            userModel?.bio ?? 'Bio',
                            style: TextStyle(fontSize: 14.sp),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 8.h),
                    CreatePostHeader(
                      imageUrl: "${ApiEndPoint.baseUrl}/public/storage/avatar/${context.watch<UserDetailsProvider>().userModel?.avatar}",
                    ),
                    Consumer<GetUserPostProvider>(
                      builder: (_, userPostProvider, __) {
                        return ListView.separated(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: userPostProvider.postResponse?.data.length ?? 0,
                          itemBuilder: (context, index) {
                            final post = userPostProvider.postResponse?.data[index];
                            if (post == null) {
                              return Container();
                            }
                            return Consumer<DeletePostProvider>(
                                builder: (_, deletePostProvider, __) {
                                  return UserPostCard(
                                    postId: post.id.toString(),
                                    avatarUrl: "${ApiEndPoint.baseUrl}/public/storage/avatar/${context.watch<UserDetailsProvider>().userModel?.avatar}",
                                    userName: userModel?.username ?? 'Username',
                                    postTime: post.createdAt.toIso8601String(),
                                    postImageUrl: post.image != null
                                        ? "${ApiEndPoint.baseUrl}/public/storage/avatar/${post.image}"
                                        : 'https://via.placeholder.com/150',
                                    caption: post.caption,
                                    onPostDelete: () {
                                      _onPostDelete(context, post.id.toString());
                                    },
                                    onPostEdit: () async {
                                      await context.read<EditPostProvider>().setPostId(post.id.toString());
                                      Navigator.pushNamed(context, RouteName.editPostScreen,);
                                    },
                                  );
                                }
                            );
                          },
                          separatorBuilder: (context, index) => SizedBox(height: 16.h,),
                        );
                      }
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({required String icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8.r),
          border: Border.all(color: Colors.grey, width: 1.w),
        ),
        padding: EdgeInsets.all(8.w),
        child: SvgPicture.asset(icon),
      ),
    );
  }
}
