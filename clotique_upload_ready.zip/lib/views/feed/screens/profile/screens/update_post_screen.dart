import 'package:clotique/view_model/profile/edit_post_provider.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';

import '../../../../../cors/constant/api_end_point.dart';
import '../../../../../view_model/auth/check_me/user_details_provider.dart';
import '../../../../../view_model/profile/get_user_post_provider.dart';

class UpdatePostScreen extends StatefulWidget {
  const UpdatePostScreen({super.key});

  @override
  State<UpdatePostScreen> createState() => _UpdatePostScreenState();
}

class _UpdatePostScreenState extends State<UpdatePostScreen> {
  final TextEditingController _captionController = TextEditingController();
  String _audience = 'Friends';

  @override
  void dispose() {
    _captionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffFAF9F6),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Edit Post'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 20.r,
                  backgroundImage: context.watch<UserDetailsProvider>().userModel?.avatar != null
                      ? NetworkImage(
                    '${ApiEndPoint.baseUrl}/public/storage/avatar/${context.watch<UserDetailsProvider>().userModel!.avatar}',
                  )
                      : const AssetImage('assets/images/placeholder.png') as ImageProvider,
                ),
                SizedBox(width: 12.w),
                Text(
                  context.watch<UserDetailsProvider>().userModel?.name ?? 'Name',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey[300]!),
                    borderRadius: BorderRadius.circular(30.r),
                  ),
                  child: Consumer<EditPostProvider>(
                    builder: (_, editPostProvider, __) {
                      return DropdownButton<String>(
                        value: editPostProvider.audience,
                        items: <String>['Friends', 'All'].map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              value,
                              style: TextStyle(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          editPostProvider.setAudience(newValue);
                        },
                        iconEnabledColor: Colors.black,
                        dropdownColor: Colors.white,
                        underline: Container(),
                      );
                    }
                  ),
                ),
              ],
            ),
            SizedBox(height: 16.h),
            TextField(
              controller: _captionController,
              decoration: InputDecoration(
                hintText: 'What was today\'s look?',
                hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14.sp),
                border: InputBorder.none,
                focusedBorder: InputBorder.none,
                filled: true,
                fillColor: const Color(0xffFFFFFF),
                contentPadding: EdgeInsets.all(12.w),
                suffixIcon: const Icon(
                  Icons.emoji_emotions_outlined,
                  color: Colors.black,
                ),
              ),
              maxLines: 1,
            ),
            SizedBox(height: 16.h),
            Consumer<EditPostProvider>(
              builder: (context, editPostProvider, child) {
                return DottedBorder(
                  borderType: BorderType.RRect,
                  radius: Radius.circular(8.r),
                  padding: EdgeInsets.all(8.w),
                  color: const Color(0xffDFE1E7),
                  strokeWidth: 1,
                  dashPattern: const [10, 2],
                  child: GestureDetector(
                    onTap: () {
                      context.read<EditPostProvider>().pickImage();
                    },
                    child: Container(
                      width: double.infinity,
                      height: 140.h,
                      color: const Color(0xffFFFFFF),
                      alignment: Alignment.center,
                      child: Stack(
                        children: [
                          if (editPostProvider.isUploaded && editPostProvider.image != null)
                            Image.file(
                              editPostProvider.image!,
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: double.infinity,
                            ),
                          if (!editPostProvider.isUploaded || editPostProvider.image == null)
                            Positioned(
                              bottom: 8.h,
                              right: 8.w,
                              child: Image.asset("assets/icons/dotted.png"),
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
            if (context.watch<EditPostProvider>().image != null) ...[
              SizedBox(height: 8.h),
              Text(
                'Leslie Alexander, 10 min ago',
                style: TextStyle(fontSize: 12.sp, color: Colors.grey),
              ),
              Text(
                'My today\'s outfit!',
                style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold),
              ),
            ],
            SizedBox(height: 16.h),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xff202A37),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.r),
                ),
              ),
              onPressed: () async {
                if (_captionController.text.isNotEmpty) {
                  final result = await context.read<EditPostProvider>().updateUserDetails(_captionController.text);
                  if (result) {
                    Fluttertoast.showToast(
                      msg: 'Post updated successfully',
                      gravity: ToastGravity.BOTTOM,
                    );
                    await context.read<GetUserPostProvider>().getUserPost();
                    Navigator.pop(context); // Navigate back on success
                  } else {
                    Fluttertoast.showToast(
                      msg: 'Failed to update post',
                      gravity: ToastGravity.BOTTOM,
                    );
                  }
                } else {
                  Fluttertoast.showToast(
                    msg: 'Please enter a caption',
                    gravity: ToastGravity.BOTTOM,
                  );
                }
              },
              child: context.watch<EditPostProvider>().isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Post", style: TextStyle(color: Color(0xffFFFFFF))),
            ),
          ],
        ),
      ),
    );
  }
}