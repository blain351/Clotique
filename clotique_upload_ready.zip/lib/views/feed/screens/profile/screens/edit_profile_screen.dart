import 'package:clotique/view_model/auth/check_me/user_details_provider.dart';
import 'package:clotique/view_model/profile/edit_profile_provider.dart';
import 'package:clotique/views/feed/screens/profile/widgets/profile_image_section.dart';
import 'package:clotique/widget/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../../../widget/custom_header.dart';

class EditProfileScreen extends StatefulWidget {
  EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final userDetailsProvider = context.read<UserDetailsProvider>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      userDetailsProvider.getUserDetails();
      _nameController.text = userDetailsProvider.userModel?.name ?? '';
      _usernameController.text = userDetailsProvider.userModel?.username ?? '';
      _bioController.text = userDetailsProvider.userModel?.bio ?? '';
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _usernameController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            CustomHeader(title: 'Edit Profile', onPressed: ()=> Navigator.pop(context),),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    ProfileImageSection(isEditable: true,),
                    SizedBox(height: 16.h),
                    _buildInputField(title: 'Name', controller: _nameController),
                    SizedBox(height: 16.h),
                    _buildInputField(title: 'Username', controller: _usernameController),
                    SizedBox(height: 16.h),
                    _buildInputField(title: 'Bio', controller: _bioController),
                    SizedBox(height: 24.h),
                    Consumer<EditProfileProvider>(
                      builder: (_, editProfileProvider, __) {
                        final name = _nameController.text;
                        final username = _usernameController.text;
                        final bio = _bioController.text;
                        return Visibility(
                          visible: editProfileProvider.isLoading == false,
                          replacement: const Center(child: CircularProgressIndicator(),),
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width * 0.9,
                            child: PrimaryButton(
                              text: "Save",
                              onPressed: () async {
                                await editProfileProvider.updateUserDetails(name, username, bio);
                                await context.read<UserDetailsProvider>().getUserDetails();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Profile updated successfully. Please wait some time...'),
                                    duration: Duration(seconds: 2),
                                  ),
                                );
                                },
                              textColor: Colors.white,
                            ),
                          ),
                        );
                      }
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({required String title, required TextEditingController controller}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title),
        SizedBox(height: 4.h),
        TextFormField(
          controller: controller,
          maxLines: title == 'Bio' ? 4 : 1,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please Enter $title';
            }
            return null;
          },
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
            hintText: title,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.r),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1.w),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.r),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1.w),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.r),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1.w),
            ),
          ),
        )
      ],
    );
  }
}
