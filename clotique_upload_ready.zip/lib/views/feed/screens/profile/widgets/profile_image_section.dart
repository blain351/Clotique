import 'package:clotique/view_model/profile/edit_profile_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../../../../cors/constant/api_end_point.dart';
import '../../../../../view_model/auth/check_me/user_details_provider.dart';

class ProfileImageSection extends StatelessWidget {
  const ProfileImageSection({super.key, required this.isEditable});

  final bool isEditable;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            Stack(
              children: [
                Container(
                  width: double.infinity,
                  height: 140.h,
                  decoration: BoxDecoration(
                    image: const DecorationImage(
                      image: AssetImage('assets/images/cover.png'),
                      fit: BoxFit.cover,
                    ),
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                if (isEditable)
                  Positioned(
                    bottom: 20,
                    right: 20,
                    child: Container(
                      padding: EdgeInsets.all(5.w),
                      decoration: BoxDecoration(
                        color: const Color(0xff202A37),
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      child: SvgPicture.asset('assets/icons/add_image.svg'),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 40.h),
          ],
        ),
        Positioned(
          bottom: 0,
          left: 20,
          child: GestureDetector(
            onTap: () {
              if (isEditable) {
                context.read<EditProfileProvider>().pickImage();
              }
            },
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage: _getBackgroundImage(context),
                  backgroundColor: Colors.black,
                ),
                if (isEditable) SvgPicture.asset('assets/icons/add_image.svg'),
              ],
            ),
          ),
        ),
      ],
    );
  }

  ImageProvider _getBackgroundImage(BuildContext context) {
    final editProfileProvider = context.watch<EditProfileProvider>();
    final userDetailsProvider = context.watch<UserDetailsProvider>();

    if (isEditable && editProfileProvider.image != null) {
      return FileImage(editProfileProvider.image!);
    } else if (!isEditable && editProfileProvider.isUploaded && editProfileProvider.image != null) {
      return FileImage(editProfileProvider.image!);
    } else if (userDetailsProvider.userModel?.avatar != null) {
      return NetworkImage(
        '${ApiEndPoint.baseUrl}/public/storage/avatar/${userDetailsProvider.userModel!.avatar}',
      );
    } else {
      return const AssetImage('assets/images/placeholder.png');
    }
  }
}