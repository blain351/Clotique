import 'package:clotique/view_model/feed/get_all_comments_provider.dart';
import 'package:clotique/view_model/parent_screen_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../../cors/constant/api_end_point.dart';
import '../../../../cors/routes/routes_name.dart';
import '../../../../view_model/auth/check_me/user_details_provider.dart';
import '../../../../view_model/feed/create_comment_provider.dart';
import '../../../../view_model/feed/feed_view_model.dart';
import '../../../../view_model/profile/edit_profile_provider.dart';
import '../../widget/create_post_header.dart';
import '../../widget/header_widget_feed.dart';
import '../../widget/post_card.dart';

class CommentScreen extends StatefulWidget {
  const CommentScreen({super.key});

  @override
  State<CommentScreen> createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen> {

  final TextEditingController _commentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final postId = context.read<CreateCommentProvider>().postId;
      if (postId != null) {
        context.read<GetAllCommentsProvider>().getAllComments(postId);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final commentProvider = context.read<CreateCommentProvider>();
    final feedViewModel = Provider.of<FeedViewModel>(context);
    final getAllCommentsProvider = Provider.of<GetAllCommentsProvider>(context);
    final selectedPostId = commentProvider.postId;
    final post = feedViewModel.getPostById(selectedPostId);
    if (post == null) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, __) async {
        await Navigator.pushReplacementNamed(context, RouteName.parentScreen);
        await context.read<ParentScreensProvider>().gotoFeedScreen();

      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(
            children: [
              HeaderWidgetFeed(),
              SizedBox(height: 20.h),
              CreatePostHeader(
                imageUrl: "${ApiEndPoint.baseUrl}/public/storage/avatar/${context.watch<UserDetailsProvider>().userModel?.avatar}",
              ),
              SizedBox(height: 20.h),
              PostCard(
                postId: post.id.toString(),
                avatarUrl: post.user?.avatar ?? 'assets/images/user2.png',
                userName: post.user?.username ?? 'Unknown',
                postTime: post.createTimeAgo,
                postImageUrl:
                post.image != null
                    ? "${ApiEndPoint.baseUrl}/public/storage/avatar/${post.image}"
                    : 'https://via.placeholder.com/150',
                caption: post.caption,
                likes: post.likeCount.toString(),
                comments: getAllCommentsProvider.comments.length.toString(),
                shares: post.shareCount.toString(),
              ),
              SizedBox(height: 12.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _commentController,
                        decoration: InputDecoration(
                          labelText: 'Comment',
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12.r),
                            borderSide: BorderSide(
                              color: Colors.grey.shade300,
                              width: 1.w,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    GestureDetector(
                      onTap: () async {
                        if (_commentController.text.isEmpty) {
                          return;
                        }
                        await commentProvider.commentPost(post.id, _commentController.text);
                        _commentController.clear();
                        await context.read<GetAllCommentsProvider>().getAllComments(post.id);
                        await context.read<FeedViewModel>().updateCommentCount(post.id, getAllCommentsProvider.comments.length);
                      },
                      child: Container(
                        height: 48.h,
                        width: 48.w,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [
                                Color(0xFF5E59FF),
                                Color(0xFF9C7DF5),
                              ]
                          ),
                          borderRadius: BorderRadius.circular(45.r),
                        ),
                        child: Image.asset('assets/icons/send.png', height: 32.h),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 12.h),
              Consumer<GetAllCommentsProvider>(
                builder: (context, getCommentProvider, _) {
                  if (getCommentProvider.isLoading) {
                    return Center(child: CircularProgressIndicator());
                  }

                  if (getCommentProvider.errorMessage != null) {
                    return Center(child: Text(getCommentProvider.errorMessage!));
                  }

                  if (getCommentProvider.comments.isEmpty) {
                    return Center(child: Text("No comments available"));
                  }
                  return Column(
                    spacing: 8.h,
                    children: List.generate(getCommentProvider.comments.length, (index) {
                      final comment = getCommentProvider.comments[index];
                      return Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.w),
                        child: Container(
                          height: 80.h,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: Column(
                            children: [
                              ListTile(
                                leading: CircleAvatar(
                                  radius: 20.r,
                                  backgroundImage: context.watch<EditProfileProvider>().isUploaded == true
                                      ? FileImage(context.watch<EditProfileProvider>().image!)
                                      : NetworkImage('${ApiEndPoint.baseUrl}/public/storage/avatar/${context.watch<UserDetailsProvider>().userModel?.avatar}'),
                                ),
                                title: Row(
                                  children: [
                                    Expanded(child: Text(comment.user.username ?? 'Unknown')),
                                    Text(comment.timeAgo, style: TextStyle(fontSize: 10.sp)),
                                  ],
                                ),
                                subtitle: Text(comment.content),
                              ),
                              Row(
                                children: [

                                ],
                              )
                            ],
                          ),
                        ),
                      );
                    }),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
