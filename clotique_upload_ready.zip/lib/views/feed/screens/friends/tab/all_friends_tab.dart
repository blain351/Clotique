import 'package:clotique/cors/routes/routes_name.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../../view_model/friends/single_user_all_friend_provider/all_friends_provider.dart';

class SingleUserAllFriendTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SingleUserAllFriendProvider(),
      child: Consumer<SingleUserAllFriendProvider>(
        builder: (context, provider, child) {
          // Loading State
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          // Error State
          if (provider.errorMessage.isNotEmpty) {
            return Center(
              child: Text(
                provider.errorMessage,
                style: TextStyle(color: Colors.red, fontSize: 16.sp),
              ),
            );
          }

          // No friends found
          if (provider.friendsList.isEmpty) {
            return const Center(
              child: Text(
                'No friends found.',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            );
          }

          // Displaying friends
          return Scaffold(
            appBar: AppBar(
              title: Text(
                'All Friends',
                style: TextStyle(fontSize: 18.sp),
              ),
            ),
            backgroundColor: Colors.white,
            body: SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16.h),
                  Text(
                    'Your Friends',
                    style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16.h),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: provider.friendsList.length,
                    itemBuilder: (context, index) {
                      final friend = provider.friendsList[index];
                      return ListTile(
                        leading: CircleAvatar(
                          radius: 20,
                          backgroundImage: friend.avatar.isNotEmpty
                              ? NetworkImage(friend.avatar)
                              : const AssetImage("assets/images/apple.png") as ImageProvider,
                        ),
                        title: Text(
                          friend.name ?? 'No Name',
                          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          friend.username ?? 'No Username',
                          style: TextStyle(fontSize: 12.sp, color: Colors.grey),
                        ),
                        onTap: () {

                          Navigator.pushNamed(context, RouteName.allFriends);
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
