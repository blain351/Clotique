import 'package:clotique/cors/routes/routes_name.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../../../view_model/friends/suggestions/single_user_suggestion_friend_provider.dart';

class SingleUserSuggestionTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SingleUserSuggestionFriendProvider(),
      child: Consumer<SingleUserSuggestionFriendProvider>(
        builder: (context, provider, child) {
          // Loading State
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          // Error State
          if (provider.errorMessage.isNotEmpty) {
            return Center(
              child: Text(
                provider.errorMessage,
                style: TextStyle(color: Colors.red, fontSize: 16.sp),
              ),
            );
          }

          // No suggestions
          if (provider.suggestions.isEmpty) {
            return const Center(
              child: Text(
                'No suggestions found.',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            );
          }

          // Displaying suggestions
          return Scaffold(
            appBar: AppBar(
              title: Text(
                'Friend Suggestions',
                style: TextStyle(fontSize: 18.sp),
              ),
            ),
            backgroundColor: Colors.white,
            body: SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16.h),
                  Text(
                    'Suggestions for You',
                    style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16.h),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: provider.suggestions.length,
                    itemBuilder: (context, index) {
                      final suggestion = provider.suggestions[index];
                      return ListTile(
                        leading: CircleAvatar(
                          radius: 20,
                          backgroundImage: suggestion.avatar != null
                              ? NetworkImage(suggestion.avatar!)
                              : const AssetImage("assets/images/apple.png") as ImageProvider,
                        ),
                        title: Text(
                          suggestion.name ?? 'No Name',
                          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          suggestion.username ?? 'No Username',
                          style: TextStyle(fontSize: 12.sp, color: Colors.grey),
                        ),
                        trailing: suggestion.isRequested
                            ? ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xff7E6BFA), // Purple color
                            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                          ),
                          child: Container(
                            width: 85.w, // Reduced width for the "Connect" button
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset('assets/images/add_circle.png', scale: 3),
                                SizedBox(width: 10.w),
                                Text(
                                  'Connect',
                                  style: TextStyle(fontSize: 14.sp, color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                        )
                            : ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey.shade100, // Grey color for Cancel
                            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                          ),
                          child: Text(
                            'Cancel',
                            style: TextStyle(fontSize: 14.sp, color: Colors.black),
                          ),
                        ),
                        onTap: () {
                          Navigator.pushNamed(context, RouteName.friendsProfileScreen);
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
