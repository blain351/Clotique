import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../cors/constant/api_end_point.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../view_model/auth/check_me/user_details_provider.dart';
import '../../../view_model/profile/edit_profile_provider.dart';

class HeaderWidgetFeed extends StatelessWidget {
  const HeaderWidgetFeed({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 130.h, // Dynamic height
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF5E59FF), Color(0xFF9C7DF5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30.r),
          bottomRight: Radius.circular(30.r),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.end,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Feed',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24.sp, // Dynamic font size
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Spacer(),
                GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(context, RouteName.searchScreen);
                  },
                  child: Icon(
                    Icons.search,
                    color: Colors.white,
                    size: 30.sp, // Dynamic icon size
                  ),
                ),
                SizedBox(width: 16.w),
                GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(context, RouteName.friendsScreen);
                  },
                  child: Icon(
                    Icons.people,
                    color: Colors.white,
                    size: 30.sp, // Dynamic icon size
                  ),
                ),
                SizedBox(width: 16.w),
                Icon(
                  Icons.notification_add_outlined,
                  color: Colors.white,
                  size: 30.sp, // Dynamic icon size
                ),
                SizedBox(width: 16.w),
                GestureDetector(
                  onTap: () => Navigator.pushNamed(context, RouteName.profileScreen),
                  child: Container(
                    height: 50.h,
                    width: 50.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50.r),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(50.r),
                      child: context.watch<EditProfileProvider>().isUploaded == true &&
                          context.watch<EditProfileProvider>().image != null
                          ? Image.file(context.watch<EditProfileProvider>().image!, errorBuilder: (context, error, stackTrace) => Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(50.r), color: Colors.white),child: Icon(Icons.person_2_outlined, color: Color(0xFF5E59FF), size: 24.sp)),)
                          : context.watch<UserDetailsProvider>().userModel?.avatar != null
                            ? Image.network('${ApiEndPoint.baseUrl}/public/storage/avatar/${context.watch<UserDetailsProvider>().userModel!.avatar}', errorBuilder: (context, error, stackTrace) => Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(50.r), color: Colors.white),child: Icon(Icons.person_2_outlined, color: Color(0xFF5E59FF), size: 24.sp)),)
                            : Icon(Icons.person,), // Fallback placeholder image
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
