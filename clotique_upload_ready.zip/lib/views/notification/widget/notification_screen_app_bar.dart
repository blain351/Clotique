import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class NotificationScreenAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBackTap;
  final VoidCallback? onSearchTap;

  const NotificationScreenAppBar({
    super.key,
    this.title = 'Notification', // Default title as in the image
    this.onBackTap,
    this.onSearchTap,
  });

  @override
  Widget build(BuildContext context) {


    return Container(
      // The background color from your previous widgets if this bar sits on top of that background
      // If it's meant to be a standalone bar, you might set a specific background like Colors.white
      color: Colors.white, // Assuming a white background for the bar itself, as per image
      padding: EdgeInsets.fromLTRB(16.w, 50.h, 16.w, 16.h), // Adjusted top padding for status bar
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: onBackTap ?? () {
              print('Back button tapped (default)');
              Navigator.pop(context);
              // Navigator.of(context).pop(); // Use this if integrated into a Navigator stack
            },
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              color: const Color(0xFF2C3E50), // Darker grey/black as in image
              size: 24.sp,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 20.sp,
              fontWeight: FontWeight.bold,
              color: const Color(0xFF2C3E50), // Darker grey/black as in image
            ),
          ),
          GestureDetector(
            onTap: onSearchTap ?? () {
              print('Search button tapped (default)');
            },
            child: Icon(
              Icons.search,
              color: const Color(0xFF2C3E50), // Darker grey/black as in image
              size: 24.sp,
            ),
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => Size.fromHeight(56.h);
}