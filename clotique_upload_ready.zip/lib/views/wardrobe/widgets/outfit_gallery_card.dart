import 'package:clotique/cors/routes/routes_name.dart';
import 'package:clotique/data/model/home/daily_outfit_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../cors/constant/api_end_point.dart';

class OutfitGalleryCard extends StatefulWidget {
  final String title;
  final int totalItems;
  final List<DailyOutfitModel> outfitList;
  final VoidCallback onSeeAllTap;

  const OutfitGalleryCard({
    super.key,
    required this.title,
    required this.totalItems,
    required this.outfitList,
    required this.onSeeAllTap,
  });

  @override
  State<OutfitGalleryCard> createState() => _OutfitGalleryCardState();
}

class _OutfitGalleryCardState extends State<OutfitGalleryCard> {
  late PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _currentPage = 0;
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: Title and Item Count (now outside the card)
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 0.w, vertical: 10.h), // Adjust padding as needed
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.title,
                  style: TextStyle(
                    fontSize: 24.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 6.h),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color(0xFFDFE1E7), // Border color: #DFE1E7
                      width: 1.5, // Border width
                    ),
                    borderRadius: BorderRadius.circular(30.r), // Rounded corners
                  ),
                  child: Text(
                    '${widget.outfitList.length} Item',
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey.shade700,
                    ),
                  ),
                )

              ],
            ),
          ),
          SizedBox(height: 10.h), // Space between title/items and the card

          // The Card itself
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20.r),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 15,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            padding: EdgeInsets.all(20.w), // Padding for content inside the card
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Outfit Image Carousel
                ClipRRect(
                  borderRadius: BorderRadius.circular(16.r),
                  child: Container(
                    height: 300.h,
                    width: double.infinity,
                    color: Colors.grey.shade200,
                    child: widget.outfitList.isEmpty
                        ? Center(
                      child: Text(
                        'No Outfits Uploaded',
                        style: TextStyle(fontSize: 16.sp, color: Colors.grey.shade500),
                      ),
                    )
                        : PageView.builder(
                      controller: _pageController,
                      itemCount: widget.outfitList.length < 3 ? widget.outfitList.length : 3,
                      onPageChanged: (index) {
                        setState(() {
                          _currentPage = index;
                        });
                      },
                      itemBuilder: (context, index) {
                        final imageUrl = '${ApiEndPoint.baseUrl}/public${widget.outfitList[index].imageUrl}';
                        return Image.network(
                          imageUrl,
                          fit: BoxFit.fill,
                          loadingBuilder: (context, child, loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Center(
                              child: CircularProgressIndicator(
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded /
                                    loadingProgress.expectedTotalBytes!
                                    : null,
                                color: const Color(0xFF6359FF),
                              ),
                            );
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return Center(
                              child: Icon(
                                Icons.broken_image,
                                size: 50.sp,
                                color: Colors.grey.shade400,
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
                SizedBox(height: 20.h),

                // Navigation and "See All" button
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Navigation Arrows
                    Row(
                      children: [
                        // Left Arrow
                        Container(
                          padding: const EdgeInsets.all(1), // Padding inside the border
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30), // Rounded corners
                            border: Border.all(
                              color: const Color(0xFFDFE1E7), // Border color: #DFE1E7
                              width: 1, // Border width
                            ),
                          ),
                          child: IconButton(
                            icon: Image.asset(
                              "assets/icons/arrow-left.png",
                              scale: 2.8,
                            ),
                            onPressed: _currentPage == 0
                                ? null
                                : () {
                              _pageController.previousPage(
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeOut,
                              );
                            },
                          ),
                        ),

                        SizedBox(width: 8.w),
                        // Page Indicator
                        Text(
                          '${widget.outfitList.isEmpty ? 0 : _currentPage + 1} / ${widget.outfitList.length > 3 ? 3 : widget.outfitList.length}',
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.black87,
                          ),
                        ),
                        SizedBox(width: 8.w),
                        // Right Arrow
                        Container(
                          padding: const EdgeInsets.all(1), // Padding inside the border
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30), // Rounded corners
                            border: Border.all(
                              color: const Color(0xFFDFE1E7), // Border color: #DFE1E7
                              width: 1, // Border width
                            ),
                          ),
                          child: IconButton(
                            icon: Image.asset(
                              "assets/icons/arrow-right.png",
                              scale: 2.9,
                            ),
                            onPressed: _currentPage == (widget.outfitList.length > 3 ? 3 : widget.outfitList.length) - 1
                                ? null
                                : () {
                              _pageController.nextPage(
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeOut,
                              );
                            },
                          ),
                        )

                      ],
                    ),
                    // See All Button
                    SizedBox(
                      height: 40.h,
                      child: OutlinedButton(
                        onPressed: () {
                          widget.onSeeAllTap();
                        },
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color(0xFF8570F9),
                          side: const BorderSide(color: Color(0xFF8570F9), width: 1),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.r),
                          ),
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                        ),
                        child: Text(
                          'See All',
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}