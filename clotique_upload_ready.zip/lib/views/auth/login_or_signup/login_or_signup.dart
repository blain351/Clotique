import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../cors/routes/routes_name.dart';
import '../../../widget/primary_button.dart';
import '../../../widget/primary_outline_button.dart';

class LoginOrSignup extends StatelessWidget {
  const LoginOrSignup({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 20.w,
        ), // Ensure responsive padding
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 300.h),
            Image.asset(
              'assets/onboarding/splash.png',
              height: 200.h,
              width: 200.w,
            ),
            // Title
            Spacer(),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.9,
              child: PrimaryOutlineButton(
                text: "Login",
                onPressed: () {
                    Navigator.pushNamed(context, RouteName.loginScreen);
                },
                borderColor: Color(0xff7E6BFA),
                textColor: Color(0xff7E6BFA),
              ),
            ),
            SizedBox(height: 20.w),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.9,
              child: PrimaryButton(
                text: "Sign Up",
                onPressed: () {
                   Navigator.pushNamed(context, RouteName.signUpScreen);
                },
                // backgroundColor: Color(0xff0069C0),
                // textColor: Colors.white,
              ),
            ),
            SizedBox(height: 16.h),

            // GoogleButton(),
            SizedBox(height: 55.h),
          ],
        ),
      ),
    );
  }
}
