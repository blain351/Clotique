import 'package:clotique/view_model/auth/otp_verify/confirm_otp_provider.dart';
import 'package:clotique/view_model/auth/forget_pass/for_got_password_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../view_model/auth/reset_pass/set_password_provider.dart';
import '../../../widget/custom_text_field.dart';
import '../../../widget/primary_button.dart';

class SetPassword extends StatelessWidget {
  const SetPassword({super.key});

  @override
  Widget build(BuildContext context) {
    final email = Provider.of<ForgotPasswordProvider>(context, listen: false).email;
    final otpToken = Provider.of<ConfirmOtpProvider>(context, listen: false).token;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Consumer<SetPasswordProvider>(
            builder: (context, provider, _) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 30.h),
                  Align(
                    alignment: Alignment.topLeft,
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: EdgeInsets.all(6.r),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(color: const Color(0xffE9E6FE)),
                        ),
                        child: Image.asset(
                          "assets/icons/back_arrow.png",
                          height: 20.h,
                          width: 20.w,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 29.h),
                  Text(
                    "Set Password",
                    style: TextStyle(
                      color: Color(0xff212121),
                      fontSize: 24.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Text("New Password", style: _labelStyle()),
                  SizedBox(height: 7.h),
                  CustomTextField(
                    hintText: 'New Password',
                    obscureText: !provider.passwordVisible,
                    suffixIcon: IconButton(
                      icon: Icon(
                        provider.passwordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                      onPressed: provider.togglePasswordVisibility,
                    ),
                    onChanged: provider.setPassword,
                  ),
                  if (provider.password.isNotEmpty)
                    Padding(
                      padding: EdgeInsets.only(top: 4.h, left: 8.w),
                      child: RichText(
                        text: TextSpan(
                          children: provider.passwordValidationSpans,
                        ),
                      ),
                    ),
                  SizedBox(height: 16.h),
                  Text("Confirm Password", style: _labelStyle()),
                  SizedBox(height: 7.h),
                  CustomTextField(
                    hintText: 'Confirm Password',
                    obscureText: !provider.confirmPasswordVisible,
                    suffixIcon: IconButton(
                      icon: Icon(
                        provider.confirmPasswordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                      onPressed: provider.toggleConfirmPasswordVisibility,
                    ),
                    onChanged: provider.setConfirmPassword,
                  ),
                  if (provider.confirmPassword.isNotEmpty &&
                      !provider.passwordsMatch)
                    Padding(
                      padding: EdgeInsets.only(top: 4.h, left: 8.w),
                      child: Text(
                        "Passwords do not match",
                        style: TextStyle(color: Colors.red, fontSize: 12.sp),
                      ),
                    ),
                  const Spacer(),
                  Consumer<SetPasswordProvider>(
                    builder: (_, provider, __) {
                      return Visibility(
                        visible: provider.isLoading == false,
                        replacement: const Center(
                          child: CircularProgressIndicator(),
                        ),
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * 0.9,
                          child: PrimaryButton(
                            text: 'Reset Password',
                            textColor: Colors.white,
                            onPressed: () {
                              final password = provider.password;
                              provider.reset(context, email, otpToken, password);
                              if (provider.errorMessage == '' || provider.errorMessage.isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Reset Password Successfully'),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Reset Password Failed'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            },
                          ),
                        ),
                      );
                    }
                  ),
                  SizedBox(height: 20.h),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  TextStyle _labelStyle() => TextStyle(
    color: Color(0xff7C7D81),
    fontSize: 12.sp,
    fontWeight: FontWeight.w500,
  );
}
