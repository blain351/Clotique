import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../view_model/auth/sign_up/sign_up_provider.dart';
import '../../../widget/apple_button.dart';
import '../../../widget/custom_text_field.dart';
import '../../../widget/facebook_button.dart';
import '../../../widget/google_button.dart';
import '../../../widget/primary_button.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController emailController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 27.h),
                Image.asset(
                  "assets/icons/export_button.png",
                ),
                SizedBox(height: 36.h),
                Text(
                  "Create your Account",
                  style: TextStyle(
                    color: Color(0xff212121),
                    fontSize: 24.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 16.h),

                Text("Email", style: _labelStyle()),
                SizedBox(height: 7.h),
                CustomTextField(
                  controller: emailController,
                  hintText: "Enter your email",
                  keyboardType: TextInputType.emailAddress,
                  obscureText: false,
                ),

                SizedBox(height: 16.h),
                Text("Password", style: _labelStyle()),
                SizedBox(height: 7.h),
                CustomTextField(
                  controller: passwordController,
                  hintText: "New Password",
                  keyboardType: TextInputType.text,
                  obscureText: true,
                  suffixIcon: IconButton(
                    icon: Icon(Icons.visibility_off),
                    onPressed: () {},
                  ),
                ),

                SizedBox(height: 40.h),
                Consumer<SignUpProvider>(
                  builder: (context, signUpProvider, child) {
                    return SizedBox(
                      width: MediaQuery.of(context).size.width * 0.9,
                      child: PrimaryButton(
                        text: signUpProvider.isLoading ? 'Signing Up...' : 'Sign Up',
                        textColor: Color(0xffFFFFFF),
                        onPressed: signUpProvider.isLoading
                            ? null
                            : () async {
                          // Get values from the controllers
                          final email = emailController.text.trim();
                          final password = passwordController.text.trim();

                          if (email.isEmpty || password.isEmpty) {
                            // Handle empty field error
                            return;
                          }

                          final signUpResponse = await signUpProvider.signUp(email, password);

                          if (signUpResponse != null && signUpResponse.success == true) {
                            // Navigate to the next screen on success
                            Navigator.pushNamed(context, RouteName.loginScreen);
                          } else {
                            // Handle failure, show error message
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(signUpProvider.errorMessage)),
                            );
                          }
                        },
                      ),
                    );
                  },
                ),
                SizedBox(height: 20.h),
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "- Or -",
                    style: TextStyle(
                      color: Color(0xff000000),
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                SizedBox(height: 20.h),
                AppleButton(),
                SizedBox(height: 10),
                GoogleButton(),
                SizedBox(height: 10),
                FacebookButton(),

                SizedBox(height: 24.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Already have an account?",
                      style: TextStyle(
                        color: Color(0xff000000),
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pushNamed(context, RouteName.loginScreen);
                      },
                      child: Text(
                        "Login",
                        style: TextStyle(
                          color: Color(0xff7E6BFA),
                          fontWeight: FontWeight.w700,
                          fontSize: 16.sp,
                        ),
                      ),
                    ),
                  ],
                ),
                // Your Apple, Google, Facebook buttons code continues...
                // Keep the rest of the layout as is
              ],
            ),
          ),
        ),
      ),
    );
  }

  TextStyle _labelStyle() => TextStyle(
    color: Color(0xff7C7D81),
    fontSize: 12.sp,
    fontWeight: FontWeight.w500,
  );
}
