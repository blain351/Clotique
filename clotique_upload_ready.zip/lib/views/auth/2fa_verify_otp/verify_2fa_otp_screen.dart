import 'package:clotique/view_model/auth/login_logout_provider/login_logout_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../view_model/auth/otp_verify/confirm_otp_provider.dart';
import '../../../widget/pincode_text_field.dart';
import '../../../widget/primary_button.dart';

class Verify2faOtpScreen extends StatelessWidget {
  Verify2faOtpScreen({super.key});

  final TextEditingController _otpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final otpProvider = Provider.of<LoginLogoutProvider>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 24.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: EdgeInsets.all(6.r),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(color: const Color(0xffE9E6FE)),
                    ),
                    child: Image.asset(
                      "assets/icons/back_arrow.png",
                      height: 20.h,
                      width: 20.w,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 32.h),
              Text(
                "Verify Code for Two-Factor Authentication",
                style: TextStyle(
                  fontSize: 24.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 8.h),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "We’ve sent a code to your email",
                      style: TextStyle(
                        fontSize: 16.sp,
                        color: Colors.black,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 65.h),
              PincodeTextField(
                onChanged: otpProvider.setOtp,
                otpController: _otpController,
              ),
              SizedBox(height: 20.h),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "Resend : ",
                      style: TextStyle(
                        color: Color(0xff000000),
                        fontWeight: FontWeight.w400,
                        fontSize: 16.sp,
                      ),
                    ),
                    TextSpan(
                      text: "59s",
                      style: TextStyle(
                        color: Color(0xff7E6BFA),
                        fontWeight: FontWeight.w400,
                        fontSize: 16.sp,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 110.h),
              Center(
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "Didn’t get the OTP?\n",
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 18.sp,
                          color: Color(0xff000000),
                        ),
                      ),
                      TextSpan(
                        text: "   Resend code",
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 18.sp,
                          color: Color(0xff7E6BFA),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              Consumer<LoginLogoutProvider>(
                  builder: (_, provider, __) {
                    return Visibility(
                      visible: provider.isVerifyLoading == false,
                      replacement: Center(child: CircularProgressIndicator(),),
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width * 0.9,
                        child: PrimaryButton(
                          text: 'Verify',
                          textColor: Color(0xffFFFFFF),
                          onPressed: () async {
                            provider.userLoginWith2faOtp(context);
                          },
                        ),
                      ),
                    );
                  }
              ),
            ],
          ),
        ),
      ),
    );
  }
}