import 'package:clotique/view_model/home/daily_weather_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class TodayWeatherWidget extends StatefulWidget {
  const TodayWeatherWidget({super.key});

  @override
  State<TodayWeatherWidget> createState() => _TodayWeatherWidgetState();
}

class _TodayWeatherWidgetState extends State<TodayWeatherWidget> {
  int _selectedIndex = -1;

  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _searchController.text = "Dhaka";
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.all(16.0.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Today Weather",
              style: TextStyle(
                fontSize: 22.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 20.h),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10.r),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 2,
                    blurRadius: 10,
                    offset: Offset(0, 5.h),
                  ),
                ],
              ),
              child: Consumer<DailyWeatherProvider>(
                builder: (_, provider, __) {
                  return TextField(
                    controller: _searchController,
                    onSubmitted: (value) {
                      provider.getDailyWeather(_searchController.text.trim());
                    },
                    decoration: InputDecoration(
                      hintText: "Place Name",
                      hintStyle: TextStyle(color: Colors.grey[600]),
                      border: InputBorder.none,
                      suffixIcon: GestureDetector(
                        onTap: () =>provider.getDailyWeather(_searchController.text.trim()),
                        child: Image.asset(
                          "assets/icons/search.png",
                          scale: 1.6,
                        ),
                      ),
                    ),
                    style: TextStyle(fontSize: 16.sp),
                  );
                }
              ),
            ),
            SizedBox(height: 20.h),
            Consumer<DailyWeatherProvider>(
                builder: (_, provider, __) {
                  if (provider.isLoading) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (provider.errorMessage.isNotEmpty) {
                    return Center(child: Text(provider.errorMessage, style: TextStyle(color: Colors.red)));
                  }
                  if (provider.dailyWeatherModel == null) {
                    return Center(child: Text("No data available"));
                  }
                  final model = provider.dailyWeatherModel!;
                  return Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(25.w),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF5E59FF), Color(0xFF9C7DF5)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20.r),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.deepPurpleAccent.withOpacity(0.3),
                          blurRadius: 15,
                          offset: Offset(0, 8.h),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              model.location['city'] ?? 'Loading...',
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              model.currentIcon,
                              style: TextStyle(fontSize: 40.sp),
                            ),
                          ],
                        ),
                        Text(
                          model.location['country'] ?? 'Unknown',
                          style: TextStyle(
                            fontSize: 14.sp,
                            color: Colors.white70,
                          ),
                        ),
                        SizedBox(height: 15.h),
                        Text(
                          "${model.currentTemp.toString()}° C",
                          style: TextStyle(
                            fontSize: 48.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  );
                }
            ),
            SizedBox(height: 20.h),
            Consumer<DailyWeatherProvider>(
              builder: (_, provider, __) {
                if (provider.dailyWeatherModel == null) {
                  return Center(child: Text("No data available"));
                }
                return SizedBox(
                  height: 160.h,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: List.generate(provider.dailyWeatherModel!.hourlyForecast.length, (index) {
                      final times = provider.dailyWeatherModel!.hourlyForecast.map((forecast) => forecast.time).toList();
                      final icons = provider.dailyWeatherModel!.hourlyForecast.map((forecast) => forecast.icon).toList();
                      final temps = provider.dailyWeatherModel!.hourlyForecast.map((forecast) => forecast.temp.toString()).toList();
                      return _buildHourlyForecastCard(
                        time: times[index],
                        assetPath: icons[index],
                        temperature: '${temps[index]}°',
                        index: index,
                        context: context,
                      );
                    }),
                  ),
                );
              }
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHourlyForecastCard({
    required String time,
    required String assetPath,
    required String temperature,
    required int index,
    required BuildContext context,
  }) {
    return Container(
      width: 90.w,
      margin: EdgeInsets.only(right: 15.w),
      padding: EdgeInsets.symmetric(vertical: 15.h, horizontal: 10.w),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Colors.grey[300]!,
          width: 1.w,
        ),
        borderRadius: BorderRadius.circular(15.r),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 10,
            offset: Offset(0, 5.h),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Text(
            time,
            style: TextStyle(
              fontSize: 13.sp,
              color: Colors.grey[700],
            ),
          ),
          Text(assetPath, style: TextStyle(fontSize: 20.sp)),
          Text(
            temperature,
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}