import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../cors/routes/routes_name.dart';

class CreateShareLookWidget extends StatelessWidget {
  const CreateShareLookWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: EdgeInsets.all(20.0.w),
        padding: EdgeInsets.all(25.0.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(25.r),
          border: Border.all(color: const Color(0xFFDFDAFE), width: 1.w),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 5,
              blurRadius: 15,
              offset: Offset(0, 8.h),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(15.w),
              // decoration: BoxDecoration(
              //   color: Colors.deepPurple.shade50,
              //   shape: BoxShape.circle,
              // ),
              child: Image.asset(
                "assets/icons/ai_look.png",
                scale: 2.9,
              ),
            ),
            SizedBox(height: 25.h),
            Text(
              "Create & Share Your Look",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 15.h),
            Text(
              "Use our AI generator to style an outfit or log your own, then post it to get feedback from friends.",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.sp,
                color: Colors.grey[700],
                height: 1.5,
              ),
            ),
            SizedBox(height: 30.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildActionIcon(Icons.favorite_border),
                _buildActionIcon(Icons.chat_bubble_outline),
                _buildActionIcon(Icons.share),
                _buildActionIcon(Icons.content_copy),
              ],
            ) ,
            SizedBox(height: 30.h),
            Container(
              width: 0.75.sw,
              height: 55.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30.r),
                boxShadow: [
                  BoxShadow(
                    color: Colors.deepPurpleAccent.withOpacity(0.3),
                    blurRadius: 10,
                    offset: Offset(0, 5.h),
                  ),
                ],
                gradient: const LinearGradient(
                  colors: [Color(0xFF5E59FF), Color(0xFF9C7DF5)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: ElevatedButton(
                onPressed: () {
                  //Navigator.pushNamed(context, RouteName.createPostScreen);
                  print('Create a Post button pressed!');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.r),
                  ),
                  padding: EdgeInsets.zero,
                ),
                child: Text(
                  "Create a Post",
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionIcon(IconData icon) {
    return Icon(
      icon,
      color: Colors.grey[600],
      size: 24.w,
    );
  }
}
