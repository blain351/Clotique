import 'package:clotique/data/model/home/daily_weather_model.dart';
import 'package:flutter/material.dart';
import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';

class DailyWeatherProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';
  DailyWeatherModel? _dailyWeatherModel;

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  DailyWeatherModel? get dailyWeatherModel => _dailyWeatherModel;

  final ApiService _apiService = ApiService();

  Future<void> getDailyWeather(String placeName) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      final response = await _apiService.get(ApiEndPoint.dailyWeatherByPlaceName(placeName));

      if (response.statusCode == 200) {
        _dailyWeatherModel = DailyWeatherModel.fromJson(response.data);
      } else {
        _errorMessage = 'Failed to fetch data: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = 'Give a valid place name';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
