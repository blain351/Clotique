import 'package:clotique/data/model/home/daily_outfit_model.dart';
import 'package:flutter/material.dart';
import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';

class DailySmartOutfitProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';
  List<DailyOutfitModel> _response = [];

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  List<DailyOutfitModel> get response => _response;

  final ApiService _apiService = ApiService();

  Future<void> getDailySmartOutfit() async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      final response = await _apiService.get(ApiEndPoint.dailySmartOutfit);
      if (response.statusCode == 200) {
        print("Response data: ${response.data}");
        _response = List<DailyOutfitModel>.from(response.data.map((item) => DailyOutfitModel.fromJson(item)));
        print("Response length: ${_response.length}");
        notifyListeners();
      } else {
        _errorMessage = 'Failed to fetch data: ${response.statusCode}';
        print(_errorMessage);
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      print(_errorMessage);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
