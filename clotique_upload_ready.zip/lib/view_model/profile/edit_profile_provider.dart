import 'dart:io';
import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:mime/mime.dart';
import 'package:http_parser/http_parser.dart';

import '../../cors/services/token_storage.dart';

class EditProfileProvider extends ChangeNotifier {
  File? image;
  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (pickedFile != null) {
      image = File(pickedFile.path);
      notifyListeners();
    } else {
      print('No image selected.');
    }
  }

  bool _isLoading = false;
  bool _isUploaded = false;

  bool get isLoading => _isLoading;
  bool get isUploaded => _isUploaded;

  String name = '';
  String username = '';
  String bio = '';

  void setName(String newName) {
    name = newName;
    notifyListeners();
  }

  void setUsername(String newUsername) {
    username = newUsername;
    notifyListeners();
  }

  void setBio(String newBio) {
    bio = newBio;
    notifyListeners();
  }

  final tokenStorage = TokenStorage();

  Future<bool> updateUserDetails(String name, String username, String bio) async {

    _isLoading = true;
    notifyListeners();

    final url = Uri.parse(ApiEndPoint.updateUser);

    try {
      final accessToken = await tokenStorage.getToken();
      if (accessToken == null) {
        debugPrint('Access token not found. Cannot add item.');
        return false;
      }

      final request = http.MultipartRequest('PATCH', url);
      request.headers['Authorization'] = 'Bearer $accessToken';

      request.fields['name'] = name;
      request.fields['username'] = username;
      request.fields['bio'] = bio;

      if (image != null) {
        debugPrint('Uploading image...');
        String? mimeType = lookupMimeType(image!.path);
        String filename = path.basename(image!.path);
        request.files.add(
          await http.MultipartFile.fromPath(
            'image',
            image!.path,
            filename: filename,
            contentType: mimeType != null ? MediaType.parse(mimeType) : null,
          ),
        );

      } else {
        debugPrint('No image selected to upload.');
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      if (response.statusCode >= 200 && response.statusCode < 300) {
        debugPrint('update user details added successfully. Status: ${response.statusCode}');
        debugPrint('Response Body: $responseBody');
        _isLoading = false;
        _isUploaded = true;
        setName(name);
        setUsername(username);
        setBio(bio);
        notifyListeners();
        return true;
      } else {
        debugPrint('Failed to add details. Status: ${response.statusCode}');
        debugPrint('Request URL: ${request.url}');
        debugPrint('Request Headers: ${request.headers}');
        debugPrint('Request Fields: ${request.fields}');
        debugPrint('Response Body: $responseBody');
        _isLoading = false;
        _isUploaded = false;
        notifyListeners();
        return false;
      }
    } catch (error) {
      debugPrint('Error adding details: $error');
      _isLoading = false;
      _isUploaded = false;
      notifyListeners();
      return false;
    }
  }
}