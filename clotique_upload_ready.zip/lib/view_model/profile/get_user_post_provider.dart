import 'package:clotique/data/model/user_post/post_model.dart';
import 'package:flutter/material.dart';

import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';

class GetUserPostProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';
  PostResponse? _postResponse;


  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  PostResponse? get postResponse => _postResponse;

  final ApiService _apiService = ApiService();

  Future<void> getUserPost() async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      final response = await _apiService.get(ApiEndPoint.getUserAllPost);
      if (response.statusCode == 200) {
        _postResponse = PostResponse.fromJson(response.data);
        _isLoading = false;
        notifyListeners();
      } else {
        _errorMessage = 'Failed to fetch data: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}