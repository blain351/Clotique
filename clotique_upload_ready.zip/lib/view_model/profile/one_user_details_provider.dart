// import 'package:flutter/cupertino.dart';
// import '../../cors/services/api_services.dart';
// import '../friends/all_pending_request_provider/pending_request_provider.dart';
//
// class OneUserDetailsProvider extends ChangeNotifier {
//   bool _isLoading = false;
//   List<AllPendingRequestProvider> _pendingRequests = [];
//   String _errorMessage = '';
//
//   bool get isLoading => _isLoading;
//   List<AllPendingRequestProvider> get pendingRequests => _pendingRequests;
//   String get errorMessage => _errorMessage;
//
//   final ApiService _apiService = ApiService();
//
//   Future<void> fetchPendingRequestResponse() async {
//     try {
//       _isLoading = true;
//       _errorMessage = '';
//       notifyListeners();
//
//       final response = await _apiService.get('path_to_your_api_endpoint');
//
//       if (response.statusCode == 200) {
//         final data = response.data as List;
//         _pendingRequests = data.map((item) => AllPendingRequestProvider.fromJson(item)).toList();
//       } else {
//         _errorMessage = 'Failed to load data: ${response.statusCode}';
//       }
//
//       _isLoading = false;
//       notifyListeners();
//     } catch (e) {
//       _errorMessage = 'An error occurred: $e';
//       _isLoading = false;
//       notifyListeners();
//     }
//   }
//
//   void removeRequest(String postId) {
//     _pendingRequests.removeWhere((request) => request.id == postId);
//     notifyListeners();
//   }
// }
