import 'dart:io';
import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:mime/mime.dart';
import 'package:http_parser/http_parser.dart';

import '../../cors/services/token_storage.dart';

class EditPostProvider extends ChangeNotifier {
  File? _image;
  bool _isUploaded = false;
  bool _isLoading = false;
  String _description = '';
  String _postId = '';
  String? _audience;

  File? get image => _image;
  bool get isUploaded => _isUploaded;
  bool get isLoading => _isLoading;
  String get description => _description;
  String get postId => _postId;
  String? get audience => _audience;

  final ImagePicker _picker = ImagePicker();
  final TokenStorage _tokenStorage = TokenStorage();

  setPostId(String value) {
    _postId = value;
    notifyListeners();
  }

  setAudience(String? value) {
    _audience = value;
    notifyListeners();
  }

  void updateDescription(String newDescription) {
    _description = newDescription;
    notifyListeners();
  }

  Future<void> pickImage() async {
    try {
      final pickedFile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        _isUploaded = true;
        notifyListeners();
      } else {
        print('No image selected.');
      }
    } catch (e) {
      print('Error picking image: $e');
      _isUploaded = false;
      _image = null;
      notifyListeners();
    }
  }

  Future<bool> updateUserDetails(String description) async {
    _isLoading = true;
    notifyListeners();

    final url = Uri.parse(ApiEndPoint.editUserPostByPostId(_postId));

    try {
      final accessToken = await _tokenStorage.getToken();
      if (accessToken == null) {
        debugPrint('Access token not found. Cannot update post.');
        _isLoading = false;
        notifyListeners();
        return false;
      }

      final request = http.MultipartRequest('PATCH', url);
      request.headers['Authorization'] = 'Bearer $accessToken';
      request.fields['caption'] = description;

      request.fields['privacy'] = _audience!;

      if (_image != null) {
        debugPrint('Uploading image: ${_image!.path}');
        String? mimeType = lookupMimeType(_image!.path);
        String filename = path.basename(_image!.path);
        request.files.add(
          await http.MultipartFile.fromPath(
            'image',
            _image!.path,
            filename: filename,
            contentType: mimeType != null ? MediaType.parse(mimeType) : null,
          ),
        );
      } else {
        debugPrint('No image selected to upload.');
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      if (response.statusCode >= 200 && response.statusCode < 300) {
        debugPrint('Post updated successfully. Status: ${response.statusCode}, Body: $responseBody');
        _isLoading = false;
        _isUploaded = true;
        _description = description;
        notifyListeners();
        return true;
      } else {
        debugPrint('Failed to update post. Status: ${response.statusCode}, Body: $responseBody');
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      debugPrint('Error updating post: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  void reset() {
    _image = null;
    _isUploaded = false;
    _isLoading = false;
    _description = '';
    notifyListeners();
  }
}