import 'package:flutter/material.dart';

import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';
import '../../data/model/notification/notification_response_model.dart';

class NotificationProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;

  NotificationResponseModel? _notificationResponseModel;
  NotificationResponseModel? get notificationResponseModel => _notificationResponseModel;

  List<NotificationDataModel>? _notificationList;
  List<NotificationDataModel>? get notificationList => _notificationList;

  final ApiService _apiService = ApiService();

  Future<void> getNotifications() async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      final response = await _apiService.get(ApiEndPoint.notificationUrl);
      if (response.statusCode == 200) {
        _notificationResponseModel = NotificationResponseModel.fromJson(response.data);
        _notificationList = _notificationResponseModel?.data;
        notifyListeners();
      } else {
        _errorMessage = 'Failed to fetch data: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
