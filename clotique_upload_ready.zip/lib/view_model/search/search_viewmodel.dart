import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:clotique/cors/services/api_services.dart';
import 'package:clotique/data/model/search/search_response.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

class SearchViewModel extends ChangeNotifier {
  final ApiService _apiService = ApiService();

  String _searchQuery = '';
  String _selectedFilter = 'All'; // Track selected filter
  List<Data> _searchResults = [];
  int _currentPage = 1;
  int _totalPages = 1; // Track total pages from metadata
  final int _limit = 10; // Default limit per page
  bool _isLoading = false; // Track loading state

  String get searchQuery => _searchQuery;
  String get selectedFilter => _selectedFilter;
  List<Data> get searchResults => _searchResults;
  int get currentPage => _currentPage;
  int get totalPages => _totalPages;
  bool get isLoading => _isLoading;

  void updateSearchQuery(String query, String filter) {
    _searchQuery = query;
    _selectedFilter = filter;
    _currentPage = 1;
    _searchResults.clear();
    notifyListeners();
  }

  void updateSearchResults(List<Data> results, int totalPages) {
    _searchResults.addAll(results); // Add new results to existing ones
    _totalPages = totalPages; // Update total pages
    notifyListeners();
  }

  void clearSearch() {
    _searchQuery = '';
    _selectedFilter = 'All';
    _searchResults = [];
    _currentPage = 1;
    _totalPages = 1;
    _isLoading = false;
    notifyListeners();
  }

  Future<void> search(String query, String filter, {int page = 1}) async {
    try {
      _isLoading = true;
      notifyListeners();

      final response = await _apiService.get(
        ApiEndPoint.search,
        queryParameters: {
          'query': query,
          'type': filter.toLowerCase(), // Use filter as type
          'page': page.toString(),
          'limit': _limit.toString(),
        },
      );

      print('Searched query: $query, Filter: $filter, Page: $page');
      print('API Response: ${response.data}'); // Log the raw response

      // Check if the response data is valid
      if (response.statusCode == 200) {
        if (response.data is Map<String, dynamic> && response.data != null) {
          final searchResponse = SearchResponse.fromJson(response.data);

          // Check if searchResponse is valid
          if (searchResponse.data.isNotEmpty) {
            List<Data> results = searchResponse.data;
            updateSearchResults(results, searchResponse.metadata.pages);
            _currentPage = page; // Update current page after successful search
          } else {
            print('No data found for query: $query, filter: $filter');
          }
        } else {
          throw Exception('Unexpected response format. Expected a non-null Map<String, dynamic>, got ${response.data.runtimeType}');
        }
      } else {
        print('Invalid response status: ${response.statusCode}');
        throw Exception('Failed to load search results: status ${response.statusCode}');
      }
    } catch (e) {
      print('Search error: $e');
      throw e;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}