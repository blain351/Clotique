import 'dart:ffi';
import 'package:clotique/data/model/ai_generate/save_outfit_response.dart';
import 'package:flutter/cupertino.dart';
import 'package:dio/dio.dart';
import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';
import '../../data/model/ai_generate/ai_generate_response.dart';

class AiGenerateViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';
  AiGenerateResponse? _aiGenerateResponse;
  bool isPremium = true;
  bool _isOutfitSaved = false;
  SaveOutfitResponse? _saveOutfitResponse;

  bool get isOutfitSaved => _isOutfitSaved;
  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  AiGenerateResponse? get aiGenerateResponse => _aiGenerateResponse;
  SaveOutfitResponse? get saveOutfitResponse => _saveOutfitResponse;

  final ApiService _apiService = ApiService();

  Future<void> generateOutfit(String occasion, String prompt) async {
    // Validate inputs
    if (occasion.isEmpty) {
      _isLoading = false;
      _errorMessage = 'Please select a valid occasion.';
      debugPrint("Validation failed: Occasion is empty");
      notifyListeners();
      return;
    }
    if (prompt.trim().length < 5) {
      _isLoading = false;
      _errorMessage = 'Please provide a prompt with at least 5 characters.';
      debugPrint("Validation failed: Prompt too short");
      notifyListeners();
      return;
    }

    _isLoading = true;
    _errorMessage = '';
    debugPrint("Setting isLoading to true, notifying listeners");
    notifyListeners();

    debugPrint("AI Generate Request: Starting outfit generation with occasion: $occasion and prompt: $prompt");

    // Prepare the request body
    final Map<String, dynamic> body = {
      'occasion': occasion,
      'prompt': prompt.trim(),
    };

    try {
      // Make the API call without explicit headers, relying on Network().dio
      final response = await _apiService.post(
        ApiEndPoint.aiGenerateImage,
        data: body,
      );

      debugPrint("AI Generate Response: StatusCode: ${response.statusCode}, Data: ${response.data}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        _aiGenerateResponse = AiGenerateResponse.fromJson(response.data);
        debugPrint("Outfit generated successfully");
      } else if (response.statusCode == 500) {
        _errorMessage = 'Server error occurred while generating outfit. Please try again later.';
        debugPrint("Server error: ${response.statusCode}");
      } else {
        _errorMessage = 'Failed to generate outfit: ${response.statusCode} - ${response.data['message'] ?? 'Unknown error'}';
        debugPrint("Unexpected response: ${response.statusCode}");
      }
    } catch (e) {
      debugPrint("AI Generate Error: $e");
      _errorMessage = 'An error occurred: ${e.toString()}';
      if (e is DioException) {
        debugPrint("DioException Details: Type: ${e.type}, Message: ${e.message}, Response: ${e.response?.data}");
        if (e.response?.statusCode == 500) {
          _errorMessage = 'Server error occurred. Please try again later.';
        }
      }
    } finally {
      _isLoading = false;
      debugPrint("Setting isLoading to false, notifying listeners");
      notifyListeners();
    }
  }

  Future<void> saveOutfit(String imageId, String date) async {
    _isOutfitSaved = false;
    _errorMessage = '';
    notifyListeners();

    // Prepare the request body with the 'date' field
    final Map<String, dynamic> requestBody = {
      'date': date,
    };

    try {
      final response = await _apiService.patch(
        ApiEndPoint.saveAiGenerateImage(imageId), // your endpoint
        data: requestBody, // pass the date as part of the request body
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Parse the response data and set the SaveOutfitResponse
        _saveOutfitResponse = SaveOutfitResponse.fromJson(response.data);
        if (_saveOutfitResponse?.success == true) {
          _isOutfitSaved = true;
          debugPrint("Outfit saved successfully");
        } else {
          _errorMessage = _saveOutfitResponse?.message ?? 'Failed to save outfit: Unknown error';
          debugPrint("Failed to save outfit: ${response.statusCode}");
        }
      } else {
        _errorMessage = 'Failed to save outfit: ${response.statusCode} - ${response.data['message'] ?? 'Unknown error'}';
        debugPrint("Unexpected response: ${response.statusCode}");
      }
    } catch (e) {
      debugPrint("Save Outfit Error: $e");
      _errorMessage = 'An error occurred while saving the outfit: ${e.toString()}';
    } finally {
      notifyListeners();
    }
  }

}
