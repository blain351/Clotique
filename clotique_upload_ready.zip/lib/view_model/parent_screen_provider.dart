import 'package:clotique/views/ai_generator/screen/ai_generator_screen.dart';
import 'package:clotique/views/settings/screen/settings_screen.dart';
import 'package:flutter/material.dart';

import '../views/feed/screen/feed_screen.dart';
import '../views/home/screen/home_screen.dart';
import '../views/wardrobe/screens/wardrobe_screen.dart';

class ParentScreensProvider with ChangeNotifier {
  List<Widget> screens = [
    HomeScreen(),
    WardrobeScreen(),
    AiGeneratorScreen(),
    FeedScreen(),
    SettingsScreen(),

  ];
  int _selectedIndex = 0;
  int get selectedIndex => _selectedIndex;

  void onSelectedIndex(int selectedIndex) {
    _selectedIndex = selectedIndex;
    notifyListeners();
    debugPrint("Selected Index : $selectedIndex");
  }

  gotoFeedScreen() {
    _selectedIndex = 3;
    notifyListeners();
  }

  gotoHomeScreen() {
    _selectedIndex = 0;
    notifyListeners();
  }
}
