import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../../../cors/constant/api_end_point.dart';
import '../../../../cors/services/token_storage.dart';
import '../../cors/constant/api_end_point.dart';

class StripePaymentProvider extends ChangeNotifier {
  bool _isPaymentLoading = false;
  int _selectedPlan = 0; // 0: No plan, 1: Monthly, 2: Yearly

  bool get isPaymentLoading => _isPaymentLoading;
  int get selectedPlan => _selectedPlan;

  void setSelectedPlan(int plan) {
    _selectedPlan = plan;
    notifyListeners();
  }

  Future<void> stripePaymentMonthly(String paymentMethodId) async {
    _isPaymentLoading = true;
    notifyListeners();
    debugPrint("The monthly payment click");
    debugPrint("The payment method id is\n\n $paymentMethodId \n\n");

    final url = Uri.parse(ApiEndPoint.paymentMonthly);

    debugPrint("The url is $url");
    final TokenStorage _tokenStorage = TokenStorage();
    final String? accessToken = await _tokenStorage.getToken();

    if (accessToken == null || accessToken.isEmpty) {
      _isPaymentLoading = false;
      notifyListeners();
      throw Exception('No authentication token found. Please log in.');
    }

    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'paymentMethodId': paymentMethodId,
        }),
      );

      if (response.statusCode == 200) {
        print("Payment successful: ${response.body}");
        final responseBody = json.decode(response.body);
        final customerIdFromResponse = responseBody['customerId'];
        print("Customer ID from response: $customerIdFromResponse");
      } else {
        print("Payment failed: ${response.body}");
        throw Exception('Payment failed. Please try again later.');
      }
    } catch (e) {
      print("Error during payment: $e");
      throw Exception('Error during payment processing. Please try again.');
    } finally {
      _isPaymentLoading = false;
      notifyListeners();
    }
  }

  Future<void> stripePaymentYearly(String paymentMethodId) async {
    _isPaymentLoading = true;
    notifyListeners();

    debugPrint("The yearly payment click");

    debugPrint("The payment method id is\n\n $paymentMethodId \n\n");

    final url = Uri.parse(ApiEndPoint.paymentYearly);

    debugPrint("The url is $url");
    final TokenStorage _tokenStorage = TokenStorage();
    final String? accessToken = await _tokenStorage.getToken();

    if (accessToken == null || accessToken.isEmpty) {
      _isPaymentLoading = false;
      notifyListeners();
      throw Exception('No authentication token found. Please log in.');
    }

    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'paymentMethodId': paymentMethodId,
        }),
      );

      if (response.statusCode == 200) {
        print("Payment successful: ${response.body}");
        final responseBody = json.decode(response.body);
        final customerIdFromResponse = responseBody['customerId'];
        print("Customer ID from response: $customerIdFromResponse");
      } else {
        print("Payment failed: ${response.body}");
        throw Exception('Payment failed. Please try again later.');
      }
    } catch (e) {
      print("Error during payment: $e");
      throw Exception('Error during payment processing. Please try again.');
    } finally {
      _isPaymentLoading = false;
      notifyListeners();
    }
  }
}