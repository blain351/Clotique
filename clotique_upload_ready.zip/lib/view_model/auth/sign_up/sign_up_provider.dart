import 'package:flutter/material.dart';

import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';
import '../../../data/model/auth/sign_up_response.dart';


class SignUpProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;

  // API service
  final ApiService _apiService = ApiService();

  // Function to handle sign-up
  Future<SignUpResponse?> signUp(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      // Prepare data
      final data = {
        'email': email,
        'password': password,
      };

      final response = await _apiService.post(
        ApiEndPoint.register,
        data: data,
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        _isLoading = false;
        notifyListeners();
        return SignUpResponse.fromJson(response.data);
      } else {
        _errorMessage = 'Failed to sign up, please try again later.';
        _isLoading = false;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isLoading = false; 
      notifyListeners();
    }
    return null;
  }
}
