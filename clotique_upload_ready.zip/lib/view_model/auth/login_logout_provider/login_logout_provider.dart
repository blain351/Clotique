import 'dart:convert';
import 'package:clotique/cors/services/user_email_storage.dart';
import 'package:clotique/cors/services/user_id_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart'; // Import provider package
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../cors/services/token_storage.dart';
import '../../../data/model/auth/login_user_model.dart';
import '../check_me/user_details_provider.dart';
import 'package:flutter/material.dart';

class LoginLogoutProvider extends ChangeNotifier {
  late bool _isPasswordVisible = false;
  bool get isPasswordVisible => _isPasswordVisible;
  String _errorMessage = '';
  String get errorMessage => _errorMessage;
  final TokenStorage tokenStorage = TokenStorage();
  final UserIdStorage userIdStorage = UserIdStorage();

  void togglePasswordVisibility() {
    _isPasswordVisible = !_isPasswordVisible;
    notifyListeners();
  }

  bool _isLoading = false;
  bool get isLoading => _isLoading;
  bool _isVerifyLoading = false;
  bool get isVerifyLoading => _isVerifyLoading;

  UserModel? _userModel;
  UserModel? get userModel => _userModel;

  Future<void> userLogin(context, String email, String password) async {
    final url = Uri.parse(ApiEndPoint.login);
    _isLoading = true;
    notifyListeners();

    try {
      final response = await http.post(
        url,
        body: {"email": email, "password": password},
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        debugPrint('Login request successful ${response.body}');

        final responseData = json.decode(response.body);
        _userModel = UserModel.fromJson(responseData);

        if (_userModel!.twoFactorRequired == true) {
          await userIdStorage.saveUserId(_userModel!.id);
          Navigator.pushNamed(context, RouteName.verify2faOtpScreen);

        } else {
          String token = responseData['authorization']['token'];
          String userToken = _userModel!.token;

          await tokenStorage.saveToken(userToken);

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Login Successfully'),
              backgroundColor: Colors.green,
            ),
          );
          await Navigator.pushNamed(context, RouteName.parentScreen);
          debugPrint('Token: $token');
          debugPrint('User Token: $userToken');
          UserEmailStorage.saveUserEmail(email);
        }
      } else {
        _errorMessage = 'Failed to login: ${response.statusCode}';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Login Failed'),
            backgroundColor: Colors.green,
          ),
        );
        if (_userModel != null) {
          debugPrint('Error: code: ${response.statusCode}, status message: ${_userModel!.message}');
        } else {
          debugPrint('Error: code: ${response.statusCode}, message: No response from API');
        }
      }

      _isLoading = false;
      notifyListeners();
    } catch (error) {
      _errorMessage = 'An error occurred: $error';
      debugPrint('An error occurred: $error');
      _isLoading = false;
      notifyListeners();
    }
  }

  String _otp = '';

  String get otp => _otp;

  void setOtp(String value) {
    _otp = value;
    notifyListeners();
  }

  Future<bool> userLoginWith2faOtp(context) async {
    final url = Uri.parse(ApiEndPoint.loginWith2faOtp);
    _isVerifyLoading = true;
    notifyListeners();

    final userId = await userIdStorage.getUserId();

    try {
      final response = await http.post(
        url,
        body: {"user_id": userId, "otp": otp},
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        debugPrint('Login request successful ${response.body}');

        final responseData = json.decode(response.body);
        _userModel = UserModel.fromJson(responseData);
        String token = responseData['authorization']['token'];
        String userToken = _userModel!.token;
        await tokenStorage.saveToken(userToken);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Login Successfully'),
            backgroundColor: Colors.green,
          ),
        );
        await Navigator.pushNamed(context, RouteName.parentScreen);
        debugPrint('Token: $token');
        debugPrint('User Token: $userToken');
        return true;
      } else {
        _errorMessage = 'Failed to login: ${response.statusCode}';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Login Failed'),
            backgroundColor: Colors.green,
          ),
        );
        if (_userModel != null) {
          debugPrint('Error: code: ${response.statusCode}, status message: ${_userModel!.message}');
        } else {
          debugPrint('Error: code: ${response.statusCode}, message: No response from API');
        }
      }

      _isVerifyLoading = false;
      notifyListeners();
    } catch (error) {
      _errorMessage = 'An error occurred: $error';
      debugPrint('An error occurred: $error');
      _isVerifyLoading = false;
      notifyListeners();
    }
    return false;
  }

  Future<void> logOut() async {
    await tokenStorage.clearToken();
    await userIdStorage.clearUserId();
  }
}
