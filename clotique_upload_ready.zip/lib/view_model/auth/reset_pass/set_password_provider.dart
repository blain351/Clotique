import 'package:flutter/material.dart';
import '../../../../../../cors/routes/routes_name.dart';
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';

class SetPasswordProvider extends ChangeNotifier {
  String _password = '';
  String _confirmPassword = '';
  bool _passwordVisible = false;
  bool _confirmPasswordVisible = false;

  String get password => _password;
  String get confirmPassword => _confirmPassword;
  bool get passwordVisible => _passwordVisible;
  bool get confirmPasswordVisible => _confirmPasswordVisible;

  void setPassword(String value) {
    _password = value;
    notifyListeners();
  }

  void setConfirmPassword(String value) {
    _confirmPassword = value;
    notifyListeners();
  }

  void togglePasswordVisibility() {
    _passwordVisible = !_passwordVisible;
    notifyListeners();
  }

  void toggleConfirmPasswordVisibility() {
    _confirmPasswordVisible = !_confirmPasswordVisible;
    notifyListeners();
  }

  bool get isStrongPassword =>
      _password.length >= 8 &&
          RegExp(r'[A-Z]').hasMatch(_password) &&
          RegExp(r'[0-9]').hasMatch(_password) &&
          RegExp(r'[!@#\$&*~]').hasMatch(_password);

  bool get passwordsMatch => _password == _confirmPassword;

  bool get isFormValid => isStrongPassword && passwordsMatch;

  List<InlineSpan> get passwordValidationSpans {
    return [
      TextSpan(
        text: '• At least 8 characters\n',
        style: TextStyle(
          color: _password.length >= 8 ? Colors.green : Colors.red,
          fontSize: 12,
        ),
      ),
      TextSpan(
        text: '• At least one uppercase letter\n',
        style: TextStyle(
          color: RegExp(r'[A-Z]').hasMatch(_password) ? Colors.green : Colors.red,
          fontSize: 12,
        ),
      ),
      TextSpan(
        text: '• At least one number\n',
        style: TextStyle(
          color: RegExp(r'[0-9]').hasMatch(_password) ? Colors.green : Colors.red,
          fontSize: 12,
        ),
      ),
      TextSpan(
        text: '• At least one special character (!@#\$&*~)',
        style: TextStyle(
          color: RegExp(r'[!@#\$&*~]').hasMatch(_password) ? Colors.green : Colors.red,
          fontSize: 12,
        ),
      ),
    ];
  }

  Future<void> reset(context, String email, String token, String password) async {
    if (isFormValid && passwordsMatch) {
      final result = await resetPassword(email, token, password);
      if (result) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          Navigator.pushNamedAndRemoveUntil(
            context,
            RouteName.loginScreen,
            (route) => false,
          );
        });
      }
    }
  }

  bool _isLoading = false;
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  Future<bool> resetPassword(String email, String token, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      // Prepare data
      final data = {
        "email" : email,
        "token" :  token,
        "password" : password
      };

      final response = await _apiService.post(
        ApiEndPoint.otpVerifyAndResetPassword,
        data: data,
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        _isLoading = false;
        notifyListeners();
        final success = response.data['success'];
        return success;

      } else {
        _errorMessage = 'Failed to reset the password, please try again.';
        _isLoading = false;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
    }
    return false;
  }
}
