import 'package:flutter/cupertino.dart';
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';
import '../../../data/model/friends/reject_request/reject_request_response.dart';

class RejectedRequestProvider extends ChangeNotifier {
  bool _isLoading = false;
  RejectedRequestResponse? _response;
  String _errorMessage = '';
  final Function(String) removeRequestFromPendingList;

  bool get isLoading => _isLoading;
  RejectedRequestResponse? get response => _response;
  String get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  RejectedRequestProvider({required this.removeRequestFromPendingList});

  static String reject(String postId) =>
      '${ApiEndPoint.baseUrl}/friendships/respond/$postId';

  Future<void> fetchRejectedRequest(String postId) async {
    debugPrint('Starting fetchRejectedRequest for postId: $postId');
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final url = reject(postId);
      debugPrint('API URL: $url');

      final response = await _apiService.post(url);

      debugPrint(
          'Response received: statusCode = ${response.statusCode}, data = ${response.data}');

      _isLoading = false;

      // Handle the response based on status code
      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data != null && response.data is Map<String, dynamic>) {
          _response = RejectedRequestResponse.fromJson(response.data);
          debugPrint('Parsed response: ${_response!.toJson()}');

          removeRequestFromPendingList(postId);
        } else {
          _errorMessage = 'Empty or invalid response format';
          debugPrint('Error: $_errorMessage');
        }
      } else if (response.statusCode == 204) {
        _errorMessage = 'No content returned from server';
        debugPrint('Error: $_errorMessage');
      } else {
        _errorMessage = 'Failed to load data: ${response.statusCode}';
        debugPrint('Error: $_errorMessage');
      }

      notifyListeners();
    } catch (e) {
      debugPrint('Exception caught: $e');
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
    }
  }
}
