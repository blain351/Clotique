import 'dart:convert';

import 'package:flutter/material.dart';
import '../../../cors/services/api_services.dart'; // Ensure ApiService is available
import '../../../cors/constant/api_end_point.dart';  // Ensure ApiEndPoint is correctly imported
import '../../../data/model/friends/all_pending_friend_request_response/request_pending_response.dart'; // Ensure the correct model is imported

class AllPendingRequestProvider extends ChangeNotifier {
  AllPendingRequestProvider() {
    fetchAllPendingRequests();
  }

  bool _isLoading = false;
  List<AllPendingFriendRequestResponsse> _pendingRequests = [];
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  List<AllPendingFriendRequestResponsse> get pendingRequests => _pendingRequests;
  String get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  // Method to remove a request from the pending requests list
  void removeRequestFromPendingList(String requestId) {
    // Remove the request from the list by matching the id
    _pendingRequests.removeWhere((request) => request.id == requestId);
    notifyListeners(); // Notify listeners to update the UI
  }

  Future<void> fetchAllPendingRequests() async {
    debugPrint('Fetching pending requests...');
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final response = await _apiService.get(ApiEndPoint.pendingRequests);
      debugPrint('Response data type: ${response.data.runtimeType}');

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data is List<dynamic>) {
          final List<dynamic> data = response.data;
          _pendingRequests = data
              .map((jsonItem) => AllPendingFriendRequestResponsse.fromJson(jsonItem as Map<String, dynamic>))
              .toList();
        } else if (response.data is String) {
          final List<dynamic> data = json.decode(response.data);
          _pendingRequests = data
              .map((jsonItem) => AllPendingFriendRequestResponsse.fromJson(jsonItem as Map<String, dynamic>))
              .toList();
        } else {
          _errorMessage = 'Unexpected response data format';
        }

        debugPrint('Pending requests loaded: ${_pendingRequests.length} items');
      } else {
        _errorMessage = 'Failed to load pending requests: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      debugPrint('Error fetching pending requests: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
