import 'package:flutter/material.dart';
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';
import '../../../data/model/friends/unblock/unblock_response.dart';

class UnblockProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  ServerErrorResponse? _response;
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  ServerErrorResponse? get response => _response;
  String get errorMessage => _errorMessage;

  static String unblock(String userId) => '${ApiEndPoint.baseUrl}/blocks/$userId';

  Future<void> fetchUnblockUser(String userId) async {
    debugPrint('Starting unblock for user: $userId');

    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final url = unblock(userId);
      debugPrint('API URL: $url');

      final response = await _apiService.delete(url);

      debugPrint('Response received: statusCode = ${response.statusCode}, data = ${response.data}');

      _isLoading = false;

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data is Map<String, dynamic>) {
          _response = ServerErrorResponse.fromJson(response.data);
          debugPrint('Parsed response: ${_response!.toJson()}');
        } else {
          _errorMessage = 'Unexpected data format: ${response.data.runtimeType}';
          debugPrint('Error: $_errorMessage');
        }
      } else {
        _errorMessage = 'Failed to unblock user: ${response.statusCode}';
        debugPrint('Error: $_errorMessage');
      }

      notifyListeners();
    } catch (e) {
      debugPrint('Exception caught: $e');
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
    }
  }
}
