import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';
import '../../../data/model/friends/suggestions/single_user_suggestion_provider_response.dart'; // Ensure model is imported

class SingleUserSuggestionFriendProvider extends ChangeNotifier {
  SingleUserSuggestionFriendProvider() {
    fetchSingleUserSuggestionFriend();
  }

  bool _isLoading = false;
  List<SingleUserSuggestionFriendResponse> _suggestions = [];
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  List<SingleUserSuggestionFriendResponse> get suggestions => _suggestions;
  String get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  // Fetching single user friend suggestions from API
  Future<void> fetchSingleUserSuggestionFriend() async {
    debugPrint('Fetching single user friend suggestions...');
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      // API call to fetch suggestions
      final response = await _apiService.get(ApiEndPoint.suggestion);
      debugPrint('Response data type: ${response.data.runtimeType}');

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data is List<dynamic>) {
          final List<dynamic> data = response.data;
          _suggestions = data
              .map((jsonItem) => SingleUserSuggestionFriendResponse.fromJson(jsonItem as Map<String, dynamic>))
              .toList();
        } else if (response.data is String) {
          final List<dynamic> data = json.decode(response.data);
          _suggestions = data
              .map((jsonItem) => SingleUserSuggestionFriendResponse.fromJson(jsonItem as Map<String, dynamic>))
              .toList();
        } else {
          _errorMessage = 'Unexpected response data format';
        }

        debugPrint('Suggestions loaded: ${_suggestions.length} items');
      } else {
        _errorMessage = 'Failed to load suggestions: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      debugPrint('Error fetching suggestions: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
