import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';
import '../../data/model/user_feed/user_feed_response.dart';

class FeedViewModel extends ChangeNotifier {
  final int _limit = 12;
  int get limit => _limit;

  int _currentPage = 0;
  int get currentPage => _currentPage;

  int? _lastPage;
  int? get lastPage => _lastPage;

  bool _inProgress = false;
  bool get inProgress => _inProgress;

  bool _initialLoadingInProgress = false;
  bool get initialLoadingInProgress => _initialLoadingInProgress;

  String _errorMessage = '';
  String get errorMessage => _errorMessage;

  List<FeedData> _feedList = [];
  List<FeedData> get feedList => _feedList;

  final ApiService _apiService = ApiService();

  Future<void> userFeed() async {
    if (_lastPage != null && _currentPage >= _lastPage!) {
      debugPrint('No more data to load');
      return;
    }

    _currentPage++;
    debugPrint('Fetching page: $_currentPage');

    if (_currentPage == 1) {
      _feedList.clear();
      _initialLoadingInProgress = true;
    } else {
      _inProgress = true;
    }
    notifyListeners();

    final url = ApiEndPoint.feed(_currentPage, _limit);

    try {
      final apiResponse = await _apiService.get(url);

      if (apiResponse.statusCode == 200 || apiResponse.statusCode == 201) {
        if (apiResponse.data is Map<String, dynamic>) {
          final feedResponse = FeedResponse.fromJson(apiResponse.data);
          if (feedResponse.success) {
            _lastPage = feedResponse.pagination.totalPages;
            _feedList.addAll(feedResponse.data);
            _errorMessage = '';
          } else {
            _errorMessage = feedResponse.message.isNotEmpty
                ? feedResponse.message
                : 'Failed to fetch feed';
          }
        } else {
          _errorMessage = 'Unexpected response format: data is not a Map';
        }
      } else {
        _errorMessage =
        'Failed to fetch feed, status code: ${apiResponse.statusCode}';
      }
    } on DioException catch (e) {
      _errorMessage = _handleDioError(e);
    } catch (e, stackTrace) {
      _errorMessage = 'An unexpected error occurred: $e';
      debugPrint('Error: $e\nStackTrace: $stackTrace');
    } finally {
      if (_currentPage == 1) {
        _initialLoadingInProgress = false;
      }
      _inProgress = false;
      debugPrint('Last page: $_lastPage, Feed list length: ${_feedList.length}');
      notifyListeners();
    }
  }

  String _handleDioError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
        return 'Connection timeout. Please check your internet connection.';
      case DioExceptionType.receiveTimeout:
        return 'Server response timeout. Please try again later.';
      case DioExceptionType.badResponse:
        return 'Server error: ${e.response?.statusCode} ${e.response?.statusMessage}';
      case DioExceptionType.cancel:
        return 'Request was cancelled';
      default:
        return 'An error occurred: ${e.message}';
    }
  }

  Future<void> refreshFeed() async {
    _currentPage = 0;
    _feedList.clear();
    _lastPage = null;
    _errorMessage = '';
    await userFeed();
  }

  FeedData? getPostById(String postId) {
    try {
      return _feedList.firstWhere(
            (post) => post.id == postId,
        orElse: () => FeedData(
          id: 'defaultId',
          caption: 'Post not found',
          image: '',
          createdAt: '',
          createTimeAgo: '',
          privacy: 'All',
          user: null,
          likeCount: 0,
          commentCount: 0,
          shareCount: 0,
          shareUserIds: [],
        ),
      );
    } catch (e) {
      debugPrint('Error finding post by ID: $e');
      return null;
    }
  }

  void updateLikeCount(String postId, int newLikeCount) {
    final postIndex = _feedList.indexWhere((post) => post.id == postId);
    if (postIndex != -1) {
      _feedList[postIndex] = FeedData(
        id: _feedList[postIndex].id,
        caption: _feedList[postIndex].caption,
        image: _feedList[postIndex].image,
        createdAt: _feedList[postIndex].createdAt,
        createTimeAgo: _feedList[postIndex].createTimeAgo,
        privacy: _feedList[postIndex].privacy,
        user: _feedList[postIndex].user,
        likeCount: newLikeCount,
        commentCount: _feedList[postIndex].commentCount,
        shareCount: _feedList[postIndex].shareCount,
        shareUserIds: _feedList[postIndex].shareUserIds,
      );
      notifyListeners();
    }
  }

  // New method to update comment count
  updateCommentCount(String postId, int newCommentCount) {
    final postIndex = _feedList.indexWhere((post) => post.id == postId);
    if (postIndex != -1) {
      _feedList[postIndex] = FeedData(
        id: _feedList[postIndex].id,
        caption: _feedList[postIndex].caption,
        image: _feedList[postIndex].image,
        createdAt: _feedList[postIndex].createdAt,
        createTimeAgo: _feedList[postIndex].createTimeAgo,
        privacy: _feedList[postIndex].privacy,
        user: _feedList[postIndex].user,
        likeCount: _feedList[postIndex].likeCount,
        commentCount: newCommentCount,
        shareCount: _feedList[postIndex].shareCount,
        shareUserIds: _feedList[postIndex].shareUserIds,
      );
      notifyListeners();
    }
  }
}