import 'package:clotique/data/model/user_feed/create_comment_response_model.dart';
import 'package:flutter/material.dart';

import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';

class CreateCommentProvider extends ChangeNotifier {

  bool _isLoading = false;
  String _errorMessage = '';
  CreateCommentResponseModel? _createCommentResponseModel;
  String _postId = '';


  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  CreateCommentResponseModel? get createCommentResponseModel => _createCommentResponseModel;
  String get postId => _postId;

  void setSelectedPostId(String value) {
    _postId = value;
    notifyListeners();
  }

  final ApiService _apiService = ApiService();

  Future<bool> commentPost(String postId, String content) async {
    try {
      _isLoading = true;
      notifyListeners();

      final data = {
        'content': content,
      };

      final response = await _apiService.post(
        ApiEndPoint.createComment(postId),
        data: data
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        _isLoading = false;
        notifyListeners();
        if (response.data['success']) {
          _createCommentResponseModel = CreateCommentResponseModel.fromJson(response.data);
          notifyListeners();
          return true;
        }
      } else {
        _errorMessage = 'Failed to post comment, status code: ${response.statusCode}';
        _isLoading = false;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isLoading = false; //bgd3649233
      notifyListeners();
    }
    return false;
  }

  
}