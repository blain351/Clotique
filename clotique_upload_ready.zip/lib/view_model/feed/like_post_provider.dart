import 'package:flutter/material.dart';
import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';

class LikePostProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool _isGetLoading = false;
  String _errorMessage = '';
  String _getErrorMessage = '';
  int? _likeCount;
  bool? _isLiked;

  bool get isLoading => _isLoading;
  bool get isGetLoading => _isGetLoading;
  String get errorMessage => _errorMessage;
  String get getErrorMessage => _getErrorMessage;
  int? get likeCount => _likeCount;
  bool? get isLiked => _isLiked;

  // API service
  final ApiService _apiService = ApiService();

  /// Function to handle like/unlike post
  Future<bool> likePost(String postId) async {
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final response = await _apiService.post(
        ApiEndPoint.likePost(postId),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data['success']) {
          _isLiked = response.data['message'] == 'Post liked successfully';
          _isLoading = false;
          notifyListeners();
          return true;
        } else {
          _errorMessage = response.data['message'] ?? 'Failed to like/unlike post';
          _isLoading = false;
          notifyListeners();
          return false;
        }
      } else {
        _errorMessage = 'Failed to like/unlike post. Status: ${response.statusCode}';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Function to fetch like count
  Future<bool> getLikeCount(String postId) async {
    try {
      _isGetLoading = true;
      _getErrorMessage = '';
      notifyListeners();

      final response = await _apiService.get(
        ApiEndPoint.getLikePost(postId),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data['success']) {
          _likeCount = response.data['totalLikes'] ?? 0;
          _isGetLoading = false;
          notifyListeners();
          return true;
        } else {
          _getErrorMessage = response.data['message'] ?? 'Failed to fetch like count';
          _isGetLoading = false;
          notifyListeners();
          return false;
        }
      } else {
        _getErrorMessage = 'Failed to fetch like count. Status: ${response.statusCode}';
        _isGetLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _getErrorMessage = 'An error occurred: $e';
      _isGetLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Optionally, fetch initial like state for a post
  Future<void> fetchInitialState(String postId) async {
    await getLikeCount(postId);
  }
}