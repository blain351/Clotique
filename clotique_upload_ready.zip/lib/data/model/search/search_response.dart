class SearchResponse {
  final List<Data> data;
  final Metadata metadata;

  SearchResponse({
    required this.data,
    required this.metadata,
  });

  factory SearchResponse.fromJson(Map<String, dynamic> json) {
    return SearchResponse(
      data: List<Data>.from((json['data'] as List<dynamic>).map((x) => Data.fromJson(x as Map<String, dynamic>))),
      metadata: Metadata.fromJson(json['metadata'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'data': List<dynamic>.from(data.map((x) => x.toJson())),
      'metadata': metadata.toJson(),
    };
  }
}

class Data {
  final String id;
  final String? username;
  final String? email;
  final String? avatar;
  final String? bio;
  final String? caption;
  final String? image;
  final String? createdAt;
  final String? userId;
  final User? user;
  final List<Comment> comments;
  final Count count;

  Data({
    required this.id,
    this.username,
    this.email,
    this.avatar,
    this.bio,
    this.caption,
    this.image,
    this.createdAt,
    this.userId,
    this.user,
    required this.comments,
    required this.count,
  });

  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(
      id: json['id'] as String? ?? '',
      username: json['username'] as String?,
      email: json['email'] as String?,
      avatar: json['avatar'] as String?,
      bio: json['bio'] as String?,
      caption: json['caption'] as String?,
      image: json['image'] as String?,
      createdAt: json['created_at'] as String?,
      userId: json['user_id'] as String?,
      user: json['user'] != null ? User.fromJson(json['user'] as Map<String, dynamic>) : null,
      comments: json['comments'] != null
          ? List<Comment>.from((json['comments'] as List<dynamic>).map((x) => Comment.fromJson(x as Map<String, dynamic>)))
          : [],
      count: json['_count'] != null
          ? Count.fromJson(json['_count'] as Map<String, dynamic>)
          : const Count(likes: 0, comments: 0, shares: 0), // Default for users
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'email': email,
      'avatar': avatar,
      'bio': bio,
      'caption': caption,
      'image': image,
      'created_at': createdAt,
      'user_id': userId,
      'user': user?.toJson(),
      'comments': List<dynamic>.from(comments.map((x) => x.toJson())),
      '_count': count.toJson(),
    };
  }
}

class User {
  final String id;
  final String? email;
  final String? username;
  final String? avatar;

  User({
    required this.id,
    this.email,
    this.username,
    this.avatar,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as String? ?? '',
      email: json['email'] as String?,
      username: json['username'] as String?,
      avatar: json['avatar'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'username': username,
      'avatar': avatar,
    };
  }
}

class Comment {
  final String id;
  final String content;
  final User user;

  Comment({
    required this.id,
    required this.content,
    required this.user,
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      id: json['id'] as String? ?? '',
      content: json['content'] as String? ?? '',
      user: User.fromJson(json['user'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'user': user.toJson(),
    };
  }
}

class Count {
  final int likes;
  final int comments;
  final int shares;

  const Count({
    required this.likes,
    required this.comments,
    required this.shares,
  });

  factory Count.fromJson(Map<String, dynamic> json) {
    return Count(
      likes: json['likes'] as int? ?? 0,
      comments: json['comments'] as int? ?? 0,
      shares: json['shares'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'likes': likes,
      'comments': comments,
      'shares': shares,
    };
  }
}

class Metadata {
  final int total;
  final int page;
  final int limit;
  final int pages;

  Metadata({
    required this.total,
    required this.page,
    required this.limit,
    required this.pages,
  });

  factory Metadata.fromJson(Map<String, dynamic> json) {
    return Metadata(
      total: json['total'] as int? ?? 0,
      page: json['page'] as int? ?? 1,
      limit: json['limit'] as int? ?? 10,
      pages: json['pages'] as int? ?? 1,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'total': total,
      'page': page,
      'limit': limit,
      'pages': pages,
    };
  }
}