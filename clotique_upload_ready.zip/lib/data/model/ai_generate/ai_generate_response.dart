class AiGenerateResponse {
  bool? success;
  String? imageUrl;
  String? outfitId;
  List<String>? itemsUsed;
  String? promptUsed;
  bool? isTemporary;
  TempOutfit? tempOutfit;

  AiGenerateResponse(
      {this.success,
        this.imageUrl,
        this.outfitId,
        this.itemsUsed,
        this.promptUsed,
        this.isTemporary,
        this.tempOutfit});

  AiGenerateResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    imageUrl = json['imageUrl'];
    outfitId = json['outfitId'];
    itemsUsed = json['itemsUsed'].cast<String>();
    promptUsed = json['promptUsed'];
    isTemporary = json['isTemporary'];
    tempOutfit = json['tempOutfit'] != null
        ? new TempOutfit.fromJson(json['tempOutfit'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['imageUrl'] = this.imageUrl;
    data['outfitId'] = this.outfitId;
    data['itemsUsed'] = this.itemsUsed;
    data['promptUsed'] = this.promptUsed;
    data['isTemporary'] = this.isTemporary;
    if (this.tempOutfit != null) {
      data['tempOutfit'] = this.tempOutfit!.toJson();
    }
    return data;
  }
}

class TempOutfit {
  String? id;
  String? description;
  String? image;
  String? createdDate;
  bool? isFavorite;
  bool? isSaved;
  Null? outfitDate;
  bool? aigenerate;
  String? userId;
  String? expiresAt;
  Null? savedateAt;

  TempOutfit(
      {this.id,
        this.description,
        this.image,
        this.createdDate,
        this.isFavorite,
        this.isSaved,
        this.outfitDate,
        this.aigenerate,
        this.userId,
        this.expiresAt,
        this.savedateAt});

  TempOutfit.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    description = json['description'];
    image = json['image'];
    createdDate = json['createdDate'];
    isFavorite = json['isFavorite'];
    isSaved = json['isSaved'];
    outfitDate = json['outfitDate'];
    aigenerate = json['aigenerate'];
    userId = json['user_id'];
    expiresAt = json['expiresAt'];
    savedateAt = json['savedateAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['description'] = this.description;
    data['image'] = this.image;
    data['createdDate'] = this.createdDate;
    data['isFavorite'] = this.isFavorite;
    data['isSaved'] = this.isSaved;
    data['outfitDate'] = this.outfitDate;
    data['aigenerate'] = this.aigenerate;
    data['user_id'] = this.userId;
    data['expiresAt'] = this.expiresAt;
    data['savedateAt'] = this.savedateAt;
    return data;
  }
}
