class CommentModel {
  final String id;
  final String content;
  final String createdAt;
  final String timeAgo;
  final User user;
  final List<dynamic> replies;

  CommentModel({
    required this.id,
    required this.content,
    required this.createdAt,
    required this.timeAgo,
    required this.user,
    required this.replies,
  });

  factory CommentModel.fromJson(Map<String, dynamic> json) {
    return CommentModel(
      id: json['id'] ?? '',
      content: json['content'] ?? '',
      createdAt: json['created_at'] ?? '',
      timeAgo: json['time_ago'] ?? '',
      user: User.fromJson(json['user'] ?? {}),
      replies: json['replies'] ?? [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'created_at': createdAt,
      'time_ago': timeAgo,
      'user': user.toJson(),
      'replies': replies,
    };
  }
}

class User {
  final String id;
  final String? username;
  final String? avatar;

  User({
    required this.id,
    this.username,
    this.avatar,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] ?? '',
      username: json['username'] ?? 'Unknown',
      avatar: json['avatar'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'avatar': avatar,
    };
  }
}

