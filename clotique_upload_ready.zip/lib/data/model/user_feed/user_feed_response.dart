// Define the User model
class User {
  final String id;
  final String? username;
  final String? avatar;

  User({
    required this.id,
    this.username,
    this.avatar,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      username: json['username'],
      avatar: json['avatar'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'avatar': avatar,
    };
  }
}

// Define the FeedData model
class FeedData {
  final String id;
  final String caption;
  final String image;
  final String createdAt;
  final String createTimeAgo;
  final String privacy;
  final User? user;
  int likeCount;
  final int commentCount;
  final int shareCount;
  final List<String> shareUserIds;

  FeedData({
    required this.id,
    required this.caption,
    required this.image,
    required this.createdAt,
    required this.createTimeAgo,
    required this.privacy,
    this.user,
    this.likeCount = 0,
    required this.commentCount,
    required this.shareCount,
    required this.shareUserIds,
  });

  factory FeedData.fromJson(Map<String, dynamic> json) {
    return FeedData(
      id: json['id'],
      caption: json['caption'],
      image: json['image'],
      createdAt: json['created_at'],
      createTimeAgo: json['create_time_ago'],
      privacy: json['privacy'],
      user: json['user'] != null ? User.fromJson(json['user']) : null,
      likeCount: json['like_count'] is int
          ? json['like_count']
          : int.tryParse(json['like_count'].toString()) ?? 0,
      commentCount: json['comment_count'] is int
          ? json['comment_count']
          : int.tryParse(json['comment_count'].toString()) ?? 0,
      shareCount: json['share_count'] is int
          ? json['share_count']
          : int.tryParse(json['share_count'].toString()) ?? 0,
      shareUserIds: List<String>.from(json['share_user_ids']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'caption': caption,
      'image': image,
      'created_at': createdAt,
      'create_time_ago': createTimeAgo,
      'privacy': privacy,
      'user': user?.toJson(),
      'like_count': likeCount,
      'comment_count': commentCount,
      'share_count': shareCount,
      'share_user_ids': shareUserIds,
    };
  }
}

// Define the Pagination model
class Pagination {
  final int totalItems;
  final int currentPage;
  final int pageSize;
  final int totalPages;
  final int currentItemsOnPage;

  Pagination({
    required this.totalItems,
    required this.currentPage,
    required this.pageSize,
    required this.totalPages,
    required this.currentItemsOnPage,
  });

  factory Pagination.fromJson(Map<String, dynamic> json) {
    return Pagination(
      totalItems: json['totalItems'] is int
          ? json['totalItems']
          : int.tryParse(json['totalItems'].toString()) ?? 0,
      currentPage: json['currentPage'] is int
          ? json['currentPage']
          : int.tryParse(json['currentPage'].toString()) ?? 1,
      pageSize: json['pageSize'] is int
          ? json['pageSize']
          : int.tryParse(json['pageSize'].toString()) ?? 10,
      totalPages: json['totalPages'] is int
          ? json['totalPages']
          : int.tryParse(json['totalPages'].toString()) ?? 1,
      currentItemsOnPage: json['currentItemsOnPage'] is int
          ? json['currentItemsOnPage']
          : int.tryParse(json['currentItemsOnPage'].toString()) ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'totalItems': totalItems,
      'currentPage': currentPage,
      'pageSize': pageSize,
      'totalPages': totalPages,
      'currentItemsOnPage': currentItemsOnPage,
    };
  }
}

// Define the FeedResponse model
class FeedResponse {
  final bool success;
  final String message;
  final List<FeedData> data;
  final Pagination pagination;

  FeedResponse({
    required this.success,
    required this.message,
    required this.data,
    required this.pagination,
  });

  factory FeedResponse.fromJson(Map<String, dynamic> json) {
    return FeedResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      data: json['data'] != null && json['data']['feed'] != null
          ? List<FeedData>.from(
        json['data']['feed'].map((item) => FeedData.fromJson(item)),
      )
          : [],
      pagination: json['data'] != null && json['data']['pagination'] != null
          ? Pagination.fromJson(json['data']['pagination'])
          : Pagination(
        totalItems: 0,
        currentPage: 1,
        pageSize: 10,
        totalPages: 1,
        currentItemsOnPage: 0,
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message,
      'data': {
        'feed': data.map((item) => item.toJson()).toList(),
        'pagination': pagination.toJson(),
      },
    };
  }
}