class RequestPendingResponse {
  final String id;
  final String? createdAt;
  final String? updatedAt;
  final String requesterId;
  final String recipientId;
  final String status;
  final Requester requester;

  RequestPendingResponse({
    required this.id,
    this.createdAt,
    this.updatedAt,
    required this.requesterId,
    required this.recipientId,
    required this.status,
    required this.requester,
  });

  factory RequestPendingResponse.fromJson(Map<String, dynamic> json) {
    return RequestPendingResponse(
      id: json['id'] ?? '',
      createdAt: json['createdAt'],
      updatedAt: json['updatedAt'],
      requesterId: json['requesterId'] ?? '',
      recipientId: json['recipientId'] ?? '',
      status: json['status'] ?? '',
      requester: Requester.fromJson(json['requester'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'requesterId': requesterId,
      'recipientId': recipientId,
      'status': status,
      'requester': requester.toJson(),
    };
  }
}

class Requester {
  final String id;
  final String email;
  final String? username;
  final String? name;
  final String? firstName;
  final String? lastName;
  final int status;
  final String? avatar;
  final String? country;
  final String subscriptionStatus;
  final String subscriptionType;

  Requester({
    required this.id,
    required this.email,
    required this.status,
    required this.subscriptionStatus,
    required this.subscriptionType,
    this.username,
    this.name,
    this.firstName,
    this.lastName,
    this.avatar,
    this.country,
  });

  factory Requester.fromJson(Map<String, dynamic> json) {
    return Requester(
      id: json['id'] ?? '',
      email: json['email'] ?? '',
      status: json['status'] ?? 0,
      subscriptionStatus: json['subscription_status'] ?? '',
      subscriptionType: json['subscription_type'] ?? '',
      username: json['username'],
      name: json['name'],
      firstName: json['first_name'],
      lastName: json['last_name'],
      avatar: json['avatar'],
      country: json['country'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'status': status,
      'subscription_status': subscriptionStatus,
      'subscription_type': subscriptionType,
      'username': username,
      'name': name,
      'first_name': firstName,
      'last_name': lastName,
      'avatar': avatar,
      'country': country,
    };
  }
}
