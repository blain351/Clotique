class BlockListResponse {
  final String id;
  final String createdAt;
  final String updatedAt;
  final BlockedUser? blocked;

  BlockListResponse({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    this.blocked,
  });

  factory BlockListResponse.fromJson(Map<String, dynamic> json) {
    return BlockListResponse(
      id: json['id'] ?? '',
      createdAt: json['createdAt'] ?? '',
      updatedAt: json['updatedAt'] ?? '',
      blocked: json['blocked'] != null
          ? BlockedUser.fromJson(json['blocked'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'blocked': blocked?.toJson(),
    };
  }
}

class BlockedUser {
  final String id;
  final String createdAt;
  final String updatedAt;
  final String? email;
  final String? username;
  final String? name;
  final String? firstName;
  final String? lastName;
  final String? bio;
  final String? domain;
  final String? avatar;
  final String? country;
  final String? state;
  final String? city;
  final String? gender;
  final String? dateOfBirth;
  final String subscriptionType;

  BlockedUser({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    this.email,
    this.username,
    this.name,
    this.firstName,
    this.lastName,
    this.bio,
    this.domain,
    this.avatar,
    this.country,
    this.state,
    this.city,
    this.gender,
    this.dateOfBirth,
    required this.subscriptionType,
  });

  factory BlockedUser.fromJson(Map<String, dynamic> json) {
    return BlockedUser(
      id: json['id'] ?? '',
      createdAt: json['created_at'] ?? '',
      updatedAt: json['updated_at'] ?? '',
      email: json['email'],
      username: json['username'],
      name: json['name'],
      firstName: json['first_name'],
      lastName: json['last_name'],
      bio: json['bio'],
      domain: json['domain'],
      avatar: json['avatar'],
      country: json['country'],
      state: json['state'],
      city: json['city'],
      gender: json['gender'],
      dateOfBirth: json['date_of_birth'],
      subscriptionType: json['subscription_type'] ?? 'FREE',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'email': email,
      'username': username,
      'name': name,
      'first_name': firstName,
      'last_name': lastName,
      'bio': bio,
      'domain': domain,
      'avatar': avatar,
      'country': country,
      'state': state,
      'city': city,
      'gender': gender,
      'date_of_birth': dateOfBirth,
      'subscription_type': subscriptionType,
    };
  }
}
