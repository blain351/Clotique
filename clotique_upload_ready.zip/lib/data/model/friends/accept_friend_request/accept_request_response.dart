class AcceptFriendRequestResponse {
  final bool success;
  final Message message;

  AcceptFriendRequestResponse({
    required this.success,
    required this.message,
  });

  // Convert JSON to Dart object
  factory AcceptFriendRequestResponse.fromJson(Map<String, dynamic> json) {
    return AcceptFriendRequestResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? 'Error',
    );
  }
  // Convert Dart object to JSON
  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message.toJson(),
    };
  }
}

class Message {
  final String message;
  final String error;
  final int statusCode;

  Message({
    required this.message,
    required this.error,
    required this.statusCode,
  });

  // Convert JSON to Dart object
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      message: json['message'] ?? '',
      error: json['error'] ?? '',
      statusCode: json['statusCode'] ?? 0,
    );
  }

  // Convert Dart object to JSON
  Map<String, dynamic> toJson() {
    return {
      'message': message,
      'error': error,
      'statusCode': statusCode,
    };
  }
}
