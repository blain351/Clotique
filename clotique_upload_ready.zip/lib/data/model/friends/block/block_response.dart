class BlockErrorResponse {
  final bool success;
  final ErrorMessage message;

  BlockErrorResponse({
    required this.success,
    required this.message,
  });

  factory BlockErrorResponse.fromJson(Map<String, dynamic> json) {
    return BlockErrorResponse(
      success: json['success'] as bool,
      message: ErrorMessage.fromJson(json['message'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message.toJson(),
    };
  }
}

class ErrorMessage {
  final String message;
  final String error;
  final int statusCode;

  ErrorMessage({
    required this.message,
    required this.error,
    required this.statusCode,
  });

  factory ErrorMessage.fromJson(Map<String, dynamic> json) {
    return ErrorMessage(
      message: json['message'] as String,
      error: json['error'] as String,
      statusCode: json['statusCode'] as int,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'message': message,
      'error': error,
      'statusCode': statusCode,
    };
  }
}