package com.example.clotique
import io.flutter.embedding.android.FlutterFragmentActivity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterFragmentActivity() {
}
