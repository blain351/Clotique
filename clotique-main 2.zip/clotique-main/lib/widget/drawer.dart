// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:share_plus/share_plus.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// class MyDrawer extends StatelessWidget {
//   const MyDrawer({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     Future<void> _launchEmail() async {
//       final Uri emailLaunchUri = Uri(
//         scheme: 'mailto',
//         path: 'support@example.com',
//         query: Uri.encodeFull('subject=Support Needed&body=Hello, I need help with...'),
//       );
//
//       if (await canLaunchUrl(emailLaunchUri)) {
//         await launchUrl(emailLaunchUri);
//       } else {
//         throw 'Could not launch email app';
//       }
//     }
//     return Drawer(
//       backgroundColor: Color(0xffF6F8FA),
//       child: Column(
//         children: [
//           DrawerHeader(
//             decoration: BoxDecoration(color: Colors.white),
//             child: Column(
//               children: [
//                 Align(
//                   alignment: Alignment.topRight,
//                   child: GestureDetector(
//                     onTap: () {
//                       Navigator.pop(context);
//                     },
//                     child: Image.asset('assets/icons/cancel.png', scale: 1.5),
//                   ),
//                 ),
//                 SizedBox(height: 12.h),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     Image.asset("assets/app_icons/calculator.png",height: 60,width: 60,),
//                     SizedBox(width: 10),
//                     Text(
//                       'FINANCE\nCALCULATOR',
//                       style: TextStyle(
//                         color: Colors.black,
//                         fontSize: 18.sp,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//           // Drawer Items
//           Expanded(
//             child: ListView(
//               shrinkWrap: true,
//               children: [
//                 _buildDrawerItem(
//                   context,
//                   image: "assets/icons/rate.png", // Corrected image path
//                   text: "Rate Now",
//                   onTap: () {
//                     Navigator.pop(context); // Close the drawer
//                   },
//                 ),
//                 _buildDrawerItem(
//                   context,
//                   image: "assets/icons/email.png",
//                   text: "Email Us",
//                   onTap: () {
//                     Navigator.pop(context); // Close drawer
//                     _launchEmail();         // Open default email app
//                   },
//                 ),
//
//                 _buildDrawerItem(
//                   context,
//                   image: "assets/icons/share.png",
//                   text: "Share Now",
//                   onTap: () {
//                     Share.share(
//                       'Check out this app: https://play.google.com/store/apps/details?id=com.example.streamly',
//
//                     );
//                   },
//                 ),
//
//
//                 _buildDrawerItem(
//                   context,
//                   image: "assets/icons/share.png", // Corrected image path
//                   text: "Disclaimer",
//                   onTap: () {
//                     showDialog(
//                       context: context,
//                       builder: (BuildContext context) {
//                         return AlertDialog(
//                           backgroundColor: Colors.white,
//                           actions: <Widget>[
//                             Column(
//                               children: [
//                                 SizedBox(height: 24.h),
//                                 Align(
//                                   alignment: Alignment.topRight,
//
//                                   child: GestureDetector(
//                                     onTap: () {
//                                       Navigator.pop(context);
//                                     },
//                                     child: Image.asset(
//                                       "assets/icons/cancel.png",
//                                       scale: 1.6,
//                                     ),
//                                   ),
//                                 ),
//
//                                 SizedBox(height: 16.h),
//
//                                 Align(
//                                   alignment: Alignment.center,
//
//                                   child: Image.asset("assets/icons/alart.png"),
//                                 ),
//                                 SizedBox(height: 16.h),
//
//                                 Text(
//                                   "Disclaimer",
//                                   style: TextStyle(
//                                     color: Color(0xff212121),
//                                     fontSize: 22.sp,
//                                     fontWeight: FontWeight.w700,
//                                   ),
//                                 ),
//                                 SizedBox(height: 16.h),
//                                 Text(
//                                   "The Smart Finance Toolkit is intended for informational and educational purposes only. While we strive to ensure accuracy, the app does not provide legal, financial, or investment advice. All results are estimates and should not be solely relied upon for major financial decisions.",
//                                   style: TextStyle(
//                                     color: Color(0xff4A4C56),
//                                     fontSize: 16.sp,
//                                     fontWeight: FontWeight.w400,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ],
//                         );
//                       },
//                     );
//                   },
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // A custom method to build the drawer items
//   Widget _buildDrawerItem(
//     BuildContext context, {
//     required String image, // Image path as a string
//     required String text,
//     required void Function() onTap,
//   }) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Padding(
//         padding: EdgeInsets.symmetric(vertical: 5, horizontal: 16.w),
//         child: Container(
//           padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(12.r),
//             color: Colors.white,
//             border: Border.all(color: Color(0xffCAE6FC)),
//           ),
//           child: Row(
//             children: [
//               Image.asset(
//                 image, // Correctly use Image.asset here
//                 width: 26.w, // Set width of image
//                 height: 26.h, // Set height of image
//               ),
//               SizedBox(width: 16.w),
//               Text(
//                 text,
//                 style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w500),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
