import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class BarChartSample extends StatelessWidget {
  BarChartSample({super.key});

  final List<double> principalData = [
    3000,
    4000,
    6000,
    3000,
    4000,
    3000,
    5000,
    2000,
  ];
  final List<double> interestData = [
    2000,
    2000,
    5000,
    2000,
    3000,
    2000,
    4000,
    1000,
  ];
  final List<String> years = ['0y', '1y', '2y', '3y', '4y', '5y', '6y', '7y'];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Legend
        Padding(
          padding: const EdgeInsets.only(bottom: 16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              _buildLegendItem(const Color(0xFF2196F3), 'Principal'),
              const SizedBox(width: 12),
              _buildLegendItem(const Color(0xFF0069C0), 'Interest'),
            ],
          ),
        ),
        // Bar Chart
        Expanded(
          child: Container(
            color: Colors.white, // Ensure chart background is white
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: 7000,
                backgroundColor:
                    Colors.white, // Set chart's internal background to white
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          '${(value / 1000).toInt()}k',
                          style: const TextStyle(fontSize: 12),
                        );
                      },
                      interval: 1000,
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          years[value.toInt()],
                          style: const TextStyle(fontSize: 12),
                        );
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                barGroups: List.generate(years.length, (index) {
                  return BarChartGroupData(
                    x: index,
                    barsSpace:
                        2, // Minimal space between bars in the same group
                    groupVertically: false,
                    barRods: [
                      BarChartRodData(
                        toY: principalData[index],
                        color: const Color(0xFF2196F3), // Light blue
                        width: 18, // Increased bar width
                        borderRadius: BorderRadius.zero,
                      ),
                      BarChartRodData(
                        toY: interestData[index],
                        color: const Color(0xFF0069C0), // Dark blue
                        width: 18, // Increased bar width
                        borderRadius: BorderRadius.zero,
                      ),
                    ],
                    showingTooltipIndicators: [],
                  );
                }),
                gridData: const FlGridData(show: false),
                barTouchData: BarTouchData(
                  enabled: false,
                ), // Disable touch interactions
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLegendItem(Color color, String label) {
    return Row(
      children: [
        Container(
          width: 12, // Smaller size for circular indicator
          height: 12,
          decoration: BoxDecoration(
            shape: BoxShape.circle, // Circular shape
            color: color,
          ),
        ),
        const SizedBox(width: 6), // Reduced spacing between indicator and text
        Text(label),
      ],
    );
  }
}
