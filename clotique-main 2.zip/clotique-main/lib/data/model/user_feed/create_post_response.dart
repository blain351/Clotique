class CreatePostResponse {
  bool? success;
  String? message;
  Data? data;

  CreatePostResponse({this.success, this.message, this.data});

  CreatePostResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'] as bool?;
    message = json['message'] as String?;
    data = json['data'] != null ? Data.fromJson(json['data'] as Map<String, dynamic>) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? id;
  String? caption;
  List<String>? privacy;
  String? image;
  String? createdAt;
  String? updatedAt;
  String? userId;
  dynamic sharedById;

  Data({
    this.id,
    this.caption,
    this.privacy,
    this.image,
    this.createdAt,
    this.updatedAt,
    this.userId,
    this.sharedById,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'] as String?;
    caption = json['caption'] as String?;
    // Handle privacy field: convert String to List<String> if necessary
    if (json['privacy'] is String) {
      privacy = [json['privacy'] as String];
    } else if (json['privacy'] is List) {
      privacy = (json['privacy'] as List<dynamic>).cast<String>();
    } else {
      privacy = null;
    }
    image = json['image'] as String?;
    createdAt = json['created_at'] as String?;
    updatedAt = json['updated_at'] as String?;
    userId = json['user_id'] as String?;
    sharedById = json['sharedById'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['caption'] = caption;
    data['privacy'] = privacy;
    data['image'] = image;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['user_id'] = userId;
    data['sharedById'] = sharedById;
    return data;
  }
}