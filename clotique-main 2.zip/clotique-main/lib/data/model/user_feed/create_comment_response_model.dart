class CreateCommentResponseModel {
  final bool success;
  final String message;
  final Data? data;

  CreateCommentResponseModel({
    required this.success,
    required this.message,
    this.data,
  });

  factory CreateCommentResponseModel.fromJson(Map<String, dynamic> json) {
    return CreateCommentResponseModel(
      success: json['success'],
      message: json['message'],
      data: json['data'] != null ? Data.fromJson(json['data']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message,
      'data': data?.toJson(),
    };
  }
}

class Data {
  final String id;
  final String content;
  final String postId;
  final String userId;
  final String createdAt;
  final String parentId;

  Data({
    required this.id,
    required this.content,
    required this.postId,
    required this.userId,
    required this.createdAt,
    required this.parentId,
  });

  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(
      id: json['id'],
      content: json['content'],
      postId: json['post_id'],
      userId: json['user_id'],
      createdAt: json['created_at'],
      parentId: json['parent_id'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'post_id': postId,
      'user_id': userId,
      'created_at': createdAt,
      'parent_id': parentId,
    };
  }
}