class AllWardrobeModel {
  bool? success;
  String? message;
  Data? data;

  AllWardrobeModel({this.success, this.message, this.data});

  AllWardrobeModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<Items>? items;
  String? itemCount;
  String? userId;

  Data({this.items, this.itemCount, this.userId});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['items'] != null) {
      items = <Items>[];
      json['items'].forEach((v) {
        items!.add(new Items.fromJson(v));
      });
    }
    itemCount = json['itemCount'];
    userId = json['userId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.items != null) {
      data['items'] = this.items!.map((v) => v.toJson()).toList();
    }
    data['itemCount'] = this.itemCount;
    data['userId'] = this.userId;
    return data;
  }
}

class Items {
  String? id;
  String? description;
  String? image;
  String? createdDate;
  List<String>? categories; // Changed from List<dynamic> to List<String> if categories are strings
  bool? isFavorite;
  bool? isSaved;
  DateTime? outfitDate; // Changed from dynamic to DateTime? if it is a date
  bool? aigenerate;
  String? userId;
  String? expiresAt;

  Items({
    this.id,
    this.description,
    this.image,
    this.createdDate,
    this.categories,
    this.isFavorite,
    this.isSaved,
    this.outfitDate, // Changed to DateTime?
    this.aigenerate,
    this.userId,
    this.expiresAt,
  });

  Items.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    description = json['description'];
    image = json['image'];
    createdDate = json['createdDate'];

    // Changed from List<dynamic> to List<String> for categories
    if (json['categories'] != null) {
      categories = List<String>.from(json['categories']);
    }

    isFavorite = json['isFavorite'];
    isSaved = json['isSaved'];

    // Handle outfitDate as DateTime
    if (json['outfitDate'] != null) {
      outfitDate = DateTime.tryParse(json['outfitDate']);
    }

    aigenerate = json['aigenerate'];
    userId = json['user_id'];
    expiresAt = json['expiresAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['description'] = this.description;
    data['image'] = this.image;
    data['createdDate'] = this.createdDate;

    // Directly mapping categories as List<String>
    if (this.categories != null) {
      data['categories'] = this.categories;
    }

    data['isFavorite'] = this.isFavorite;
    data['isSaved'] = this.isSaved;

    // Convert DateTime to string if not null
    if (this.outfitDate != null) {
      data['outfitDate'] = this.outfitDate!.toIso8601String();
    }

    data['aigenerate'] = this.aigenerate;
    data['user_id'] = this.userId;
    data['expiresAt'] = this.expiresAt;
    return data;
  }
}
