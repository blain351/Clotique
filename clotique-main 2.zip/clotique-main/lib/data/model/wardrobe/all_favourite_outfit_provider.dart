import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:clotique/data/model/home/daily_outfit_model.dart';
import 'package:flutter/material.dart';
import '../../../cors/services/api_services.dart';

class AllFavouriteOutfitProvider extends ChangeNotifier {
  final int _count = 10;
  int get count => _count;

  int _currentPage = 0;
  int get currentPage => _currentPage;

  int? _lastPage;
  bool _inProgress = false;
  bool get inProgress => _inProgress;

  bool _initialLoadingInProgress = false;
  bool get initialLoadingInProgress => _initialLoadingInProgress;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  int get wardrobeFavouriteCount => _favouriteOutfitList.length > 3 ? 3 : _favouriteOutfitList.length;

  final List<DailyOutfitModel> _favouriteOutfitList = [];
  List<DailyOutfitModel> get favouriteOutfitList => _favouriteOutfitList;

  final ApiService _apiService = ApiService();

  Future<void> getAllFavouriteOutfit() async {
    _currentPage++;
    debugPrint('Current page: $_currentPage');

    if (_lastPage != null && _lastPage! < _currentPage) {
      debugPrint('No more data');
      return;
    }

    if (_currentPage == 1) {
      _favouriteOutfitList.clear();
      _initialLoadingInProgress = true;
    } else {
      _inProgress = true;
    }
    notifyListeners();

    final url = ApiEndPoint.getAllFavouriteOutfit(_currentPage, _count);

    try {
      final response = await _apiService.get(url);
      if (response.statusCode == 200) {
        _lastPage = response.data!['pagination']['totalPages'] ?? 0;
        List<DailyOutfitModel> list = [];
        for (Map<String, dynamic> map in response.data!['data']) {
          list.add(DailyOutfitModel.fromJson(map));
        }
        _favouriteOutfitList.addAll(list);
        _errorMessage = null;
      } else {
        _errorMessage = 'Failed to fetch data: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      if (_currentPage == 1) {
        _initialLoadingInProgress = false;
      } else {
        _inProgress = false;
      }
      debugPrint('_lastPage: $_lastPage');
      notifyListeners();
    }
    debugPrint('favouriteOutfitList length: ${_favouriteOutfitList.length}');
  }

  Future<void> refreshFavouriteOutfits() async {
    _currentPage = 0;
    _favouriteOutfitList.clear();
    _lastPage = null;
    await getAllFavouriteOutfit();
  }
}