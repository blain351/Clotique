class PostModel {
  final String id;
  final String caption;
  final String privacy;
  final String image;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String userId;
  final String? sharedById;

  // Constructor
  PostModel({
    required this.id,
    required this.caption,
    required this.privacy,
    required this.image,
    required this.createdAt,
    required this.updatedAt,
    required this.userId,
    this.sharedById,
  });

  // Factory method to create a Post from JSON
  factory PostModel.fromJson(Map<String, dynamic> json) {
    return PostModel(
      id: json['id'],
      caption: json['caption'],
      privacy: json['privacy'],
      image: json['image'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      userId: json['user_id'],
      sharedById: json['sharedById'],
    );
  }

  // Method to convert Post to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'caption': caption,
      'privacy': privacy,
      'image': image,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'user_id': userId,
      'sharedById': sharedById,
    };
  }
}

class PostResponse {
  final bool success;
  final String message;
  final List<PostModel> data;
  final int total;
  final int page;
  final int limit;
  final String userId;

  // Constructor
  PostResponse({
    required this.success,
    required this.message,
    required this.data,
    required this.total,
    required this.page,
    required this.limit,
    required this.userId,
  });

  // Factory method to create a PostResponse from JSON
  factory PostResponse.fromJson(Map<String, dynamic> json) {
    return PostResponse(
      success: json['success'],
      message: json['message'],
      data: (json['data'] as List)
          .map((postJson) => PostModel.fromJson(postJson))
          .toList(),
      total: json['total'],
      page: json['page'],
      limit: json['limit'],
      userId: json['userId'],
    );
  }

  // Method to convert PostResponse to JSON
  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message,
      'data': data.map((post) => post.toJson()).toList(),
      'total': total,
      'page': page,
      'limit': limit,
      'userId': userId,
    };
  }
}
