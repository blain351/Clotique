class SaveOutfitResponse {
  bool? success;
  Data? data;
  String? message;

  SaveOutfitResponse({this.success, this.data, this.message});

  SaveOutfitResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['message'] = this.message;
    return data;
  }
}

class Data {
  String? id;
  String? description;
  String? image;
  String? createdDate;
  bool? isFavorite;
  bool? isSaved;
  Null? outfitDate;
  bool? aigenerate;
  String? userId;
  String? expiresAt;
  String? savedateAt;

  Data(
      {this.id,
        this.description,
        this.image,
        this.createdDate,
        this.isFavorite,
        this.isSaved,
        this.outfitDate,
        this.aigenerate,
        this.userId,
        this.expiresAt,
        this.savedateAt});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    description = json['description'];
    image = json['image'];
    createdDate = json['createdDate'];
    isFavorite = json['isFavorite'];
    isSaved = json['isSaved'];
    outfitDate = json['outfitDate'];
    aigenerate = json['aigenerate'];
    userId = json['user_id'];
    expiresAt = json['expiresAt'];
    savedateAt = json['savedateAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['description'] = this.description;
    data['image'] = this.image;
    data['createdDate'] = this.createdDate;
    data['isFavorite'] = this.isFavorite;
    data['isSaved'] = this.isSaved;
    data['outfitDate'] = this.outfitDate;
    data['aigenerate'] = this.aigenerate;
    data['user_id'] = this.userId;
    data['expiresAt'] = this.expiresAt;
    data['savedateAt'] = this.savedateAt;
    return data;
  }
}
