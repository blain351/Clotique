class NotificationResponseModel {
  final bool success;
  final String message;
  final List<NotificationDataModel> data;
  final int total;
  final int page;
  final int limit;

  NotificationResponseModel({
    required this.success,
    required this.message,
    required this.data,
    required this.total,
    required this.page,
    required this.limit,
  });

  factory NotificationResponseModel.fromJson(Map<String, dynamic> json) {
    var dataList = json['data'] as List;
    List<NotificationDataModel> data = dataList.map((e) => NotificationDataModel.fromJson(e)).toList();

    return NotificationResponseModel(
      success: json['success'],
      message: json['message'],
      data: data,
      total: json['total'],
      page: json['page'],
      limit: json['limit'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message,
      'data': data.map((e) => e.toJson()).toList(),
      'total': total,
      'page': page,
      'limit': limit,
    };
  }
}


class NotificationDataModel {
  final String notificationId;
  final String senderId;
  final String receiverId;
  final String message;
  final String type;
  final String status;
  final String createdAt;
  final String updatedAt;
  final String postId;
  final String commentId;
  final bool read;
  final String friendshipId;
  final String post;
  final Map<String, dynamic> sender;

  NotificationDataModel({
    required this.notificationId,
    required this.senderId,
    required this.receiverId,
    required this.message,
    required this.type,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.postId,
    required this.commentId,
    required this.friendshipId,
    required this.read,
    required this.post,
    required this.sender,
  });

  factory NotificationDataModel.fromJson(Map<String, dynamic> json) {
    return NotificationDataModel(
      notificationId: json['id'],
      senderId: json['sender_id'],
      receiverId: json['receiver_id'],
      message: json['message'],
      type: json['type'],
      status: json['status'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
      postId: json['post_id'],
      commentId: json['comment_id'],
      read: json['read'],
      friendshipId: json['friendship_id'],
      post: json['post'],
      sender: json['sender'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': notificationId,
      'sender_id': senderId,
      'receiver_id': receiverId,
      'message': message,
      'type': type,
      'status': status,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'post_id': postId,
      'comment_id': commentId,
      'read': read,
      'friendship_id': friendshipId,
      'post': post,
      'sender': sender,
    };
  }
}
