class FriendsRequestResponse {
  final bool success;
  final Message message;

  FriendsRequestResponse({
    required this.success,
    required this.message,
  });

  factory FriendsRequestResponse.fromJson(Map<String, dynamic> json) {
    return FriendsRequestResponse(
      success: json['success'] ?? false,
      message: Message.fromJson(json['message'] ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message.toJson(),
    };
  }
}

class Message {
  final String message;
  final String error;
  final int statusCode;

  Message({
    required this.message,
    required this.error,
    required this.statusCode,
  });

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      message: json['message'] ?? 'No message',
      error: json['error'] ?? 'No error',
      statusCode: json['statusCode'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'message': message,
      'error': error,
      'statusCode': statusCode,
    };
  }
}
