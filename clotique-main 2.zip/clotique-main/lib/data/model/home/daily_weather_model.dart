class DailyWeatherModel {
  final Map<String, dynamic> location;
  final double currentTemp;
  final String currentIcon;
  final List<HourlyForecast> hourlyForecast;

  DailyWeatherModel({
    required this.location,
    required this.currentTemp,
    required this.currentIcon,
    required this.hourlyForecast,
  });

  factory DailyWeatherModel.fromJson(Map<String, dynamic> json) {
    return DailyWeatherModel(
      location: json['location'] ?? {},
      currentTemp: json['currentTemp']?.toDouble() ?? 0.0,
      currentIcon: json['currentIcon'] ?? '☀️',
      hourlyForecast: (json['hourlyForecast'] as List?)
          ?.map((e) => HourlyForecast.fromJson(e))
          .toList() ?? [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'location': location,
      'currentTemp': currentTemp,
      'currentIcon': currentIcon,
      'hourlyForecast': hourlyForecast.map((e) => e.toJson()).toList(),
    };
  }
}

class HourlyForecast {
  final String time;
  final double temp;
  final String icon;

  HourlyForecast({
    required this.time,
    required this.temp,
    required this.icon,
  });

  factory HourlyForecast.fromJson(Map<String, dynamic> json) {
    return HourlyForecast(
      time: json['time'] ?? '',
      temp: json['temp']?.toDouble() ?? 0.0,
      icon: json['icon'] ?? '☁️',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'time': time,
      'temp': temp,
      'icon': icon,
    };
  }
}
