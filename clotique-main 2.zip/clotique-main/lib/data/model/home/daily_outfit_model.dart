class DailyOutfitModel {
  final String id;
  final String userId;
  final String imageUrl;
  final String description;
  final String style;
  final String city;
  final double temperature;
  final bool isFavourite;

  DailyOutfitModel({
    required this.id,
    required this.userId,
    required this.imageUrl,
    required this.description,
    required this.isFavourite,
    required this.style,
    required this.city,
    required this.temperature
  });

  factory DailyOutfitModel.fromJson(Map<String, dynamic> json) {
    return DailyOutfitModel(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      imageUrl: json['imageUrl'],
      description: json['description'] ?? '',
      isFavourite: json['favourite'] ?? false,
      style: json['style'] ?? '',
      city: json['city'] ?? '',
      temperature: json['temperature']
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'imageUrl': imageUrl,
      'description': description,
      'favourite': isFavourite,
      'style': style,
      'city': city,
      'temperature': temperature
    };
  }
}