class ServerErrorResponse {
  final int statusCode;
  final String message;

  ServerErrorResponse({
    required this.statusCode,
    required this.message,
  });

  factory ServerErrorResponse.fromJson(Map<String, dynamic> json) {
    return ServerErrorResponse(
      statusCode: json['statusCode'] ?? 0,
      message: json['message'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'statusCode': statusCode,
      'message': message,
    };
  }
}
