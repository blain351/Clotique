class SingleUserAllFriendResponse {
  final String id;
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int status;
  final String? approvedAt;
  final String? availability;
  final String email;
  final String username;
  final String name;
  final String? firstName;
  final String? lastName;
  final String bio;
  final String? domain;
  final String avatar;
  final String? coverPhoto;
  final String? lastOutfitDate;
  final String? lastOutfitEventDate;
  final String? facebookId;
  final String? googleId;
  final String? phoneNumber;
  final String? country;
  final String? state;
  final String? city;
  final String? address;
  final String? zipCode;
  final String? gender;
  final String? dateOfBirth;
  final String subscriptionStatus;
  final String subscriptionType;
  final String? subscriptionEndDate;
  final String type;
  final bool isTwoFactorEnabled;
  final String? twoFactorMethod;
  final String? twoFactorCode;
  final String? twoFactorExpiresAt;
  final int isTwoFactorEnabledInt;
  final String? credit;

  SingleUserAllFriendResponse({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    this.deletedAt,
    required this.status,
    this.approvedAt,
    this.availability,
    required this.email,
    required this.username,
    required this.name,
    this.firstName,
    this.lastName,
    required this.bio,
    this.domain,
    required this.avatar,
    this.coverPhoto,
    this.lastOutfitDate,
    this.lastOutfitEventDate,
    this.facebookId,
    this.googleId,
    this.phoneNumber,
    this.country,
    this.state,
    this.city,
    this.address,
    this.zipCode,
    this.gender,
    this.dateOfBirth,
    required this.subscriptionStatus,
    required this.subscriptionType,
    this.subscriptionEndDate,
    required this.type,
    required this.isTwoFactorEnabled,
    this.twoFactorMethod,
    this.twoFactorCode,
    this.twoFactorExpiresAt,
    required this.isTwoFactorEnabledInt,
    this.credit,
  });

  // Convert JSON to Dart object
  factory SingleUserAllFriendResponse.fromJson(Map<String, dynamic> json) {
    return SingleUserAllFriendResponse(
      id: json['id'] ?? '',
      createdAt: json['created_at'] ?? '',
      updatedAt: json['updated_at'] ?? '',
      deletedAt: json['deleted_at'],
      status: json['status'] ?? 0,
      approvedAt: json['approved_at'],
      availability: json['availability'],
      email: json['email'] ?? '',
      username: json['username'] ?? '',
      name: json['name'] ?? '',
      firstName: json['first_name'],
      lastName: json['last_name'],
      bio: json['bio'] ?? '',
      domain: json['domain'],
      avatar: json['avatar'] ?? '',
      coverPhoto: json['coverPhoto'],
      lastOutfitDate: json['lastOutfitDate'],
      lastOutfitEventDate: json['lastOutfitEventDate'],
      facebookId: json['facebook_id'],
      googleId: json['google_id'],
      phoneNumber: json['phone_number'],
      country: json['country'],
      state: json['state'],
      city: json['city'],
      address: json['address'],
      zipCode: json['zip_code'],
      gender: json['gender'],
      dateOfBirth: json['date_of_birth'],
      subscriptionStatus: json['subscription_status'] ?? '',
      subscriptionType: json['subscription_type'] ?? '',
      subscriptionEndDate: json['subscripton_end_date'],
      type: json['type'] ?? '',
      isTwoFactorEnabled: json['isTwoFactorEnabled'] ?? false,
      twoFactorMethod: json['twoFactorMethod'],
      twoFactorCode: json['twoFactorCode'],
      twoFactorExpiresAt: json['twoFactorExpiresAt'],
      isTwoFactorEnabledInt: json['is_two_factor_enabled'] ?? 0,
      credit: json['credit'],
    );
  }

  // Convert Dart object to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'deleted_at': deletedAt,
      'status': status,
      'approved_at': approvedAt,
      'availability': availability,
      'email': email,
      'username': username,
      'name': name,
      'first_name': firstName,
      'last_name': lastName,
      'bio': bio,
      'domain': domain,
      'avatar': avatar,
      'coverPhoto': coverPhoto,
      'lastOutfitDate': lastOutfitDate,
      'lastOutfitEventDate': lastOutfitEventDate,
      'facebook_id': facebookId,
      'google_id': googleId,
      'phone_number': phoneNumber,
      'country': country,
      'state': state,
      'city': city,
      'address': address,
      'zip_code': zipCode,
      'gender': gender,
      'date_of_birth': dateOfBirth,
      'subscription_status': subscriptionStatus,
      'subscription_type': subscriptionType,
      'subscripton_end_date': subscriptionEndDate,
      'type': type,
      'isTwoFactorEnabled': isTwoFactorEnabled,
      'twoFactorMethod': twoFactorMethod,
      'twoFactorCode': twoFactorCode,
      'twoFactorExpiresAt': twoFactorExpiresAt,
      'is_two_factor_enabled': isTwoFactorEnabledInt,
      'credit': credit,
    };
  }
}
