class RejectedRequestResponse {
  final bool success;
  final FriendshipData data;

  RejectedRequestResponse({required this.success, required this.data});

  factory RejectedRequestResponse.fromJson(Map<String, dynamic> json) {
    return RejectedRequestResponse(
      success: json['success'],
      data: FriendshipData.fromJson(json['data']),
    );
  }

  get status => null;

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'data': data.toJson(),
    };
  }
}

class FriendshipData {
  final UpdatedFriendship updatedFriendship;

  FriendshipData({required this.updatedFriendship});

  factory FriendshipData.fromJson(Map<String, dynamic> json) {
    return FriendshipData(
      updatedFriendship: UpdatedFriendship.fromJson(json['updatedfriendship']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'updatedfriendship': updatedFriendship.toJson(),
    };
  }
}

class UpdatedFriendship {
  final String id;
  final String createdAt;
  final String updatedAt;
  final String requesterId;
  final String recipientId;
  final String status;

  UpdatedFriendship({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    required this.requesterId,
    required this.recipientId,
    required this.status,
  });

  factory UpdatedFriendship.fromJson(Map<String, dynamic> json) {
    return UpdatedFriendship(
      id: json['id'],
      createdAt: json['createdAt'],
      updatedAt: json['updatedAt'],
      requesterId: json['requesterId'],
      recipientId: json['recipientId'],
      status: json['status'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'requesterId': requesterId,
      'recipientId': recipientId,
      'status': status,
    };
  }
}
