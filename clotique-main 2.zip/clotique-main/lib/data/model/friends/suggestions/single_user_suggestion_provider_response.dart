class SingleUserSuggestionFriendResponse {
  final String id;
  final String? name;
  final String? username;
  final String? avatar;
  final bool isRequested;
  final String? friendshipId;

  SingleUserSuggestionFriendResponse({
    required this.id,
    this.name,
    this.username,
    this.avatar,
    required this.isRequested,
    this.friendshipId,
  });

  // Convert JSON to Dart object
  factory SingleUserSuggestionFriendResponse.fromJson(Map<String, dynamic> json) {
    return SingleUserSuggestionFriendResponse(
      id: json['id'] ?? '',
      name: json['name'],
      username: json['username'],
      avatar: json['avatar'],
      isRequested: json['isRequested'] ?? false,
      friendshipId: json['friendshipId'],
    );
  }

  // Convert Dart object to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'username': username,
      'avatar': avatar,
      'isRequested': isRequested,
      'friendshipId': friendshipId,
    };
  }
}
