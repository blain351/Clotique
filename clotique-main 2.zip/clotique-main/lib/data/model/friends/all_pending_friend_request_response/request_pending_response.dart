class AllPendingFriendRequestResponsse {
  final String id;
  final String requesterId;
  final String requesterUsername;
  final String requesterName;
  final String requesterAvatar;
  final String status;

  AllPendingFriendRequestResponsse({
    required this.id,
    required this.requesterId,
    required this.requesterUsername,
    required this.requesterName,
    required this.requesterAvatar,
    required this.status,
  });

  // Convert JSON to Dart object
  factory AllPendingFriendRequestResponsse.fromJson(Map<String, dynamic> json) {
    return AllPendingFriendRequestResponsse(
      id: json['id'] ?? '',
      requesterId: json['requesterId'] ?? '',
      requesterUsername: json['requesterUsername'] ?? '',
      requesterName: json['requesterName'] ?? '',
      requesterAvatar: json['requesterAvatar'] ?? '',
      status: json['status'] ?? '',
    );
  }

  get avatar => null;

  get bio => null;

  get email => null;

  // Convert Dart object to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'requesterId': requesterId,
      'requesterUsername': requesterUsername,
      'requesterName': requesterName,
      'requesterAvatar': requesterAvatar,
      'status': status,
    };
  }
}

void main() {
  // Sample JSON data
  List<Map<String, dynamic>> jsonData = [
    {
      "id": "cmdpg6cb30001un2s1nxl0yiu",
      "requesterId": "cmdgzqx8p0002uwf8d7w3yylz",
      "requesterUsername": "@king_of_pirate",
      "requesterName": "Monkey D. Luffy",
      "requesterAvatar": "mdpt47ozscaled_21.jpg",
      "status": "PENDING"
    },
    {
      "id": "cmdpshmjj0004uwzc27hvihwc",
      "requesterId": "cmdpsfpkw0000uwzc4vw0x84o",
      "requesterUsername": "game changerr",
      "requesterName": "Hrittik",
      "requesterAvatar": "mdpsiwl2download.jpeg",
      "status": "PENDING"
    }
  ];

  // Convert JSON to Dart objects
  List<AllPendingFriendRequestResponsse> requests = jsonData
      .map((jsonItem) => AllPendingFriendRequestResponsse.fromJson(jsonItem))
      .toList();

  // Print Dart objects
  for (var request in requests) {
    print('Request ID: ${request.id}');
    print('Requester Name: ${request.requesterName}');
    print('Requester Username: ${request.requesterUsername}');
    print('Requester Avatar: ${request.requesterAvatar}');
    print('Status: ${request.status}\n');
  }
}
