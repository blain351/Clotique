class UserModel {
  final bool success;
  final String message;
  final String token;
  final String id;
  final bool twoFactorRequired;

  UserModel({
    required this.success,
    required this.message,
    required this.token,
    required this.id,
    required this.twoFactorRequired
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      token: json['authorization']?['token'] ?? '',
      id: json['userId'] ?? '',
      twoFactorRequired: json['twoFactorRequired'] ?? false
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'message': message,
      'token': token,
      'id': id,
      'twoFactorRequired': twoFactorRequired
    };
  }
}