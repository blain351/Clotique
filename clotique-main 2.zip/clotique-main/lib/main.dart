import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:provider/provider.dart';
import 'cors/provider/app_provider.dart';
import 'cors/routes/app_routes.dart';
import 'cors/services/push_notification_service.dart';
import 'cors/services/stripe_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await Hive.initFlutter();
  await Hive.openBox('userBox');
  await ScreenUtil.ensureScreenSize();
  await dotenv.load(fileName: '.env');
  await StripeServices.instance.initialize();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // We will initialize the push notification service here
    final PushNotificationService pushNotificationService = PushNotificationService();

    return MultiProvider(
      providers: AppProviders.getProviders(),
      child: ScreenUtilInit(
        minTextAdapt: true,
        splitScreenMode: true,
        designSize: const Size(375, 812),
        builder: (context, child) {
          // Initialize the push notification service and pass the context
          // Wait until the widget tree is fully built to initialize
          Future.delayed(Duration.zero, () {
            pushNotificationService.initializeSocket(context);
          });

          return MaterialApp(
            debugShowCheckedModeBanner: false,
            initialRoute: '/',
            routes: AppRoutes.routes,
            onUnknownRoute: (settings) {
              debugPrint(
                'Attempted to navigate to unknown route: ${settings.name}',
              );
              return MaterialPageRoute(
                builder: (context) => Scaffold(
                  appBar: AppBar(title: const Text('Route Error')),
                  body: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('No route defined for: ${settings.name}'),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: () => Navigator.pushNamed(context, '/'),
                          child: const Text('Go to Home'),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
            navigatorObservers: [HeroController()],
          );
        },
      ),
    );
  }
}







// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:hive_flutter/adapters.dart';
// import 'package:provider/provider.dart';
// import 'cors/provider/app_provider.dart';
// import 'cors/routes/app_routes.dart';
// import 'cors/services/push_notification_service.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
//   await Hive.initFlutter();
//   await Hive.openBox('userBox');
//   await ScreenUtil.ensureScreenSize();
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     // We will initialize the push notification service here
//     final PushNotificationService pushNotificationService = PushNotificationService();
//
//     return MultiProvider(
//       providers: AppProviders.getProviders(),
//       child: ScreenUtilInit(
//         minTextAdapt: true,
//         splitScreenMode: true,
//         designSize: const Size(375, 812),
//         builder: (context, child) {
//           // Initialize the push notification service and pass the context
//           // Wait until the widget tree is fully built to initialize
//           Future.delayed(Duration.zero, () {
//             pushNotificationService.initializeSocket(context);
//           });
//
//           return MaterialApp(
//             debugShowCheckedModeBanner: false,
//             initialRoute: '/',
//             routes: AppRoutes.routes,
//             onUnknownRoute: (settings) {
//               debugPrint(
//                 'Attempted to navigate to unknown route: ${settings.name}',
//               );
//               return MaterialPageRoute(
//                 builder: (context) => Scaffold(
//                   appBar: AppBar(title: const Text('Route Error')),
//                   body: Center(
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text('No route defined for: ${settings.name}'),
//                         const SizedBox(height: 20),
//                         ElevatedButton(
//                           onPressed: () => Navigator.pushNamed(context, '/'),
//                           child: const Text('Go to Home'),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//             navigatorObservers: [HeroController()],
//           );
//         },
//       ),
//     );
//   }
// }
