
import 'package:clotique/view_model/notification/notification_provider.dart';
import 'package:clotique/views/notification/widget/notification_screen_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      context.read<NotificationProvider>().getNotifications();
    });
  }

  String formatDate(String updatedAt) {
    DateTime date = DateTime.parse(updatedAt);
    return DateFormat('HH:mm dd-MM-yyyy').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          NotificationScreenAppBar(),
          SizedBox(height: 16.h,),
          Expanded(
            child: Consumer<NotificationProvider>(
              builder: (_, notificationProvider, __) {
                final notifications = notificationProvider.notificationList;
                if (notificationProvider.isLoading) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (notifications == null || notifications.isEmpty) {
                  return const Center(child: Text("No notifications found"));
                }
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  child: ListView.builder(
                    itemCount: notifications.length,
                    itemBuilder: (context, index) {
                      final date = formatDate(notifications[index].updatedAt);
                      final formattedDate = formatDate(date);
                      return ListTile(
                        leading: CircleAvatar(
                          radius: 20.r,
                          backgroundImage: AssetImage("assets/images/user1.png"),
                        ),
                        title: Text(
                          notifications[index].message,
                          style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          formattedDate,
                          style: TextStyle(fontSize: 12.sp),
                        ),
                      );
                    },
                  ),
                );
              }
            ),
          )
        ],
      ),
    );
  }
}