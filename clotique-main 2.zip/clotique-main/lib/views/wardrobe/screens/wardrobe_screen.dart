import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:clotique/view_model/wardrobe/waredrob_screen_provider.dart';
import 'package:clotique/views/home/widgets/header_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../data/model/wardrobe/all_favourite_outfit_provider.dart';
import '../widgets/outfit_gallery_card.dart';
import '../widgets/upload_outfit_widget.dart';

class WardrobeScreen extends StatelessWidget {
  const WardrobeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final wardrobeScreenProvider = Provider.of<WardrobeScreenProvider>(context);
    final wardroveItemCount = wardrobeScreenProvider
        .getAllWardrobeModel
        .data
        ?.items
        ?.length ??
        0;

    final favouriteOutfitProvider = context.watch<AllFavouriteOutfitProvider>();

    return Scaffold(
      backgroundColor: Color(0xFFFAF9F6),
      body: SingleChildScrollView(
        child: Column(
          children: [
            HeaderWidget(
              titleText: "Wardrobe",
              descriptionText: "I’m your outfit assistant!",
            ),
            UploadOutfitWidget(),

            Padding(
              padding: EdgeInsets.only(left: 20.w),
              child: Align(
                alignment: Alignment.centerLeft,

                child: Text(
                  "Uploaded Outfit",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),

            SizedBox(height: 15.h),
            SizedBox(
              height: 200.h,
              child: wardroveItemCount > 0 ? ListView.builder(
                itemCount: wardroveItemCount,
                //    shrinkWrap: true,
                scrollDirection: Axis.horizontal,

                // physics: NeverScrollableScrollPhysics(),
                // physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final item =
                      wardrobeScreenProvider
                          .getAllWardrobeModel
                          .data
                          ?.items?[index];
                  final length =
                      wardrobeScreenProvider
                          .getAllWardrobeModel
                          .data
                          ?.items
                          ?.length;
                  if (item == null) {
                    return const SizedBox.shrink();
                  }
                  final imageUrl =
                      item.image != null
                          ? "${ApiEndPoint.baseUrl}/public/storage/avatar/${item.image}"
                          : 'https://via.placeholder.com/150';
                  debugPrint("The image url is for wardrobe $imageUrl");
                  debugPrint("The item count is $length");
                  return Padding(
                    padding: EdgeInsets.only(left: 20),
                    child: Container(
                      width: 180.w, // Fixed width for each item
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12.r),
                        image: DecorationImage(
                          image: NetworkImage(imageUrl),
                          fit: BoxFit.cover,
                          onError: (exception, stackTrace) {
                            debugPrint('Image load failed: $exception');
                          },
                        ),
                      ),
                    ),
                  );
                },
              ) : Center(child: Text('No Uploaded Outfit Found', style: TextStyle(
                  color: Colors.black,
                  fontSize: 16.sp),),
              ),
            ),

            OutfitGalleryCard(
              title: 'My Daily Outfit Log', // Custom title
              totalItems: 3,
              outfitList: const [
                // 'https://www.lagunapearl.com/blog/wp-content/uploads/2019/08/summer-outfits-blazer-denim-shorts.jpg', // Example image 1
                // 'https://cdn.gigwise.com/wp-content/uploads/2023/11/Soft-Chunky-Knits-1024x689.jpg', // Example image 2
                // 'https://assets.vogue.com/photos/6683050b3176138bbaa39fb6/16:9/w_2992,h_1683,c_limit/Holding%20Collage.jpg', // Example image 3
              ],
              onSeeAllTap: () {
                print('See All outfits tapped!');
                // Implement navigation to a screen with all outfits here
              },
            ),
            OutfitGalleryCard(
              // Used the new name here
              title: 'Favorites', // Custom title
              totalItems: favouriteOutfitProvider.favouriteOutfitList.length,
              outfitList: favouriteOutfitProvider.favouriteOutfitList,
              onSeeAllTap: () {
                print('See All outfits tapped!');
                Navigator.pushNamed(context, RouteName.allOutfitScreen).then((_) {
                  context.read<AllFavouriteOutfitProvider>().refreshFavouriteOutfits();
                });
              },
            ),
            OutfitGalleryCard(
              // Used the new name here
              title: 'Saved Outfits', // Custom title
              totalItems: 3,
              outfitList: const [
                // 'https://images.ctfassets.net/h9tz65waiaum/6oE2dyI8MzxPZxiJjZBMuP/3d12fd823db8a087d0fcace01b802424/2a.png?w=2560&q=75&fm=webp',
                // 'https://cdn.gigwise.com/wp-content/uploads/2023/11/Soft-Chunky-Knits-1024x689.jpg', // Example image 2
                // 'https://assets.vogue.com/photos/6683050b3176138bbaa39fb6/16:9/w_2992,h_1683,c_limit/Holding%20Collage.jpg', // Example image 3
              ],
              onSeeAllTap: () {
                print('See All outfits tapped!');
                // Implement navigation to a screen with all outfits here
              },
            ),
            OutfitGalleryCard(
              // Used the new name here
              title: 'Outfits Calendar', // Custom title
              totalItems: 3,
              outfitList: const [
                // 'https://businesswomen.com/wp-content/uploads/2024/11/the-best-interview-outfits-for-women.png',
                // 'https://cdn.gigwise.com/wp-content/uploads/2023/11/Soft-Chunky-Knits-1024x689.jpg', // Example image 2
                // 'https://assets.vogue.com/photos/6683050b3176138bbaa39fb6/16:9/w_2992,h_1683,c_limit/Holding%20Collage.jpg', // Example image 3
              ],
              onSeeAllTap: () {

                print('See All outfits tapped!');
                // Implement navigation to a screen with all outfits here
              },
            ),
            SizedBox(height: 70.h),
          ],
        ),
      ),
    );
  }
}
