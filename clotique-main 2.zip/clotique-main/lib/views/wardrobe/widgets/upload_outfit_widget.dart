import 'dart:io';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../../view_model/wardrobe/waredrob_screen_provider.dart';

class UploadOutfitWidget extends StatefulWidget {
  const UploadOutfitWidget({super.key});

  @override
  State<UploadOutfitWidget> createState() => _UploadOutfitWidgetState();
}

class _UploadOutfitWidgetState extends State<UploadOutfitWidget> {
  File? _imageFile;
  final TextEditingController _descriptionController = TextEditingController();
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
      );
      if (pickedFile != null) {
        setState(() {
          _imageFile = File(pickedFile.path);
        });
      }
    } catch (e) {
      print("Error picking image: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to pick image: $e')),
      );
    }
  }

  Future<void> _saveOutfit() async {
    final String description = _descriptionController.text.trim();

    if (_imageFile == null || description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please upload an image and provide a description.')),
      );
      return;
    }

    final wardrobeScreenProvider = Provider.of<WardrobeScreenProvider>(context, listen: false);
    final success = await wardrobeScreenProvider.createWardrobe(_imageFile!, description);

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Outfit saved successfully!')),
      );
      setState(() {
        _imageFile = null;
        _descriptionController.clear();
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(wardrobeScreenProvider.errorMessage ?? 'Failed to save outfit.'),
        ),
      );
    }
  }

  bool get _isButtonEnabled {
    return _imageFile != null && _descriptionController.text.trim().isNotEmpty;
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wardrobeScreenProvider = Provider.of<WardrobeScreenProvider>(context);
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 15,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        padding: EdgeInsets.all(24.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upload your outfit',
              style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 24.h),
            GestureDetector(
              onTap: _pickImage,
              child: DottedBorder(
                borderType: BorderType.RRect,
                radius: Radius.circular(16.r),
                dashPattern: const [8, 4],
                strokeWidth: 1.5,
                color: Colors.grey.shade400,
                child: Container(
                  width: double.infinity,
                  height: 180.h,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                  child: _imageFile == null
                      ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.cloud_upload_outlined,
                        size: 48.sp,
                        color: const Color(0xFF6359FF),
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        'Upload JPG or PNG file',
                        style: TextStyle(
                          fontSize: 16.sp,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  )
                      : ClipRRect(
                    borderRadius: BorderRadius.circular(15.r),
                    child: Image.file(
                      _imageFile!,
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 24.h),
            TextField(
              controller: _descriptionController,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: 'Describe the outfit...',
                hintStyle: TextStyle(color: Colors.grey.shade400),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16.r),
                  borderSide: BorderSide.none,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16.r),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16.r),
                  borderSide: BorderSide(
                    color: const Color(0xFF6359FF),
                    width: 1.5,
                  ),
                ),
                filled: true,
                fillColor: Colors.grey.shade50,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16.w,
                  vertical: 16.h,
                ),
              ),
              style: TextStyle(fontSize: 16.sp, color: Colors.black87),
              onChanged: (_) {
                setState(() {}); // Update state when description changes
              },
            ),
            SizedBox(height: 32.h),
            Container(
              width: double.infinity,
              height: 56.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30.r),
                gradient: _isButtonEnabled && !wardrobeScreenProvider.isLoading
                    ? const LinearGradient(
                  colors: [Color(0xFF9C7DF5), Color(0xFF5E59FF)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
                    : const LinearGradient(
                  colors: [Color(0xFFE9E6FE), Color(0xFFE9E6FE)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
              child: MaterialButton(
                onPressed: _isButtonEnabled && !wardrobeScreenProvider.isLoading
                    ? _saveOutfit
                    : null,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.r),
                ),
                padding: EdgeInsets.zero,
                child: wardrobeScreenProvider.isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(
                  'Save Outfit',
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: _isButtonEnabled && !wardrobeScreenProvider.isLoading
                        ? Colors.white
                        : Colors.grey.shade400,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}