import 'package:clotique/data/model/wardrobe/all_favourite_outfit_provider.dart';
import 'package:clotique/view_model/auth/check_me/user_details_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../view_model/home/daily_event_outfit_provider.dart';
import '../../../view_model/home/daily_smart_outfit_provider.dart';
import '../../../view_model/home/daily_weather_provider.dart';
import '../../../view_model/parent_screen_provider.dart';
import '../widget/parent_screen_widget.dart';


class ParentScreen extends StatefulWidget {
  const ParentScreen({super.key});

  @override
  State<ParentScreen> createState() => _ParentScreensState();
}

class _ParentScreensState extends State<ParentScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      context.read<UserDetailsProvider>().getUserDetails();
      context.read<DailyWeatherProvider>().getDailyWeather("Dhaka");
      context.read<DailyEventOutfitProvider>().getDailyEventOutfit();
      context.read<DailySmartOutfitProvider>().getDailySmartOutfit();
      context.read<AllFavouriteOutfitProvider>().getAllFavouriteOutfit();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Consumer<ParentScreensProvider>(
            builder: (context, parentScreenProvider, child) {
              if (parentScreenProvider.screens.isEmpty ||
                  parentScreenProvider.selectedIndex < 0 ||
                  parentScreenProvider.selectedIndex >=
                      parentScreenProvider.screens.length) {
                return const Center(child: Text('No screens available'));
              }

              final validScreens =
              parentScreenProvider.screens
                  .asMap()
                  .entries
                  .where((entry) => entry.value != null)
                  .map((entry) => entry.value!)
                  .toList();

              if (validScreens.isEmpty) {
                return const Center(child: Text('No valid screens available'));
              }

              final adjustedIndex = parentScreenProvider.selectedIndex.clamp(
                0,
                validScreens.length - 1,
              );

              return IndexedStack(index: adjustedIndex, children: validScreens);
            },
          ),
          Transform.translate(
            offset: const Offset(0, -15),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: const ParentScreenWidget(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
