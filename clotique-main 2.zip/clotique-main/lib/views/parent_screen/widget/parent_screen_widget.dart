import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../../cors/constant/app_colors.dart';
import '../../../view_model/parent_screen_provider.dart';

class ParentScreenWidget extends StatelessWidget {
  const ParentScreenWidget({super.key});

  static const _tabs = [
    {'iconPath': 'assets/icons/home.png'},
    {'iconPath': 'assets/icons/compare.png'},
    {'iconPath': 'assets/icons/outfit.png'},
    {'iconPath': 'assets/icons/social_media.png'},
    {'iconPath': 'assets/icons/setting.png'},
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: 70.h,
      width: double.infinity,
      // padding: EdgeInsets.only(bottom: 20.h),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(50.r),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: List.generate(
          _tabs.length,
          (index) => Expanded(
            child: _TabButton(
              index: index,
              iconPath: _tabs[index]['iconPath']!,
            ),
          ),
        ),
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  final int index;
  final String iconPath;

  const _TabButton({required this.index, required this.iconPath});

  @override
  Widget build(BuildContext context) {
    return Consumer<ParentScreensProvider>(
      builder: (_, provider, __) {
        final isSelected = provider.selectedIndex == index;

        return GestureDetector(
          onTap:
              () =>
                  context.read<ParentScreensProvider>().onSelectedIndex(index),
          child: Container(
            height: 37.h,
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  iconPath,
                  width: (index == 2) ? 50.w : 20.w,
                  height: (index == 2) ? 50.h : 20.h,
                  color:
                      (index == 2)
                          ? null
                          : isSelected
                          ? Color(0xff5E59FF)
                          : Color(0xff777980),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
