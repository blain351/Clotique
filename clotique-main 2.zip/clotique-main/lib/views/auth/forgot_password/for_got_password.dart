import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../view_model/auth/forget_pass/for_got_password_provider.dart';
import '../../../widget/custom_text_field.dart';
import '../../../widget/primary_button.dart';

class ForgotPassword extends StatelessWidget {
  const ForgotPassword({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<ForgotPasswordProvider>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 30.h),
              Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: EdgeInsets.all(6.r),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(color: const Color(0xffE9E6FE)),
                    ),
                    child: Image.asset(
                      "assets/icons/back_arrow.png",
                      height: 20.h,
                      width: 20.w,
                    ),
                  ),
                ),
              ),

              SizedBox(height: 29.h),

              // Title
              Text(
                "Forgot Password",
                style: TextStyle(
                  color: const Color(0xff212121),
                  fontSize: 24.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),

              SizedBox(height: 16.h),

              // Email Input Label
              Text("Email", style: _labelStyle()),
              SizedBox(height: 7.h),

              // Email Text Field
              CustomTextField(
                hintText: 'Type your email address',
                keyboardType: TextInputType.emailAddress,
                obscureText: false,
                onChanged: provider.setEmail,
              ),

              // Email Error
              if (provider.emailError != null)
                Padding(
                  padding: EdgeInsets.only(top: 4.h, left: 8.w),
                  child: Text(
                    provider.emailError!,
                    style: TextStyle(color: Colors.red, fontSize: 12.sp),
                  ),
                ),

              const Spacer(),

              // Send Button
              Consumer<ForgotPasswordProvider>(
                builder: (_, provider, __) {
                  return Visibility(
                    visible: provider.isLoading == false,
                    replacement: Center( child: CircularProgressIndicator(),),
                    child: SizedBox(
                      width: double.infinity,
                      child: PrimaryButton(
                        text: 'Send',
                        textColor: Colors.white,
                        onPressed: () {
                          provider.submit(context);
                          if (provider.errorMessage.isEmpty || provider.errorMessage == '') {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('A code has been sent to your email'),
                              ),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Failed to send code'),
                              ),
                            );
                          }
                        }
                      ),
                    ),
                  );
                }
              ),

              SizedBox(height: 20.h),
            ],
          ),
        ),
      ),
    );
  }

  TextStyle _labelStyle() => TextStyle(
    color: const Color(0xff7C7D81),
    fontSize: 12.sp,
    fontWeight: FontWeight.w500,
  );
}
