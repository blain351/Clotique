import 'package:clotique/cors/routes/routes_name.dart';
import 'package:clotique/view_model/auth/login_logout_provider/login_logout_provider.dart';
import 'package:clotique/widget/facebook_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../view_model/parent_screen_provider.dart';
import '../../../widget/apple_button.dart';
import '../../../widget/custom_text_field.dart';
import '../../../widget/google_button.dart';
import '../../../widget/primary_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    super.dispose();
    _emailController.dispose();
    _passwordController.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 27.h),
                Image.asset(
                  "assets/icons/export_button.png",
                  // height: 100.h,
                  // width: 100.w,
                ),
                SizedBox(height: 36.h),
                Text(
                  "Login to your Account",
                  style: TextStyle(
                    color: Color(0xff212121),
                    fontSize: 24.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 16.h),

                Text("Email", style: _labelStyle()),
                SizedBox(height: 7.h),
                CustomTextField(
                  controller: _emailController,
                  hintText: "Enter your email",
                  keyboardType: TextInputType.emailAddress,
                  obscureText: false,
                ),

                SizedBox(height: 16.h),
                Text("Password", style: _labelStyle()),
                SizedBox(height: 7.h),
                Consumer<LoginLogoutProvider>(
                  builder: (_, provider, __) {
                    return CustomTextField(
                      hintText: "New Password",
                      keyboardType: TextInputType.text,
                      controller: _passwordController,
                      obscureText: !provider.isPasswordVisible,
                      suffixIcon: IconButton(
                        icon: provider.isPasswordVisible ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
                        onPressed: () {
                          provider.togglePasswordVisibility();
                        },
                      ),
                    );
                  }
                ),

                SizedBox(height: 16.h),

                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: (){
                      Navigator.pushNamed(context, RouteName.forgotPassword);

                    },
                    child: Text(
                      "Forgot Password?",
                      style: TextStyle(
                        color: Color(0xff000000),
                        fontWeight: FontWeight.w500,
                        fontSize: 16.sp,
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 40.h),
                Consumer<LoginLogoutProvider>(
                  builder: (_, provider, __) {
                    return Visibility(
                      visible: provider.isLoading == false,
                      replacement: Center(child: CircularProgressIndicator(),),
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width * 0.9,
                        child: PrimaryButton(
                          text: 'Login',
                          textColor: Color(0xffFFFFFF),
                          onPressed: () async {
                            final email = _emailController.text;
                            final password = _passwordController.text;
                            provider.userLogin(context, email, password);
                          },
                        ),
                      ),
                    );
                  }
                ),
                SizedBox(height: 20.h),
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "- Or -",
                    style: TextStyle(
                      color: Color(0xff000000),
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                SizedBox(height: 20.h),
                AppleButton(),
                SizedBox(height: 10),
                GoogleButton(),
                SizedBox(height: 10),
                FacebookButton(),

                SizedBox(height: 24.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Don't have an account?",
                      style: TextStyle(
                        color: Color(0xff000000),
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pushNamed(context, RouteName.signUpScreen);
                      },
                      child: Text(
                        "Sign Up",
                        style: TextStyle(
                          color: Color(0xff7E6BFA),
                          fontWeight: FontWeight.w700,
                          fontSize: 16.sp,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  TextStyle _labelStyle() => TextStyle(
    color: Color(0xff7C7D81),
    fontSize: 12.sp,
    fontWeight: FontWeight.w500,
  );
}
