import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import '../../../view_model/ai_generate/ai_generate_viewmodel.dart';

class OutfitGeneratorWidget extends StatefulWidget {
  @override
  _OutfitGeneratorWidgetState createState() => _OutfitGeneratorWidgetState();
}

class _OutfitGeneratorWidgetState extends State<OutfitGeneratorWidget> {
  bool _isOutfitGenerated = false;
  String? _selectedOccasion;
  String _occasionDescription = '';
  final TextEditingController occasionController = TextEditingController();
  String _selectedOutfitCategory = 'Casual';
  DateTime _selectedDate = DateTime.now();

  @override
  void dispose() {
    occasionController.dispose();
    super.dispose();
  }

  Widget _buildInputForm(AiGenerateViewModel viewModel) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildHeader(),
        SizedBox(height: 24.h),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: Colors.grey.shade300, width: 1.w),
          ),
          child: DropdownButton<String>(
            value: _selectedOccasion,
            hint: Text(
              'Occasion',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 16.sp),
            ),
            icon: Icon(
              Icons.keyboard_arrow_down_rounded,
              size: 24.sp,
              color: Colors.grey.shade700,
            ),
            isExpanded: true,
            underline: const SizedBox(),
            items: <String>[
              'Casual',
              'Formal',
              'Sporty',
              'Party',
              'Business Casual',
              'Traditional',
            ].map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value, style: TextStyle(fontSize: 16.sp)),
              );
            }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _selectedOccasion = newValue;
              });
            },
          ),
        ),
        SizedBox(height: 16.h),
        TextField(
          controller: occasionController,
          decoration: InputDecoration(
            hintText: 'Describe the occasion...',
            hintStyle: TextStyle(color: Colors.grey.shade600),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.r),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1.w),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.r),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1.w),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.r),
              borderSide: BorderSide(
                color: const Color(0xFF5A4BFF),
                width: 1.5.w,
              ),
            ),
            contentPadding: EdgeInsets.symmetric(
              vertical: 16.h,
              horizontal: 16.w,
            ),
          ),
          maxLines: 4,
        ),
        SizedBox(height: 24.h),
        Container(
          padding: EdgeInsets.symmetric(vertical: 16.h),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF8A7BEE), Color(0xFF5A4BFF)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(30.r),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF5A4BFF).withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: GestureDetector(
            onTap: () async {
              if (_selectedOccasion == null || occasionController.text.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Please select an occasion and describe the occasion.',
                    ),
                  ),
                );
                return;
              }

              // Set the generated state to true immediately to show the loading animation
              setState(() {
                _isOutfitGenerated = true;
                _occasionDescription = occasionController.text;
              });

              debugPrint("Initiating outfit generation...");
              await viewModel.generateOutfit(_selectedOccasion!, occasionController.text);
              debugPrint("Outfit generation completed. Error: ${viewModel.errorMessage}, isLoading: ${viewModel.isLoading}");

              if (viewModel.errorMessage.isNotEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(viewModel.errorMessage)),
                );
                // If there's an error, go back to the input form
                setState(() {
                  _isOutfitGenerated = false;
                });
              }
            },
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Generate Outfit',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Icon(
                    Icons.auto_awesome,
                    color: Colors.white,
                    size: 20.sp,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGeneratedOutfitDisplay(AiGenerateViewModel viewModel) {
    debugPrint("Building generated outfit display. isLoading: ${viewModel.isLoading}, isOutfitGenerated: $_isOutfitGenerated");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildHeader(showFreeTag: !viewModel.isPremium),
        SizedBox(height: 8.h),
        Text(
          'Style your day in one tap',
          style: TextStyle(fontSize: 16.sp, color: Colors.black54),
        ),
        SizedBox(height: 24.h),
        _buildStaticInputField(label: _selectedOccasion ?? 'N/A'),
        SizedBox(height: 16.h),
        _buildStaticInputField(label: _occasionDescription.isNotEmpty ? _occasionDescription : 'No occasion described'),
        SizedBox(height: 24.h),
        Container(
          padding: EdgeInsets.all(16.w),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(
              color: const Color(0xFF6A34A0).withOpacity(0.6),
              width: 1.w,
            ),
            color: const Color(0xFFEEEBFF),
          ),
          child: viewModel.isLoading
              ? Container(
            height: 150.h,
            width: double.infinity,
            alignment: Alignment.center,
            color: Colors.white.withOpacity(0.8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                LoadingAnimationWidget.waveDots(
                  color: const Color(0xFF5A4BFF),
                  size: 50.sp,
                ),
                SizedBox(height: 8.h),
                Text(
                  'Generating outfit...',
                  style: TextStyle(fontSize: 16.sp, color: Colors.black54),
                ),
              ],
            ),
          )
              : viewModel.isPremium
              ? Image.network(
            "${ApiEndPoint.aiImageBaseUrl}/${viewModel.aiGenerateResponse?.imageUrl ?? ''}",
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => Container(
              height: 150.h,
              width: double.infinity,
              alignment: Alignment.center,
              child: Text(
                'Failed to load image',
                style: TextStyle(fontSize: 16.sp, color: Colors.red),
              ),
            ),
          )
              : Container(
            padding: EdgeInsets.all(16.w),
            child: Text(
              viewModel.aiGenerateResponse?.promptUsed ?? 'No outfit generated',
              style: TextStyle(
                fontSize: 16.sp,
                height: 1.5,
                color: Colors.black87,
              ),
            ),
          ),
        ),
        SizedBox(height: 24.h),
        Row(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.3,
              child: ElevatedButton(
                onPressed: () {
                  _showSaveOutfitDialog(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black87,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.r),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 16.h),
                  elevation: 5,
                ),
                child: Text(
                  'Save',
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            SizedBox(width: 16.w),
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF8A7BEE), Color(0xFF5A4BFF)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(30.r),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF5A4BFF).withOpacity(0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _isOutfitGenerated = false;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.r),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 16.h),
                    elevation: 0,
                  ),
                  icon: Text(
                    'Regenerate',
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  label: Icon(
                    Icons.auto_awesome,
                    color: Colors.white,
                    size: 20.sp,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildHeader({bool showFreeTag = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(
              Icons.auto_awesome,
              color: const Color(0xFF7F6CFA),
              size: 32.sp,
            ),
            SizedBox(width: 8.w),
            Text(
              'AI Outfit Generator',
              style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ],
        ),
        if (showFreeTag)
          Text(
            '(Free)',
            style: TextStyle(
              fontSize: 16.sp,
              color: Colors.grey.shade600,
              fontStyle: FontStyle.italic,
            ),
          ),
      ],
    );
  }

  Widget _buildStaticInputField({required String label, int maxLines = 1}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: Colors.grey.shade300, width: 1.w),
        color: Colors.white,
      ),
      child: Text(
        label,
        style: TextStyle(color: Colors.black87, fontSize: 16.sp),
        maxLines: maxLines,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  void _showSaveOutfitDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.r),
          ),
          backgroundColor: Colors.white,
          child: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(24.w),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Icon(
                            Icons.close,
                            color: Colors.grey.shade600,
                            size: 24.sp,
                          ),
                        ),
                      ),
                      Text(
                        'Save Outfit',
                        style: TextStyle(
                          fontSize: 22.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      SizedBox(height: 24.h),
                      Container(
                        width: double.infinity,
                        height: 180.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16.r),
                          color: Colors.grey.shade200,
                          image: context.read<AiGenerateViewModel>().isPremium &&
                              context.read<AiGenerateViewModel>().aiGenerateResponse?.imageUrl != null
                              ? DecorationImage(
                            image: NetworkImage(
                              "${ApiEndPoint.aiImageBaseUrl}/${context.read<AiGenerateViewModel>().aiGenerateResponse!.imageUrl}",
                            ),
                            fit: BoxFit.cover,
                          )
                              : null,
                        ),
                        child: context.read<AiGenerateViewModel>().isPremium &&
                            context.read<AiGenerateViewModel>().aiGenerateResponse?.imageUrl == null
                            ? Center(child: Text('No image available'))
                            : null,
                      ),
                      SizedBox(height: 24.h),
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 16.w,
                          vertical: 4.h,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(
                            color: Colors.grey.shade300,
                            width: 1.w,
                          ),
                        ),
                        child: DropdownButton<String>(
                          value: _selectedOutfitCategory,
                          hint: Text(
                            'Select Category',
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 16.sp,
                            ),
                          ),
                          icon: Icon(
                            Icons.keyboard_arrow_down_rounded,
                            size: 24.sp,
                            color: Colors.grey.shade700,
                          ),
                          isExpanded: true,
                          underline: const SizedBox(),
                          items: <String>[
                            'Casual',
                            'Formal',
                            'Sporty',
                            'Party',
                            'Business Casual',
                            'Traditional',
                          ].map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 16.sp),
                              ),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedOutfitCategory = newValue!;
                            });
                          },
                        ),
                      ),
                      SizedBox(height: 16.h),
                      GestureDetector(
                        onTap: () async {
                          final DateTime? picked = await showDatePicker(
                            context: context,
                            initialDate: _selectedDate,
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2101),
                          );
                          if (picked != null && picked != _selectedDate) {
                            setState(() {
                              _selectedDate = picked;
                            });
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 16.w,
                            vertical: 16.h,
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12.r),
                            border: Border.all(
                              color: Colors.grey.shade300,
                              width: 1.w,
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                DateFormat('dd MMM').format(_selectedDate),
                                style: TextStyle(
                                  fontSize: 16.sp,
                                  color: Colors.black87,
                                ),
                              ),
                              Icon(
                                Icons.calendar_today_outlined,
                                size: 20.sp,
                                color: const Color(0xFF5A4BFF),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 24.h),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () async {
                                final viewModel = context.read<AiGenerateViewModel>();
                                final outfitId = viewModel.aiGenerateResponse?.outfitId;
                                if (outfitId != null) {
                                  await viewModel.saveOutfit(outfitId, "${DateFormat('yyyy-MM-dd').format(_selectedDate)}T00:00:00Z");
                                  Navigator.pop(context);
                                  if (viewModel.isOutfitSaved) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text('Outfit saved successfully!'),
                                      ),
                                    );
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(viewModel.errorMessage.isNotEmpty
                                            ? viewModel.errorMessage
                                            : 'Failed to save outfit'),
                                      ),
                                    );
                                  }
                                } else {
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('No outfit to save'),
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.black87,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.r),
                                ),
                                padding: EdgeInsets.symmetric(vertical: 16.h),
                                elevation: 5,
                              ),
                              child: Text(
                                'Save Outfit',
                                style: TextStyle(
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 16.w),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.grey.shade200,
                              shape: BoxShape.circle,
                            ),
                            child: IconButton(
                              onPressed: () {
                                print('Share button pressed!');
                              },
                              icon: Icon(
                                Icons.share_outlined,
                                color: Colors.grey.shade700,
                                size: 24.sp,
                              ),
                              padding: EdgeInsets.all(12.w),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    debugPrint("Building OutfitGeneratorWidget");
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: DottedBorder(
        color: const Color(0xFF6A34A0).withOpacity(0.6),
        strokeWidth: 2,
        radius: Radius.circular(24.r),
        dashPattern: const [8, 6],
        borderType: BorderType.RRect,
        padding: EdgeInsets.all(24.w),
        child: Consumer<AiGenerateViewModel>(
          builder: (context, viewModel, child) {
            debugPrint("Consumer rebuilt. isLoading: ${viewModel.isLoading}, isOutfitGenerated: $_isOutfitGenerated");
            return AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: _isOutfitGenerated
                  ? _buildGeneratedOutfitDisplay(viewModel)
                  : _buildInputForm(viewModel),
            );
          },
        ),
      ),
    );
  }
}