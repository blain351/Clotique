import 'package:flutter/material.dart';

// Renaming the list and model to fit the wardrobe context
class WardrobeItem {
  final String image;

  WardrobeItem({required this.image});
}

// Renaming the list to dummyImage
final List<WardrobeItem> dummyImage = List.generate(
  10,
      (index) => WardrobeItem(
    image: "https://picsum.photos/400/300?random=${index + 20}",
  ),
);

class WardrobeWidget extends StatefulWidget {
  const WardrobeWidget({super.key});

  @override
  _WardrobeWidgetState createState() => _WardrobeWidgetState();
}

class _WardrobeWidgetState extends State<WardrobeWidget> {
  String mainImage = dummyImage[0].image;  // Initially set to the first image
  int selectedIndex = 0;  // Initially select the first item

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView( // Allows content to scroll if it overflows
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header: "My Wardrobe" and "20 Item" button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'My Wardrobe',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // TODO: Implement action for "20 Item" button
                      print('20 Item button pressed!');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[200], // Light grey background
                      foregroundColor: Colors.black54, // Text color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20), // Rounded corners
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                      elevation: 0, // No shadow
                    ),
                    child: const Text(
                      '20 Item',
                      style: TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 25), // Spacer

              // Main Outfit Card: Using image from mainImage
              Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20), // Rounded corners for the card
                ),
                clipBehavior: Clip.antiAlias, // Ensures content is clipped to card shape
                child: AspectRatio(
                  aspectRatio: 16 / 9, // Adjust aspect ratio as needed for the image
                  child: Image.network(
                    mainImage, // Use mainImage for the main image
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: Colors.grey[300],
                        child: const Center(
                          child: Icon(Icons.broken_image, size: 50, color: Colors.grey),
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 25), // Spacer

              // Horizontal Scrollable Outfit Suggestions
              SizedBox(
                height: 150, // Height for the horizontal list
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: dummyImage.length, // Use dummyImage count
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 15.0),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            mainImage = dummyImage[index].image; // Update the main image
                            selectedIndex = index; // Set selected item
                          });
                        },
                        child: Card(
                          elevation: 3,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15), // Rounded corners for suggestion cards
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: Container(
                            width: 140, // Width for each suggestion card
                            height: 140, // Height for each suggestion card
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: selectedIndex == index
                                    ? const Color(0xFF9C7DF5) // Purple border if selected
                                    : Colors.transparent, // No border if not selected
                                width: 3, // Border width
                              ),
                              borderRadius: BorderRadius.circular(15), // Matching border radius to the card
                            ),
                            child: Image.network(
                              dummyImage[index].image, // Dynamically load each image from dummyImage
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: Colors.grey[200],
                                  child: const Center(
                                    child: Icon(Icons.broken_image, size: 40, color: Colors.grey),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 30), // Spacer

              // "Update Wardrobe" Button
              Center(
                child: SizedBox(
                  width: double.infinity, // Button takes full width
                  height: 55, // Height of the button
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // TODO: Implement action for "Update Wardrobe" button
                      print('Update Wardrobe button pressed!');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white, // White background
                      foregroundColor: const Color(0xFF7C6AFA), // Dark purple text/icon color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30), // Highly rounded corners
                        side: const BorderSide(color: Color(0xFF7C6AFA), width: 1), // Border
                      ),
                      elevation: 0, // No shadow
                    ),
                    icon: const Text(
                      'Update Wardrobe',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    label: const Icon(Icons.arrow_forward), // Right arrow icon
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
