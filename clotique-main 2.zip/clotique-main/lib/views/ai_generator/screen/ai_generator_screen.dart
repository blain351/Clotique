import 'package:clotique/views/home/widgets/header_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../widgets/outfit_generator_widget.dart';
import '../widgets/wardrobe_widget.dart';

class AiGeneratorScreen extends StatelessWidget {
  const AiGeneratorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            HeaderWidget(titleText: "Hello, Mansur!", descriptionText: "I’m your outfit assistant!",),
            OutfitGeneratorWidget(),
            WardrobeWidget(),
            SizedBox(height: 50,)

          ],
        ),
      ),
    );
  }
}
