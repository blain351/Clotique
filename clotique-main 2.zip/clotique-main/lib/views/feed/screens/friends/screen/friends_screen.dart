import 'package:clotique/view_model/friends/all_pending_request_provider/pending_request_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../../../cors/routes/routes_name.dart';
import '../../../../../view_model/friends/suggestions/single_user_suggestion_friend_provider.dart';
import '../tab/all_friends_tab.dart';
import '../tab/blocked_users_tab.dart';
import '../tab/friend_search_delegate.dart';
import '../tab/requests_tab.dart';
import '../tab/suggestions_tab.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Provider.of<SuggestionsProvider>(context, listen: false).friendsScreen();
      Provider.of<AllPendingRequestProvider>(context, listen: false).fetchAllPendingRequests;
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffFAF9F6),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Friends',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.black),
            onPressed: () {
              showSearch(context: context, delegate: FriendSearchDelegate());
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          dividerColor: Colors.transparent,
          indicator: BoxDecoration(
            borderRadius: BorderRadius.circular(30.r),
            color: const Color(0xff7E6BFA),
          ),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.black54,
          labelStyle: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
          unselectedLabelStyle: TextStyle(fontSize: 16.sp),
          tabs: [
            _buildTab('All Friends (148)', 0),
            _buildTab('Suggestions', 1),
            _buildTab('Requests', 2),
            _buildTab('Blocked Users', 3),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Consumer<AllPendingRequestProvider>(
              builder: (context, requestProvider, child) {
                    return TabBarView(
                      controller: _tabController,
                      children: [
                        SingleUserAllFriendTab(),
                        SingleUserSuggestionTab(),
                        AllPendingRequestsScreen(),
                        BlockedUsersTab(),
                      ],
                    );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTab(String text, int index) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30.r),
        color: _tabController.index == index
            ? const Color(0xff7E6BFA)
            : const Color(0xffFAF9F6),
        border: Border.all(
          color: _tabController.index == index
              ? const Color(0xff7E6BFA)
              : const Color(0xffDFE1E7),
          width: 1.0,
        ),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: _tabController.index == index ? Colors.white : Colors.black,
          fontSize: 16.sp,
        ),
      ),
    );
  }
}
