import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../../../view_model/friends/accept_friend_request_provider/accept_request_provider.dart';
import '../../../../../view_model/friends/all_pending_request_provider/pending_request_provider.dart';
import '../../../../../cors/routes/routes_name.dart'; // Ensure correct route name

class AllPendingRequestsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AllPendingRequestProvider(),
      child: Consumer<AllPendingRequestProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.errorMessage.isNotEmpty) {
            return Center(
              child: Text(
                provider.errorMessage,
                style: TextStyle(color: Colors.red),
              ),
            );
          }

          if (provider.pendingRequests.isEmpty) {
            return const Center(child: Text('No pending requests.'));
          }

          return ListView.builder(
            itemCount: provider.pendingRequests.length,
            itemBuilder: (context, index) {
              final request = provider.pendingRequests[index];
              return ListTile(
                leading: CircleAvatar(
                  radius: 20,
                  backgroundImage: request.avatar != null
                      ? NetworkImage(request.avatar!)
                      : const AssetImage("assets/images/apple.png") as ImageProvider,
                ),
                title: Text(request.requesterName),
                subtitle: Text(request.requesterUsername),
                trailing: ElevatedButton(
                  onPressed: () async {

                    final acceptProvider = Provider.of<AcceptFriendRequestProvider>(context, listen: false);
                    await acceptProvider.fetchAcceptFriendRequest(request.id);

                    // Handle success/failure response
                    if (acceptProvider.response != null && acceptProvider.response!.success) {
                      // Remove the accepted request from the pending requests list
                      provider.removeRequestFromPendingList(request.id);

                      // Pass the accepted friend's data and navigate to the AllFriendsTab
                      Navigator.pushNamed(
                        context,
                        RouteName.singleUserAllFriendTab, // Make sure this matches the route name
                        arguments: {
                          'id': request.id,
                          'name': request.requesterName,
                          'username': request.requesterUsername,
                          'avatar': request.avatar,
                          'bio': request.bio,
                          'email': request.email,
                        },
                      );

                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Request accepted successfully'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Error accepting request'),
                          backgroundColor: Colors.red,
                        ),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xff7E6BFA), // Purple color
                    padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                  ),
                  child: Text(
                    'Accept',
                    style: TextStyle(fontSize: 14.sp, color: Colors.white),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
