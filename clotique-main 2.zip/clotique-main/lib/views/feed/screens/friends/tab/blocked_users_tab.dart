import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../../../../view_model/friends/block_list/block_list_provider.dart';
import '../../../../../view_model/friends/unblock/unblock_provider.dart';
import '../../../../../cors/routes/routes_name.dart';

class BlockedUsersTab extends StatelessWidget {
  const BlockedUsersTab({super.key});

  @override
  Widget build(BuildContext context) {
    final blockListProvider = Provider.of<BlockListProvider>(context);
    final unblockProvider = Provider.of<UnblockProvider>(context, listen: false);

    return SingleChildScrollView(
      padding: EdgeInsets.all(16.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 16.h),
          Text(
            'Blocked Users',
            style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16.h),

          // Show loading indicator if data is being fetched
          if (blockListProvider.isLoading)
            const Center(child: CircularProgressIndicator()),

          // Show error message if there is any error
          if (blockListProvider.errorMessage.isNotEmpty)
            Center(
              child: Column(
                children: [
                  Text(
                    blockListProvider.errorMessage,
                    style: TextStyle(fontSize: 16.sp, color: Colors.red),
                  ),
                  SizedBox(height: 16.h),
                  ElevatedButton(
                    onPressed: () => blockListProvider.fetchBlockList(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Retry'),
                  )
                ],
              ),
            ),

          // Show message if there are no blocked users
          if (!blockListProvider.isLoading &&
              blockListProvider.blockedUsers.isEmpty &&
              blockListProvider.errorMessage.isEmpty)
            Center(
              child: Text(
                'No blocked users found',
                style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
              ),
            ),

          // Show the list of blocked users
          if (blockListProvider.blockedUsers.isNotEmpty)
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: blockListProvider.blockedUsers.length,
              itemBuilder: (context, index) {
                final blockedItem = blockListProvider.blockedUsers[index];
                final blockedUser = blockedItem.blocked;

                return ListTile(
                  leading: CircleAvatar(
                    radius: 20.r,
                    backgroundImage: blockedUser?.avatar != null
                        ? NetworkImage(blockedUser!.avatar!)
                        : const AssetImage("assets/images/apple.png")
                    as ImageProvider,
                  ),
                  title: Text(
                    blockedUser?.name ?? blockedUser?.email ?? 'Unknown User',
                    style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    'Blocked',
                    style: TextStyle(fontSize: 12.sp, color: Colors.grey),
                  ),
                  trailing: ElevatedButton(
                    onPressed: () async {
                      await unblockProvider.fetchUnblockUser(blockedUser!.id);

                      if (unblockProvider.errorMessage.isEmpty && unblockProvider.response != null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Unblock Successfully! ${unblockProvider.response!.message}',
                              style: TextStyle(fontSize: 16.sp),
                            ),
                            backgroundColor: Colors.green,
                          ),
                        );
                        // Remove the unblocked user from the blocked list
                        blockListProvider.blockedUsers.removeAt(index);
                        // You could notify listeners here if necessary
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Error: ${unblockProvider.errorMessage}. Please try again.',
                              style: TextStyle(fontSize: 16.sp),
                            ),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    ),
                    child: Text(
                      'Unblock',
                      style: TextStyle(fontSize: 14.sp, color: Colors.white),
                    ),
                  ),
                  contentPadding: EdgeInsets.zero,
                  minVerticalPadding: 8.h,
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      RouteName.friendsProfileScreen,
                      arguments: {'postId': blockedUser?.id},
                    );
                  },
                );
              },
            ),
        ],
      ),
    );
  }
}
