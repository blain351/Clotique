import 'package:clotique/views/feed/screens/report/report_intellectual.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class ReportUserPage extends StatelessWidget {
  const ReportUserPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Report User',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Why are you reporting this user?',
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 8.h),
            Text(
              'Your report is anonymous. If someone is in immediate danger, call local emergency services.',
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 24.h),
            _buildReportOption(context, 'It\'s spam', () {
              print('Report option selected: It\'s spam');
            }),
            _buildReportOption(context, 'Inappropriate content or profile', () {
              print('Report option selected: Inappropriate content or profile');
            }),
            _buildReportOption(context, 'Hate speech or symbols', () {
              print('Report option selected: Hate speech or symbols');
            }),
            _buildReportOption(context, 'Impersonation or pretending to be someone else', () {
              print('Report option selected: Impersonation or pretending to be someone else');
            }),
            _buildReportOption(context, 'Intellectual property violation', () {
              print('Report option selected: Intellectual property violation');
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ReportUserDetailPage(
                    selectedReason: 'Intellectual property violation',
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildReportOption(BuildContext context, String text, VoidCallback onTap) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        title: Text(
          text,
          style: TextStyle(fontSize: 16.sp, color: Colors.black),
        ),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }
}