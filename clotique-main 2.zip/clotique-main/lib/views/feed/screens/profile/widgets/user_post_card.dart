import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../../../cors/routes/routes_name.dart';

class UserPostCard extends StatelessWidget {
  final String avatarUrl;
  final String userName;
  final String postTime;
  final String postImageUrl;
  final String caption;
  final String postId;
  final Function onPostDelete;
  final Function onPostEdit;

  const UserPostCard({
    super.key,
    required this.avatarUrl,
    required this.userName,
    required this.postTime,
    required this.postImageUrl,
    required this.caption,
    required this.postId,
    required this.onPostDelete,
    required this.onPostEdit,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: Colors.grey.shade300, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Post Header
          Row(
            children: [
              CircleAvatar(
                radius: 22,
                child: Image.network(
                  avatarUrl,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.person_2_outlined);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    userName,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    DateFormat.yMMMd().add_jm().format(DateTime.parse(postTime)),
                    style: const TextStyle(fontSize: 14, color: Colors.black54),
                  ),
                ],
              ),
              const Spacer(),
              PopupMenuButton<String>(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.r),
                onSelected: (String result) {
                  if (result == 'Edit') {
                    onPostEdit();
                  } else if (result == 'Delete') {
                    onPostDelete();
                  }
                },
                itemBuilder: (BuildContext context) {
                  return [
                    PopupMenuItem<String>(
                      value: 'Edit',
                      child: Container(
                        width: double.infinity,
                        height: 30.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4.r),
                          color: Colors.grey.shade50,
                        ),
                        child: const Center(child: Text('Edit')),
                      ),
                    ),
                    PopupMenuItem<String>(
                      value: 'Delete',
                      child: Container(
                        width: double.infinity,
                        height: 30.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4.r),
                          color: Colors.grey.shade50,
                        ),
                        child: const Center(child: Text('Delete')),
                      ),
                    ),
                  ];
                },
                child: const Icon(Icons.more_vert),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Post Image
          Image.network(
            postImageUrl,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => Container(
              height: 220.h,
              color: Colors.grey[300],
              child: Center(
                child: Icon(
                  Icons.broken_image,
                  size: 50.w,
                  color: Colors.grey[600],
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Caption
          Text(
            caption,
            style: const TextStyle(fontSize: 16, color: Colors.black),
          ),
        ],
      ),
    );
  }
}
