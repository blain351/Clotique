import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../../view_model/friends/all_pending_request_provider/pending_request_provider.dart';

class AllFriends extends StatefulWidget {
  const AllFriends({super.key});

  @override
  _AllFriendsState createState() => _AllFriendsState();
}

class _AllFriendsState extends State<AllFriends> {
  bool isConnected = false;

  @override
  Widget build(BuildContext context) {
    // Retrieve the passed FriendData object
    final FriendData friendData = ModalRoute.of(context)!.settings.arguments as FriendData;
    final String name = friendData.name;
    final String username = friendData.username;
    final String avatar = friendData.avatar ?? '';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Profile',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 30),
                  child: Container(
                    height: 100.h,
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/post1.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 0.w,
                  right: 0.w,
                  bottom: -80.h,
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 40.r,
                        backgroundImage: NetworkImage(
                          avatar.isNotEmpty
                              ? avatar
                              : 'https://www.bing.com/images/search?view=detailV2&ccid=ElnGGnDp&id=984A413C71B5ABE46513EF787775932B9A7EB14A&thid=OIP.ElnGGnDpCGPTBRHQp-bjjQHaGN&mediaurl=https%3a%2f%2fi.pinimg.com%2foriginals%2f46%2f53%2f55%2f46535505093c4d0b5aa382c45f81d09e.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.1259c61a70e90863d30511d0a7e6e38d%3frik%3dSrF%252bmiuTdXd47w%26pid%3dImgRaw%26r%3d0&exph=816&expw=974&q=shinchan+vulgerity&simid=608026800307836935&FORM=IRPRST&ck=745292AB34F41E9E56FA00B8C69954C7&selectedIndex=15&itb=0',
                        ),
                      ),
                      Text(
                        name,
                        style: TextStyle(
                          fontSize: 20.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '@$username',
                        style: TextStyle(fontSize: 14.sp, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 100),
            Padding(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.9,
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              isConnected = !isConnected;
                            });

                            if (!isConnected) {
                              debugPrint('Connecting to user $name with username $username');
                              Provider.of<AllPendingRequestProvider>(context, listen: false)
                                  .fetchAllPendingRequests();
                            } else {
                              debugPrint('Canceling connection to user $name');
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: isConnected ? Colors.grey : const Color(0xff7E6BFA),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 16.w,
                              vertical: 8.h,
                            ),
                          ),
                          child: Text(
                            isConnected ? 'Cancel -' : '+ Connect',
                            style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16.h),
                  // About Section
                  Container(
                    padding: EdgeInsets.all(16.w),
                    margin: EdgeInsets.symmetric(
                      vertical: 8.h,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8.r),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          spreadRadius: 1,
                          blurRadius: 4,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "About ",
                                style: TextStyle(
                                  fontSize: 18.sp,
                                  color: Colors.black,
                                ),
                              ),
                              TextSpan(
                                text: name,
                                style: TextStyle(
                                  fontSize: 18.sp,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 8.h),
                        Text(
                          'Bio: User-focused on creating intuitive, user-friendly digital experiences.',
                          style: TextStyle(
                            fontSize: 14.sp,
                            color: Colors.black87,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16.h),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}



// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:provider/provider.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import '../report/report_user_page.dart';
//
// class AllFriends extends StatefulWidget {
//   const AllFriends({super.key});
//
//   @override
//   _AllFriendsState createState() => _AllFriendsState();
// }
//
// class _AllFriendsState extends State<AllFriends> {
//   bool isConnected = false;
//   FriendData? _friendData;
//
//   @override
//   void didChangeDependencies() {
//     super.didChangeDependencies();
//     final arguments = ModalRoute.of(context)!.settings.arguments;
//     if (arguments is FriendData) {
//       _friendData = arguments;
//     } else {
//       _friendData = FriendData(
//         id: 'unknown_id',
//         name: 'Unknown Name',
//         username: 'unknown_username',
//         avatar: '',
//         email: 'unknown@example.com',
//       );
//     }
//   }
//
//   void _showBlockUserDialog(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (BuildContext dialogContext) {
//         return Dialog(
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(16.r),
//           ),
//           child: Container(
//             padding: EdgeInsets.all(20.w),
//             decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.circular(16.r),
//             ),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Image.asset('assets/images/button.png', scale: 3),
//                 SizedBox(height: 16.h),
//                 Text(
//                   'Block User',
//                   style: TextStyle(
//                     fontSize: 20.sp,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black,
//                   ),
//                 ),
//                 SizedBox(height: 8.h),
//                 Text(
//                   'Are you sure you want to block this user?\nYou won\'t be able to see each other\'s\nprofile or send messages.',
//                   textAlign: TextAlign.center,
//                   style: TextStyle(
//                     fontSize: 14.sp,
//                     color: Colors.grey[600],
//                   ),
//                 ),
//                 SizedBox(height: 24.h),
//                 Row(
//                   children: [
//                     Expanded(
//                       child: ElevatedButton(
//                         onPressed: () {
//                           Navigator.of(dialogContext).pop();
//                         },
//                         style: ElevatedButton.styleFrom(
//                           backgroundColor: const Color(0xFFF6F8FA),
//                           foregroundColor: Colors.black,
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(8.r),
//                           ),
//                           padding: EdgeInsets.symmetric(vertical: 12.h),
//                         ),
//                         child: Text(
//                           'Cancel',
//                           style: TextStyle(
//                               fontSize: 16.sp,
//                               fontWeight: FontWeight.bold,
//                               color: const Color(0xFF777980)),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 12.w),
//                     Expanded(
//                       child: ElevatedButton(
//                         onPressed: () {
//                           print('User Blocked: ${_friendData?.name ?? 'Unknown'} (ID: ${_friendData?.id ?? 'N/A'})');
//                           // TODO: Implement actual API call to block user using _friendData.id
//                           Navigator.of(dialogContext).pop();
//                         },
//                         style: ElevatedButton.styleFrom(
//                           backgroundColor: Colors.red[600],
//                           foregroundColor: Colors.white,
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(8.r),
//                           ),
//                           padding: EdgeInsets.symmetric(vertical: 12.h),
//                         ),
//                         child: Text(
//                           'Yes, Block',
//                           style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final String name = _friendData?.name ?? 'Unknown Name';
//     final String username = _friendData?.username ?? 'Unknown Username';
//     final String avatar = _friendData?.avatar.isNotEmpty == true
//         ? _friendData!.avatar
//         : 'https://www.bing.com/images/search?view=detailV2&ccid=ElnGGnDp&id=984A413C71B5ABE46513EF787775932B9A7EB14A&thid=OIP.ElnGGnDpCGPTBRHQp-bjjQHaGN&mediaurl=https%3a%2f%2fi.pinimg.com%2foriginals%2f46%2f53%2f55%2f46535505093c4d0b5aa382c45f81d09e.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.1259c61a70e90863d30511d0a7e6e38d%3frik%3dSrF%252bmiuTdXd47w%26pid%3dImgRaw%26r%3d0&exph=816&expw=974&q=shinchan+vulgerity&simid=608026800307836935&FORM=IRPRST&ck=745292AB34F41E9E56FA00B8C69954C7&selectedIndex=15&itb=0';
//
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         centerTitle: true,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.black),
//           onPressed: () => Navigator.pop(context),
//         ),
//         title: const Text(
//           'Friend Profile',
//           style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
//         ),
//       ),
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             Stack(
//               clipBehavior: Clip.none,
//               children: [
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 30.w),
//                   child: Container(
//                     height: 120.h,
//                     decoration: const BoxDecoration(
//                       image: DecorationImage(
//                         image: AssetImage("assets/images/post1.png"),
//                         fit: BoxFit.cover,
//                       ),
//                     ),
//                   ),
//                 ),
//                 Positioned(
//                   left: 0.w,
//                   right: 0.w,
//                   bottom: -80.h,
//                   child: Column(
//                     children: [
//                       CircleAvatar(
//                         radius: 50.r,
//                         backgroundImage: NetworkImage(avatar),
//                       ),
//                       Text(
//                         name,
//                         style: TextStyle(
//                           fontSize: 22.sp,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                       Text(
//                         '@$username',
//                         style: TextStyle(fontSize: 16.sp, color: Colors.grey),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//             SizedBox(height: 80.h),
//             Padding(
//               padding: EdgeInsets.all(16.w),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       SizedBox(
//                         width: MediaQuery.of(context).size.width * 0.7,
//                         child: ElevatedButton(
//                           onPressed: () {
//                           },
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.black,
//                             foregroundColor: Colors.white,
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(8.r),
//                             ),
//                             padding: EdgeInsets.symmetric(
//                               horizontal: 16.w,
//                               vertical: 8.h,
//                             ),
//                           ),
//                           child: Row(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             children: [
//                               SvgPicture.asset(
//                                 'assets/icons/edit_profile.svg',
//                                 width: 24,
//                                 height: 24,
//                                 colorFilter: const ColorFilter.mode(Colors.white, BlendMode.srcIn),
//                               ),
//                               const SizedBox(width: 8),
//                               Text(
//                                 'Friends',
//                                 style: TextStyle(
//                                   fontSize: 16.sp,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 8.w),
//                       Container(
//                         width: 50.w,
//                         height: 48.h,
//                         decoration: BoxDecoration(
//                           color: Colors.grey[200],
//                           borderRadius: BorderRadius.circular(8.r),
//                         ),
//                         child: PopupMenuButton<String>(
//                           icon: Icon(Icons.more_horiz, color: Colors.black, size: 24.sp),
//                           offset: Offset(0, 50.h),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(8.r),
//                           ),
//                           itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
//                             PopupMenuItem<String>(
//                               value: 'block',
//                               child: Text('Block', style: TextStyle(fontSize: 14.sp)),
//                             ),
//                             PopupMenuItem<String>(
//                               value: 'report',
//                               child: Text('Report', style: TextStyle(fontSize: 14.sp)),
//                               onTap: () {
//                                 WidgetsBinding.instance.addPostFrameCallback((_) {
//                                   Navigator.push(
//                                     context,
//                                     MaterialPageRoute(builder: (context) => const ReportUserPage()),
//                                   );
//                                 });
//                               },
//                             ),
//                           ],
//                           onSelected: (String value) {
//                             if (value == 'block') {
//                               _showBlockUserDialog(context);
//                             } else if (value == 'report') {
//                               print('Report selected for user: ${name}');
//                             }
//                           },
//                           padding: EdgeInsets.zero,
//                         ),
//                       )
//                     ],
//                   ),
//                   SizedBox(height: 16.h),
//                   Container(
//                     padding: EdgeInsets.all(16.w),
//                     margin: EdgeInsets.symmetric(vertical: 8.h),
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(8.r),
//                       boxShadow: [
//                         BoxShadow(
//                           color: Colors.black.withOpacity(0.1),
//                           spreadRadius: 1,
//                           blurRadius: 4,
//                           offset: const Offset(0, 2),
//                         ),
//                       ],
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         RichText(
//                           text: TextSpan(
//                             children: [
//                               TextSpan(
//                                 text: "About ",
//                                 style: TextStyle(
//                                   fontSize: 18.sp,
//                                   color: Colors.black,
//                                 ),
//                               ),
//                               TextSpan(
//                                 text: name,
//                                 style: TextStyle(
//                                   fontSize: 18.sp,
//                                   color: Colors.black,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                         SizedBox(height: 8.h),
//                         Text(
//                           'Bio: User-focused on creating intuitive, user-friendly digital experiences.',
//                           style: TextStyle(
//                             fontSize: 14.sp,
//                             color: Colors.black87,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   SizedBox(height: 16.h),
//                   _buildPostCard(
//                     context,
//                     'Kathryn Murphy',
//                     '10 min ago',
//                     'assets/images/post2.png',
//                     'My today\'s outfit! 😊',
//                     1000,
//                     3500,
//                     1500,
//                   ),
//                   _buildPostCard(
//                     context,
//                     'Kathryn Murphy',
//                     '10 min ago',
//                     'assets/images/post1.png',
//                     '',
//                     7000,
//                     5000,
//                     2000,
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildPostCard(
//       BuildContext context,
//       String username,
//       String time,
//       String imagePath,
//       String caption,
//       int likes,
//       int comments,
//       int shares,
//       ) {
//     return Card(
//       margin: EdgeInsets.only(bottom: 16.h),
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           ListTile(
//             leading: CircleAvatar(
//               radius: 20.r,
//               backgroundImage: AssetImage(imagePath),
//             ),
//             title: Text(
//               username,
//               style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
//             ),
//             subtitle: Text(
//               time,
//               style: TextStyle(fontSize: 12.sp, color: Colors.grey),
//             ),
//             trailing: Row(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Icon(Icons.favorite_border, size: 16.sp, color: Colors.grey),
//                 SizedBox(width: 4.w),
//                 Icon(Icons.bookmark_border, size: 16.sp, color: Colors.grey),
//               ],
//             ),
//           ),
//           Container(
//             height: 200.h,
//             decoration: BoxDecoration(
//               image: DecorationImage(
//                 image: AssetImage(imagePath),
//                 fit: BoxFit.cover,
//               ),
//               borderRadius: BorderRadius.vertical(top: Radius.circular(12.r)),
//             ),
//           ),
//           if (caption.isNotEmpty)
//             Padding(
//               padding: EdgeInsets.all(8.w),
//               child: Text(caption, style: TextStyle(fontSize: 14.sp)),
//             ),
//           Padding(
//             padding: EdgeInsets.all(8.w),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Row(
//                   children: [
//                     Icon(Icons.favorite, size: 16.sp, color: Colors.red),
//                     SizedBox(width: 4.w),
//                     Text('$likes', style: TextStyle(fontSize: 14.sp)),
//                   ],
//                 ),
//                 Row(
//                   children: [
//                     Icon(
//                       Icons.chat_bubble_outline,
//                       size: 16.sp,
//                       color: Colors.grey,
//                     ),
//                     SizedBox(width: 4.w),
//                     Text('$comments', style: TextStyle(fontSize: 14.sp)),
//                   ],
//                 ),
//                 Row(
//                   children: [
//                     Icon(Icons.share, size: 16.sp, color: Colors.grey),
//                     SizedBox(width: 4.w),
//                     Text('$shares', style: TextStyle(fontSize: 14.sp)),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
//
// class FriendData {
//   final String id;
//   final String name;
//   final String username;
//   final String avatar;
//   final String email;
//
//   FriendData({
//     required this.id,
//     required this.name,
//     required this.username,
//     required this.avatar,
//     required this.email,
//   });
//
//   // A method to convert JSON data to FriendData (if needed)
//   factory FriendData.fromJson(Map<String, dynamic> json) {
//     return FriendData(
//       id: json['id'],
//       name: json['name'],
//       username: json['username'],
//       avatar: json['avatar'],
//       email: json['email'],
//     );
//   }
//
//   // A method to convert FriendData to JSON (if needed)
//   Map<String, dynamic> toJson() {
//     return {
//       'id': id,
//       'name': name,
//       'username': username,
//       'avatar': avatar,
//       'email': email,
//     };
//   }
// }
class FriendData {
  final String id;
  final String name;
  final String username;
  final String avatar;
  final String email;

  FriendData({
    required this.id,
    required this.name,
    required this.username,
    required this.avatar,
    required this.email,
  });

  // A method to convert JSON data to FriendData (if needed)
  factory FriendData.fromJson(Map<String, dynamic> json) {
    return FriendData(
      id: json['id'],
      name: json['name'],
      username: json['username'],
      avatar: json['avatar'],
      email: json['email'],
    );
  }

  // A method to convert FriendData to JSON (if needed)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'username': username,
      'avatar': avatar,
      'email': email,
    };
  }
}