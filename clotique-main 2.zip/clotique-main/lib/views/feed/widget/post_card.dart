import 'dart:ffi';

import 'package:clotique/cors/routes/routes_name.dart';
import 'package:clotique/view_model/feed/create_comment_provider.dart';
import 'package:clotique/view_model/feed/feed_view_model.dart';
import 'package:clotique/view_model/feed/like_post_provider.dart';
import 'package:clotique/view_model/feed/share_post_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class PostCard extends StatelessWidget {
  final String avatarUrl;
  final String userName;
  final String postTime;
  final String postImageUrl;
  final String caption;
  final String? likes;
  final String? comments;
  final String? shares;
  final String postId;
  final VoidCallback? onCommentTap;

  const PostCard({
    super.key,
    required this.avatarUrl,
    required this.userName,
    required this.postTime,
    required this.postImageUrl,
    required this.caption,
    this.likes,
    this.comments,
    this.shares,
    required this.postId,
    this.onCommentTap,
  });

  @override
  Widget build(BuildContext context) {
    final feedViewModel = Provider.of<FeedViewModel>(context);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: Colors.grey.shade300, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Post Header
          Row(
            children: [
              CircleAvatar(
                radius: 22,
                child: Image.network(
                  avatarUrl,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.person_2_outlined);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    userName,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    postTime,
                    style: const TextStyle(fontSize: 14, color: Colors.black54),
                  ),
                ],
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, RouteName.compareOutfitScreen);
                },
                child: Image.asset(
                  "assets/icons/compare.png",
                  color: Color(0xFF8A5DFF),
                  scale: 2.3,
                ),
              ),
              SizedBox(width: 16.w),
              Image.asset("assets/icons/copy.png", color: Color(0xFF000000)),
            ],
          ),
          const SizedBox(height: 16),

          // Post Image
          Image.network(
            postImageUrl,
            fit: BoxFit.cover,
            errorBuilder:
                (context, error, stackTrace) => Container(
                  height: 220.h,
                  color: Colors.grey[300],
                  child: Center(
                    child: Icon(
                      Icons.broken_image,
                      size: 50.w,
                      color: Colors.grey[600],
                    ),
                  ),
                ),
          ),

          const SizedBox(height: 16),

          // Caption
          Text(
            caption,
            style: const TextStyle(fontSize: 16, color: Colors.black),
          ),
          const SizedBox(height: 16),

          // Action Buttons (Likes, Comments, Shares)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Consumer<LikePostProvider>(
                builder: (_, likePostProvider, __) {
                  return GestureDetector(
                    onTap: () async {
                      if (likePostProvider.isLoading ||
                          likePostProvider.isGetLoading)
                        return;

                      int optimisticLikeCount =
                          likePostProvider.isLiked == true
                              ? (likePostProvider.likeCount ?? 0) - 1
                              : (likePostProvider.likeCount ?? 0) + 1;
                      feedViewModel.updateLikeCount(
                        postId,
                        optimisticLikeCount,
                      );

                      try {
                        bool success = await likePostProvider.likePost(postId);
                        if (success) {
                          await likePostProvider.getLikeCount(postId);
                          if (likePostProvider.getErrorMessage.isEmpty) {
                            feedViewModel.updateLikeCount(
                              postId,
                              likePostProvider.likeCount ?? 0,
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(likePostProvider.getErrorMessage),
                              ),
                            );
                          }
                        } else {
                          // Revert optimistic update
                          feedViewModel.updateLikeCount(
                            postId,
                            likePostProvider.likeCount ?? 0,
                          );
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(likePostProvider.errorMessage),
                            ),
                          );
                        }
                      } catch (e) {
                        feedViewModel.updateLikeCount(
                          postId,
                          likePostProvider.likeCount ?? 0,
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('An error occurred: $e')),
                        );
                      }
                    },
                    child: _buildActionButton(
                      icon: 'assets/icons/favorite.png',
                      text: likes ?? '0',
                      color: const Color(0xFFFF4D6D),
                    ),
                  );
                },
              ),
              Consumer<CreateCommentProvider>(
                builder: (_, createCommentProvider, __) {
                  return GestureDetector(
                    onTap: onCommentTap,
                    child: _buildActionButton(
                      icon: 'assets/icons/comment.png',
                      text: comments ?? '0',
                    ),
                  );
                },
              ),
              Consumer<SharePostProvider>(
                builder: (_, sharePostProvider, __) {
                  return GestureDetector(
                    onTap: () async {
                      await sharePostProvider.sharePost(context, postId);
                      await context.read<FeedViewModel>().userFeed();
                    },
                    child: _buildActionButton(
                      icon: "assets/icons/share.png",
                      text: shares ?? '0',
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required String icon,
    required String text,
    Color? color,
  }) {
    return Row(
      children: [
        Image.asset(icon, color: color ?? Colors.black87, height: 24),
        const SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(
            color: color ?? Colors.black87,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
