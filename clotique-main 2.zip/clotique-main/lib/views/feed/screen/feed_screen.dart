import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../cors/routes/routes_name.dart';
import '../../../view_model/auth/check_me/user_details_provider.dart';
import '../../../view_model/feed/create_comment_provider.dart';
import '../../../view_model/feed/feed_view_model.dart';
import '../widget/create_post_header.dart';
import '../widget/header_widget_feed.dart';
import '../widget/post_card.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});

  @override
  _FeedScreenState createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    // Load initial feed
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FeedViewModel>().userFeed();
    });

    // Add scroll listener for pagination
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent * 0.9 &&
          !context.read<FeedViewModel>().inProgress) {
        context.read<FeedViewModel>().userFeed();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final feedViewModel = Provider.of<FeedViewModel>(context);
    final createCommentProvider = Provider.of<CreateCommentProvider>(context);
    final userDetailsProvider = Provider.of<UserDetailsProvider>(context);

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () => context.read<FeedViewModel>().refreshFeed(),
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Column(
            children: [
              HeaderWidgetFeed(),
              SizedBox(height: 20.h),
              CreatePostHeader(
                imageUrl:
                "${ApiEndPoint.baseUrl}/public/storage/avatar/${userDetailsProvider.userModel?.avatar ?? ''}",
              ),
              if (feedViewModel.initialLoadingInProgress)
                const Center(child: CircularProgressIndicator())
              else if (feedViewModel.errorMessage.isNotEmpty)
                Center(
                  child: Padding(
                    padding: EdgeInsets.all(16.w),
                    child: Text(
                      feedViewModel.errorMessage,
                      style: TextStyle(color: Colors.red, fontSize: 14.sp),
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              else if (feedViewModel.feedList.isEmpty)
                  Center(
                    child: Padding(
                      padding: EdgeInsets.all(16.w),
                      child: Text(
                        'No posts available',
                        style: TextStyle(fontSize: 14.sp),
                      ),
                    ),
                  )
                else
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: feedViewModel.feedList.length +
                        (feedViewModel.inProgress ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index == feedViewModel.feedList.length) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      final post = feedViewModel.feedList[index];
                      return PostCard(
                        postId: post.id,
                        avatarUrl: post.user?.avatar != null
                            ? "${ApiEndPoint.baseUrl}/public/storage/avatar/${post.user!.avatar}"
                            : 'assets/images/user2.png',
                        userName: post.user?.username ?? 'Unknown',
                        postTime: post.createTimeAgo,
                        postImageUrl: post.image.isNotEmpty
                            ? "${ApiEndPoint.baseUrl}/public/storage/avatar/${post.image}"
                            : 'https://via.placeholder.com/150',
                        caption: post.caption,
                        likes: post.likeCount.toString(),
                        comments: post.commentCount.toString(),
                        onCommentTap: () {
                          createCommentProvider.setSelectedPostId(post.id);
                          Navigator.pushNamed(context, RouteName.commentScreen);
                        },
                        shares: post.shareCount.toString(),
                      );
                    },
                    separatorBuilder: (context, index) => SizedBox(height: 16.h),
                  ),
              SizedBox(height: 70.h),
            ],
          ),
        ),
      ),
    );
  }
}