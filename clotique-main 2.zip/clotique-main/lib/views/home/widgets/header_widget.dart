import 'package:clotique/cors/routes/routes_name.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HeaderWidget extends StatelessWidget {
  final String? titleText;
  final String? descriptionText;
  final bool? isUserNameNull;

  const HeaderWidget({
    super.key,
    this.titleText,
    this.descriptionText,
    this.isUserNameNull,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 130.h,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF5E59FF), Color(0xFF9C7DF5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30.r),
          bottomRight: Radius.circular(30.r),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 4.h),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  titleText ?? '',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5.h),
                Text(
                  descriptionText ?? 'Welcome Back!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14.sp,
                  ),
                ),
                SizedBox(height: 2.h),
                if (isUserNameNull == true)
                  Text('Please complete your profile before proceeding', style: TextStyle(color: Colors.redAccent, fontSize: 13, fontWeight: FontWeight.w600),)
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 16.0),
              child: GestureDetector(
                onTap: () => Navigator.pushNamed(context, RouteName.notificationScreen),
                child: Icon(
                  Icons.notifications,
                  color: Colors.white,
                  size: 30.sp, // Dynamic icon size
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
