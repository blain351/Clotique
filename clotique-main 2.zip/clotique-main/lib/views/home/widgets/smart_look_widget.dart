import 'package:clotique/view_model/home/daily_smart_outfit_provider.dart';
import 'package:clotique/view_model/home/make_smart_post_favorite_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../cors/constant/api_end_point.dart';
import '../../../data/model/wardrobe/all_favourite_outfit_provider.dart';

class SmartLookWidget extends StatefulWidget {
  const SmartLookWidget({super.key});

  @override
  State<SmartLookWidget> createState() => _SmartLookWidgetState();
}

class _SmartLookWidgetState extends State<SmartLookWidget> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  // final List<String> _imageUrls = [
  //   'https://cdn.mos.cms.futurecdn.net/yhLo9uagotwDcGhSAHLp3P.jpg',
  //   'https://cdn.mos.cms.futurecdn.net/v2/t:0,l:0,cw:1920,ch:1080,q:80,w:1920/BoGzcrGyTjPBKiFPU3bWUW.jpg',
  //   'https://azuro-republic.com/cdn/shop/articles/summer_outfit.jpg?v=1618911906&width=2048',
  // ];

  @override
  void initState() {
    super.initState();
    _pageController.addListener(() {
      int nextP = _pageController.page!.round();
      if (nextP != _currentPage) {
        setState(() {
          _currentPage = nextP;
        });
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.all(16.0.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Today's Smart Look",
              style: TextStyle(
                fontSize: 22.sp,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 20.h),
            Container(
              width: double.infinity,
              constraints: BoxConstraints(maxHeight: 600.h),
              child: Consumer<DailySmartOutfitProvider>(
                  builder: (_, dailySmartOutfitProvider, __) {
                    if (dailySmartOutfitProvider.isLoading) {
                      return Center(child: CircularProgressIndicator());
                    }

                    if (dailySmartOutfitProvider.errorMessage.isNotEmpty) {
                      return Center(child: Text(dailySmartOutfitProvider.errorMessage));
                    }

                    if (dailySmartOutfitProvider.response.isEmpty) {
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            height: 220.h,
                            color: Colors.grey[300],
                            child: Center(
                              child: Icon(
                                Icons.broken_image,
                                size: 50.w,
                                color: Colors.grey[600],
                              ),
                            ),),
                          SizedBox(height: 100.h),
                          Text('No data available')
                        ],
                      );
                    }
                    return Column(
                      children: [
                        Row(
                          children: [
                            _buildInfoChip(
                              assetPath: 'assets/icons/cloud_color.png',
                              text: "${dailySmartOutfitProvider.response[_currentPage].temperature.toString()}°C, ${dailySmartOutfitProvider.response[_currentPage].city}",
                            ),
                            SizedBox(width: 10.w),
                            _buildInfoChip(
                              assetPath: 'assets/icons/calender.png',
                              text: dailySmartOutfitProvider.response[_currentPage].style,
                            ),
                          ],
                        ),
                        SizedBox(height: 20.h),
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20.r),
                            child: Stack(
                              children: [
                                PageView.builder(
                                  controller: _pageController,
                                  itemCount: dailySmartOutfitProvider.response.length,
                                  itemBuilder: (context, index) {
                                    return Image.network(
                                      "${ApiEndPoint.baseUrl}/public${dailySmartOutfitProvider.response[index].imageUrl}",
                                      fit: BoxFit.cover,
                                      width: double.infinity,
                                      height: double.infinity,
                                      errorBuilder: (context, error, stackTrace) => Container(
                                        color: Colors.grey[300],
                                        child: Center(
                                          child: Icon(
                                            Icons.broken_image,
                                            size: 50.w,
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                Positioned(
                                  top: 15.h,
                                  right: 15.w,
                                  child: Consumer<MakeSmartPostFavoriteProvider>(
                                      builder: (_, makeSmartPostFavoriteProvider, __) {
                                        return GestureDetector(
                                          onTap: () async {
                                            debugPrint('PostId in home: ${dailySmartOutfitProvider.response[_currentPage].id}');
                                            final isFavorite = await makeSmartPostFavoriteProvider.makeSmartPostFavorite(dailySmartOutfitProvider.response[_currentPage].id);
                                            if (isFavorite) {
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                SnackBar(
                                                  content: Text('Added to favorites'),
                                                ),
                                              );
                                              context.read<AllFavouriteOutfitProvider>().refreshFavouriteOutfits();
                                            } else {
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                SnackBar(
                                                  content: Text('Failed to add to favorites'),
                                                ),
                                              );
                                            }
                                          },
                                          child: Container(
                                            padding: EdgeInsets.all(8.w),
                                            decoration: BoxDecoration(
                                              color: Colors.white.withOpacity(0.8),
                                              shape: BoxShape.circle,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black.withOpacity(0.1),
                                                  blurRadius: 5,
                                                  spreadRadius: 2,
                                                ),
                                              ],
                                            ),
                                            child: Icon(
                                              makeSmartPostFavoriteProvider.isFavorite && makeSmartPostFavoriteProvider.postId == dailySmartOutfitProvider.response[_currentPage].id ? Icons.favorite : Icons.favorite_border,
                                              color: makeSmartPostFavoriteProvider.isFavorite && makeSmartPostFavoriteProvider.postId == dailySmartOutfitProvider.response[_currentPage].id ? Colors.deepPurpleAccent :Colors.grey[600],
                                              size: 20.w,
                                            ),
                                          ),
                                        );
                                      }
                                  ),
                                ),
                                Positioned(
                                  bottom: 10.h,
                                  right: 10.w,
                                  child: Container(
                                    padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.6),
                                      borderRadius: BorderRadius.circular(5.r),
                                    ),
                                    child: Text(
                                      'AI',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 10.sp,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 20.h),
                        Container(
                          height: 120.h,
                          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20.r),
                            border: Border.all(color: const Color(0xFFE0D7FC), width: 1.w),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.1),
                                spreadRadius: 2,
                                blurRadius: 10,
                                offset: Offset(0, 5.h),
                              ),
                            ],
                          ),
                          child: SingleChildScrollView(
                            child: Text(
                              dailySmartOutfitProvider.response[_currentPage].description,
                              style: TextStyle(
                                fontSize: 14.sp,
                                color: Colors.grey[700],
                                height: 1.5,
                              ),
                              textAlign: TextAlign.justify,
                            ),
                          ),
                        ),
                        SizedBox(height: 20.h),
                        Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: List.generate(dailySmartOutfitProvider.response.length, (index) {
                              return Container(
                                margin: EdgeInsets.symmetric(horizontal: 4.w),
                                width: _currentPage == index ? 24.w : 8.w,
                                height: 8.h,
                                decoration: BoxDecoration(
                                  color: _currentPage == index
                                      ? Colors.deepPurpleAccent
                                      : Colors.grey[300],
                                  borderRadius: BorderRadius.circular(4.r),
                                ),
                              );
                            }),
                          ),),
                      ],
                    );
                  }
              ),
            ),
            SizedBox(height: 30.h),
            Center(
              child: Container(
                height: 60.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30.r),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.deepPurpleAccent.withOpacity(0.3),
                      blurRadius: 10,
                      offset: Offset(0, 5.h),
                    ),
                  ],
                  gradient: const LinearGradient(
                    colors: [Color(0xFF5E59FF), Color(0xFF9C7DF5)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: ElevatedButton(
                  onPressed: () {
                    print('Plan by Event button pressed!');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.r),
                    ),
                    padding: EdgeInsets.zero,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Plan by Event",
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(width: 10.w),
                      Icon(
                        Icons.arrow_forward,
                        color: Colors.white,
                        size: 20.w,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 20.h),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip({
    required String assetPath,
    required String text,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30.r),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: Offset(0, 3.h),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(assetPath, width: 16.w, height: 16.w),
          SizedBox(width: 8.w),
          Text(
            text,
            style: TextStyle(
              fontSize: 13.sp,
              color: Colors.grey[700],
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
