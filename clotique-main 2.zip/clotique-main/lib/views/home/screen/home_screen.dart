import 'package:clotique/view_model/auth/check_me/user_details_provider.dart';
import 'package:clotique/views/home/widgets/header_widget.dart';
import 'package:clotique/views/home/widgets/smart_look_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../widgets/create_share_look_widget.dart';
import '../widgets/event_outfit_widget.dart';
import '../widgets/today_weather_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  @override
  void initState() {
    super.initState();
    context.read<UserDetailsProvider>().getUserDetails();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<UserDetailsProvider>();
    print('user details name: ${provider.userModel?.name}');
    return Scaffold(
      body: Container(
        color: Colors.grey[100],
        child: SingleChildScrollView(
          child: Column(
            children: [
              HeaderWidget(titleText: "Hello, ${provider.userModel?.name ?? 'User'}!", descriptionText: "Welcome Back!", isUserNameNull: provider.userModel?.name == null,),
              SmartLookWidget(),
              SizedBox(height: 20),
              EventOutfitWidget(),
              TodayWeatherWidget(),
              CreateShareLookWidget(),
              SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }
}
