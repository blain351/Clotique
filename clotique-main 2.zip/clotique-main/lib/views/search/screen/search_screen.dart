import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:clotique/data/model/search/search_response.dart';

import '../../../view_model/search/search_viewmodel.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String _selectedFilter = 'All';
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final searchViewModel = Provider.of<SearchViewModel>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Container(
          height: 40.h,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(30),
          ),
          child: TextField(
            onChanged: (query) {
              searchViewModel.updateSearchQuery(query, _selectedFilter);
              if (query.isNotEmpty) {
                searchViewModel.search(query, _selectedFilter);
              } else {
                searchViewModel.clearSearch();
              }
            },
            decoration: const InputDecoration(
              hintText: 'Search outfits, users, tags...',
              hintStyle: TextStyle(color: Colors.grey),
              suffixIcon: Icon(Icons.search, color: Color(0xFF7E6BFA)),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: <Widget>[
                FilterChip(
                  label: const Text('All'),
                  selected: _selectedFilter == 'All',
                  onSelected: (bool selected) {
                    setState(() {
                      _selectedFilter = 'All';
                      if (searchViewModel.searchQuery.isNotEmpty) {
                        searchViewModel.updateSearchQuery(searchViewModel.searchQuery, _selectedFilter);
                        searchViewModel.search(searchViewModel.searchQuery, _selectedFilter);
                      }
                    });
                  },
                  selectedColor: const Color(0xFF7E6BFA),
                  labelStyle: TextStyle(
                    color: _selectedFilter == 'All' ? Colors.white : Colors.black,
                  ),
                  backgroundColor: Colors.grey[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                const SizedBox(width: 10),
                FilterChip(
                  label: const Text('Post'),
                  selected: _selectedFilter == 'Post',
                  onSelected: (bool selected) {
                    setState(() {
                      _selectedFilter = 'Post';
                      if (searchViewModel.searchQuery.isNotEmpty) {
                        searchViewModel.updateSearchQuery(searchViewModel.searchQuery, _selectedFilter);
                        searchViewModel.search(searchViewModel.searchQuery, _selectedFilter);
                      }
                    });
                  },
                  selectedColor: const Color(0xFF7E6BFA),
                  labelStyle: TextStyle(
                    color: _selectedFilter == 'Post' ? Colors.white : Colors.black,
                  ),
                  backgroundColor: Colors.grey[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                const SizedBox(width: 10),
                FilterChip(
                  label: const Text('People'),
                  selected: _selectedFilter == 'People',
                  onSelected: (bool selected) {
                    setState(() {
                      _selectedFilter = 'People';
                      if (searchViewModel.searchQuery.isNotEmpty) {
                        searchViewModel.updateSearchQuery(searchViewModel.searchQuery, _selectedFilter);
                        searchViewModel.search(searchViewModel.searchQuery, _selectedFilter);
                      }
                    });
                  },
                  selectedColor: const Color(0xFF7E6BFA),
                  labelStyle: TextStyle(
                    color: _selectedFilter == 'People' ? Colors.white : Colors.black,
                  ),
                  backgroundColor: Colors.grey[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: searchViewModel.isLoading
                  ? const Center(child: CircularProgressIndicator(color: Color(0xFF7E6BFA)))
                  : searchViewModel.searchResults.isNotEmpty
                  ? ListView.builder(
                itemCount: searchViewModel.searchResults.length,
                itemBuilder: (context, index) {
                  var result = searchViewModel.searchResults[index];
                  bool isPost = result.caption != null || result.image != null;
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: isPost
                          ? (result.image != null && result.image!.isNotEmpty
                          ? NetworkImage(result.image!)
                          : const AssetImage('assets/default_post.png') as ImageProvider)
                          : (result.avatar != null && result.avatar!.isNotEmpty
                          ? NetworkImage(result.avatar!)
                          : const AssetImage('assets/default_avatar.png') as ImageProvider),
                    ),
                    title: Text(isPost
                        ? (result.caption ?? 'Untitled Post')
                        : (result.username ?? 'Unknown User')),
                    subtitle: Text(isPost
                        ? (result.createdAt ?? 'No date available')
                        : (result.bio ?? 'No bio available')),
                    onTap: () {
                      // Handle item tap, navigate to detail screen if needed
                    },
                  );
                },
                controller: _scrollController
                  ..addListener(() {
                    if (_scrollController.position.pixels ==
                        _scrollController.position.maxScrollExtent &&
                        searchViewModel.currentPage < searchViewModel.totalPages) {
                      searchViewModel.search(
                        searchViewModel.searchQuery,
                        searchViewModel.selectedFilter,
                        page: searchViewModel.currentPage + 1,
                      );
                    }
                  }),
              )
                  : const Center(child: Text('No results found')),
            ),
          ],
        ),
      ),
    );
  }
}