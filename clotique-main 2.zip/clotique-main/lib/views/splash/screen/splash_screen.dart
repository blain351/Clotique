import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../cors/routes/routes_name.dart';
import '../../../cors/services/token_storage.dart';
import '../../../cors/services/user_id_storage.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    _controller.forward();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(seconds: 3)); // Splash delay
      String? userId = await UserIdStorage().getUserId();
      String? token = await TokenStorage().getToken();
      if (userId != null || token != null) {
        Navigator.pushReplacementNamed(context, RouteName.parentScreen);
      } else {
        Navigator.pushReplacementNamed(context, RouteName.onboardingScreen);
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffffff),
      body: Stack(
        fit: StackFit.expand,
        children: [
          FadeTransition(
            opacity: _animation,
            child: Image.asset(
              'assets/onboarding/splash.png',
              height: 236.h,
              width: 117.w,
            ),
          ),
        ],
      ),
    );
  }
}
