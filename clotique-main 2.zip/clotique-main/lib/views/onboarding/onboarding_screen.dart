import 'package:clotique/cors/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../cors/routes/routes_name.dart';
import '../parent_screen/screen/parent_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<Map<String, dynamic>> onboardingData = [
    {
      "image": 'assets/onboarding/onboarding_one.png',
      "titleWidgets": "Your Personal Fashion Assistant",
      "subtitle":
          'Let Clotique build outfits using the clothes you already own.',
    },
    {
      "image": 'assets/onboarding/onboarding_two.png',
      "titleWidgets": "Stay Weather-Ready",
      "subtitle": 'We match your outfit to today’s weather — rain or shine.',
    },
    {
      "image": 'assets/onboarding/onboarding_three.png',
      "titleWidgets": "Compare Looks with Friends",
      "subtitle": 'See what others are wearing and share your own style.',
    },
    {
      "image": 'assets/onboarding/onboarding_four.png',
      "titleWidgets": "Share with Your Friends",
      "subtitle":
          'Calculate mortgages, rental yields, ROI, and more — all in one place.',
    },
  ];

  void _goToLogin() {
    Navigator.pushNamed(context, RouteName.loginOrSignup);
  }

  void _nextPage() {
    if (_currentPage < onboardingData.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _goToLogin();
    }
  }

  void _skip() {
    _goToLogin();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              itemCount: onboardingData.length,
              onPageChanged: (index) {
                setState(() => _currentPage = index);
              },
              itemBuilder: (context, index) {
                final item = onboardingData[index];
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.w),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(item["image"]!, height: 300.h),
                      SizedBox(height: 50.h),
                      Text(
                        item["titleWidgets"]!,
                        style: TextStyle(
                          fontSize: 24.sp,
                          fontWeight: FontWeight.w500,
                          color: Color(0xff212121),
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 16.h),
                      Text(
                        item["subtitle"]!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w400,
                          color: Color(0xff757575),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          SizedBox(height: 20.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              onboardingData.length,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                height: 10.h,
                width: _currentPage == index ? 24.w : 10.w,
                decoration: BoxDecoration(
                  color:
                      _currentPage == index
                          ? Color(0xff7E6BFA)
                          : Color(0xffEBEBEB),
                  borderRadius: BorderRadius.circular(4.r),
                ),
              ),
            ),
          ),
          SizedBox(height: 50.h),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _currentPage == onboardingData.length - 1
                    ? SizedBox.shrink()
                    : SizedBox(
                      width: MediaQuery.of(context).size.width * 0.3,
                      child: ElevatedButton(
                        onPressed: _skip,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xffF6F8FA),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(32.r),
                          ),
                          padding: EdgeInsets.symmetric(
                            vertical: 10.h,
                            horizontal: 20.w,
                          ),
                        ),
                        child: Text(
                          "Skip",
                          style: TextStyle(
                            fontSize: 16.sp,
                            color: Color(0xff212121),
                          ),
                        ),
                      ),
                    ),
                Padding(
                  padding: EdgeInsets.only(right: 24.w),
                  child: SizedBox(
                    width:
                        _currentPage == onboardingData.length - 1
                            ? MediaQuery.of(context).size.width * 0.8
                            : MediaQuery.of(context).size.width * 0.5,
                    child: ElevatedButton(
                      onPressed: _nextPage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xff7E6BFA),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(32.r),
                        ),
                        padding: EdgeInsets.symmetric(
                          vertical: 10.h,
                          horizontal: 20.w,
                        ),
                      ),
                      child: Text(
                        _currentPage == onboardingData.length - 1
                            ? "Get Started"
                            : "Next",
                        style: TextStyle(fontSize: 16.sp, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 32.h),
        ],
      ),
    );
  }
}
