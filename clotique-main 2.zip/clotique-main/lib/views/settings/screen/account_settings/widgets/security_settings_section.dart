import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:async';

import '../dialogs/settings_helper_widgets.dart';
import '../dialogs/show_enable_2fa_dialog.dart'; // Import for Timer


class SecuritySettingsSection extends StatefulWidget {
  const SecuritySettingsSection({super.key});

  @override
  State<SecuritySettingsSection> createState() => _SecuritySettingsSectionState();
}

class _SecuritySettingsSectionState extends State<SecuritySettingsSection> {
  bool _isTwoFactorEnabled = true;
  bool _isEmailVerified = false;

  final TextEditingController _emailController = TextEditingController();

  late Timer _timer;
  int _resendCountdown = 59;

  @override
  void initState() {
    super.initState();
    // Initialize timer if needed, but typically starts on dialog open
  }

  @override
  void dispose() {
    _emailController.dispose();
    if (_timer.isActive) { // Check if timer is active before cancelling
      _timer.cancel(); // Cancel timer to prevent memory leaks
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section Header (as seen in the full Account Settings screen)
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.w),
          child: Text(
            'Security',
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade600,
            ),
          ),
        ),
        SizedBox(height: 12.h),

        // Two-Factor Authentication Toggle Item
        _buildTwoFactorAuthItem(context),
        SizedBox(height: 12.h),

        // Change Email Navigation Item
        buildNavigationSettingsItem(
          context,
          icon: Icons.mail_outline, // Envelope icon
          title: 'Change Email',
          onTap: () {
            print('Change Email tapped');
            // Navigate to Change Email screen
          },
        ),
        SizedBox(height: 12.h),

        // Change Password Navigation Item
        buildNavigationSettingsItem(
          context,
          icon: Icons.key_outlined, // Key icon for password
          title: 'Change Password',
          onTap: () {
            print('Change Password tapped');
            // Navigate to Change Password screen
          },
        ),
      ],
    );
  }

  // New method specifically for the Two-Factor Authentication item
  Widget _buildTwoFactorAuthItem(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w),
      padding: EdgeInsets.fromLTRB(20.w, 16.h, 10.w, 16.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.05),
            spreadRadius: 0,
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: const Color(0xFF6359FF).withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.security_outlined, // Shield icon
              color: const Color(0xFF6359FF),
              size: 24.sp,
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Text(
              'Two-Factor Authentication',
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Transform.scale(
            scale: 0.8,
            child: Switch(
              value: _isTwoFactorEnabled,
              onChanged: (bool newValue) {
                setState(() {
                  _isTwoFactorEnabled = newValue;
                });
                print('Two-Factor Authentication toggled to: $newValue');
                if (newValue) {
                  showEnable2FADialog(context, _isEmailVerified, (bool verified) {
                    setState(() {
                      _isEmailVerified = verified;
                    });
                  });
                }
              },
              activeColor: const Color(0xFF6359FF),
              activeTrackColor: const Color(0xFF6359FF).withOpacity(0.5),
              inactiveThumbColor: Colors.white,
              inactiveTrackColor: Colors.grey.shade300,
            ),
          ),
        ],
      ),
    );
  }
}