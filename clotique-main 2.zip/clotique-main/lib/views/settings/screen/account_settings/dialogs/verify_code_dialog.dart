import 'package:clotique/view_model/auth/enable_2fa/enable_2fa_verify_provider.dart';
import 'package:clotique/views/settings/screen/account_settings/dialogs/show_enable_2fa_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:async';
import 'package:provider/provider.dart';

import '../../../../../widget/pincode_text_field.dart';


void showVerifyCodeDialog(BuildContext context, Function(bool) onEmailVerified) {
  final TextEditingController otpController = TextEditingController();
  final otpVerifyProvider = Provider.of<Enable2FAVerifyProvider>(context);
  int resendCountdown = 59;
  late Timer timer;

  Dialog dialogBuilder(BuildContext dialogContext, StateSetter setDialogState) {
    // Start the countdown when the dialog is shown
    resendCountdown = 59;
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (resendCountdown == 0) {
        timer.cancel();
      } else {
        setDialogState(() {
          resendCountdown--;
        });
      }
    });

    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.r),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Container(
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Verify Code',
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.grey),
                  onPressed: () {
                    timer.cancel();
                    Navigator.of(dialogContext).pop();
                  },
                ),
              ],
            ),
            SizedBox(height: 20.h),
            Expanded(
              child: PincodeTextField(
                onChanged: otpVerifyProvider.setOtp,
                otpController: otpController,
              ),
            ),
            SizedBox(height: 24.h),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Resend: $resendCountdown' + 's',
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
            SizedBox(height: 24.h),
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                gradient: const LinearGradient(
                  colors: [Color(0xFF6359FF), Color(0xFF5A4BFF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: MaterialButton(
                onPressed: () {
                  print('Verify button tapped in Verify Code Dialog');
                  timer.cancel();
                  Navigator.of(dialogContext).pop();
                  onEmailVerified(true);
                  showEnable2FADialog(context, true, onEmailVerified);
                },
                padding: EdgeInsets.symmetric(vertical: 14.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Text(
                  'Verify',
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => StatefulBuilder(builder: dialogBuilder),
  ).then((_) {
    if (timer.isActive) {
      timer.cancel();
    }
  });
}