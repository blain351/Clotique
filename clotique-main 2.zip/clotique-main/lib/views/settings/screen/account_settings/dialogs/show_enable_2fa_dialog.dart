import 'package:clotique/views/settings/screen/account_settings/dialogs/settings_helper_widgets.dart';
import 'package:clotique/views/settings/screen/account_settings/dialogs/show_number_verify_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'email_verify_dialog.dart';
// Import the new dialog file

void showEnable2FADialog(BuildContext context, bool isEmailVerified, Function(bool) onEmailVerified) {
  showDialog(
    context: context,
    builder: (BuildContext dialogContext) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.r),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.all(20.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Enable 2FA',
                    style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: () {
                      Navigator.of(dialogContext).pop();
                    },
                  ),
                ],
              ),
              SizedBox(height: 20.h),
              buildDialogOptionItem(
                icon: Icons.mail_outline,
                title: 'Email verify',
                isVerified: isEmailVerified,
                onTap: () {
                  Navigator.of(dialogContext).pop();
                  showEmailVerifyDialog(context, onEmailVerified);
                },
              ),
              SizedBox(height: 12.h),
              buildDialogOptionItem(
                icon: Icons.vpn_key_outlined,
                title: 'Number verify',
                onTap: () {
                  Navigator.of(dialogContext).pop(); // Close the current dialog
                  showNumberVerifyDialog(context); // Open the new phone number verification dialog
                },
              ),
            ],
          ),
        ),
      );
    },
  );
}

