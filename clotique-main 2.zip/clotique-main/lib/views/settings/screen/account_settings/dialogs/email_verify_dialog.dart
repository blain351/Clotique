import 'dart:async';

import 'package:clotique/view_model/auth/enable_2fa/enable_2fa_request_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../../../view_model/auth/enable_2fa/enable_2fa_verify_provider.dart';
import '../../../../../widget/pincode_text_field.dart';

void showEmailVerifyDialog(
    BuildContext context,
    Function(bool) onEmailVerified,
    ) {
  final TextEditingController emailController = TextEditingController();
  final GlobalKey<FormState> emailFormKey =
  GlobalKey<FormState>(); // Unique key for this form

  showDialog(
    context: context,
    builder: (BuildContext dialogContext) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.r),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.all(20.w),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20.r),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Enable 2FA',
                    style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: () {
                      Navigator.of(dialogContext).pop(); // Close dialog
                    },
                  ),
                ],
              ),
              SizedBox(height: 20.h),
              Text(
                'Enter your current Email',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade700,
                ),
              ),
              SizedBox(height: 8.h),
              Form(
                key: emailFormKey, // Use the unique GlobalKey here
                child: TextField(
                  // controller: emailController,
                  decoration: InputDecoration(
                    hintText: 'Your Email',
                    hintStyle: TextStyle(color: Colors.grey.shade400),
                    filled: true,
                    fillColor: Colors.grey.shade100,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.r),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 16.w,
                      vertical: 14.h,
                    ),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
              ),
              SizedBox(height: 24.h),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.r),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6359FF), Color(0xFF5A4BFF)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Consumer<Enable2faRequestProvider>(
                  builder: (_, enable2faRequestProvider, __) {
                    return Visibility(
                      visible: !enable2faRequestProvider.isLoading,
                      replacement: const Center(child: CircularProgressIndicator()),
                      child: MaterialButton(
                        onPressed: () {
                          Navigator.of(dialogContext).pop(); // Close the current dialog
                          Future.delayed(Duration(milliseconds: 300), () async {
                            final isEmailVerified = await enable2faRequestProvider.enable2faRequest();
                            if (isEmailVerified) {
                              showVerifyCodeDialog(context, onEmailVerified,);
                            }
                          });
                        },
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.r),
                        ),
                        child: Text(
                          'Next',
                          style: TextStyle(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    );
                  }
                ),
              ),
            ],
          ),
        ),
      );
    },
  ).then((_) {
    emailController.dispose();
  });
}
void showVerifyCodeDialog(BuildContext context, Function(bool) onEmailVerified) {
  final TextEditingController otpController = TextEditingController();
  final otpVerifyProvider = Provider.of<Enable2FAVerifyProvider>(context, listen: false);
  int resendCountdown = 59;
  Timer? timer; // Use nullable Timer to ensure proper cleanup

  Dialog dialogBuilder(BuildContext dialogContext, StateSetter setDialogState) {
    // Start the countdown when the dialog is shown
    resendCountdown = 59;
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!dialogContext.mounted) {
        t.cancel(); // Cancel timer if dialog is not mounted
        return;
      }
      if (resendCountdown == 0) {
        t.cancel();
      } else {
        setDialogState(() {
          resendCountdown--;
        });
      }
    });

    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.r),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Container(
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Verify Code',
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.grey),
                  onPressed: () {
                    timer?.cancel(); // Cancel timer when closing dialog
                    Navigator.of(dialogContext).pop();
                  },
                ),
              ],
            ),
            SizedBox(height: 20.h),
            PincodeTextField(
              onChanged: otpVerifyProvider.setOtp,
              otpController: otpController,
            ),
            SizedBox(height: 24.h),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Resend: $resendCountdown' + 's',
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
            SizedBox(height: 24.h),
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                gradient: const LinearGradient(
                  colors: [Color(0xFF6359FF), Color(0xFF5A4BFF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Consumer<Enable2FAVerifyProvider>(
                builder: (_, enable2faVerifyProvider, __) {
                  return Visibility(
                    visible: !enable2faVerifyProvider.isLoading,
                    replacement: const Center(child: CircularProgressIndicator()),
                    child: MaterialButton(
                      onPressed: () async {
                        if (!dialogContext.mounted) return; // Avoid actions if dialog is not mounted
                        final isOtpVerified = await enable2faVerifyProvider.enable2faOtpVerify(otpController.text);
                        if (!isOtpVerified) {
                          ScaffoldMessenger.of(dialogContext).showSnackBar(
                            const SnackBar(
                              content: Text('Invalid OTP, please try again'),
                              backgroundColor: Colors.red,
                            ),
                          );
                          return;
                        }
                        timer?.cancel(); // Cancel timer on successful verification
                        if (dialogContext.mounted) {
                          Navigator.of(dialogContext).pop();
                          onEmailVerified(true);
                        }
                      },
                      padding: EdgeInsets.symmetric(vertical: 14.h),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: Text(
                        'Verify',
                        style: TextStyle(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => StatefulBuilder(builder: dialogBuilder),
  ).then((_) {
    timer?.cancel(); // Cancel timer when dialog is dismissed
    otpController.dispose(); // Dispose controller
  });
}
