import 'package:clotique/views/home/widgets/header_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../widgets/settings_list_widget.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            HeaderWidget(titleText: "Settings", descriptionText: null),
            SettingsListWidget(),
            SizedBox(height: 70,)
          ],
        ),
      ),
    );
  }
}
