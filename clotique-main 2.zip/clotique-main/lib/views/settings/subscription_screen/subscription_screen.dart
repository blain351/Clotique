import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:clotique/widget/primary_button.dart';
import 'package:clotique/cors/routes/routes_name.dart';
import '../../../../view_model/payment/stripe_payment_provider.dart';

class SubscriptionScreen extends StatelessWidget {
  const SubscriptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final subscriptionProvider = Provider.of<StripePaymentProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Subscription & Payment'),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current Plan Section
            const Text(
              'Current Plan',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Free Plan',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('\$0 /forever', style: TextStyle(fontSize: 14)),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.check_circle, color: Colors.green, size: 18),
                      SizedBox(width: 5),
                      Text('6 Uploads per month'),
                    ],
                  ),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Icon(Icons.close, color: Colors.red, size: 18),
                      SizedBox(width: 5),
                      Text('No AI Suggestions'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Upgrade Plan Section
            const Text(
              'Upgrade Plan',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Column(
              children: [
                // Premium Monthly Plan
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: subscriptionProvider.selectedPlan == 1
                          ? Colors.blue
                          : Colors.grey,
                    ),
                  ),
                  child: Row(
                    children: [
                      Radio<int>(
                        value: 1,
                        groupValue: subscriptionProvider.selectedPlan,
                        onChanged: (value) {
                          subscriptionProvider.setSelectedPlan(value!);
                        },
                      ),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Premium Monthly',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text('\$4.99/month'),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 18,
                              ),
                              SizedBox(width: 5),
                              Text('Unlimited Uploads'),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 18,
                              ),
                              SizedBox(width: 5),
                              Text('All Smart Suggestions'),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 15),
                // Premium Yearly Plan
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: subscriptionProvider.selectedPlan == 2
                          ? Colors.blue
                          : Colors.grey,
                    ),
                  ),
                  child: Row(
                    children: [
                      Radio<int>(
                        value: 2,
                        groupValue: subscriptionProvider.selectedPlan,
                        onChanged: (value) {
                          subscriptionProvider.setSelectedPlan(value!);
                        },
                      ),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Premium Yearly',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text('\$49.99/year'),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 18,
                              ),
                              SizedBox(width: 5),
                              Text('Unlimited Uploads'),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 18,
                              ),
                              SizedBox(width: 5),
                              Text('All Smart Suggestions'),
                            ],
                          ),
                          SizedBox(height: 5),
                          Text(
                            '2 Months Free',
                            style: TextStyle(color: Colors.blue),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Subscribe Button
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.9,
              child: PrimaryButton(
                text: "Subscribe Now",
                onPressed: () {
                  final planName = subscriptionProvider.selectedPlan == 1
                      ? "Monthly"
                      : "Yearly";
                  final planPrice = subscriptionProvider.selectedPlan == 1
                      ? "\$4.99"
                      : "\$49.99";
                  showDialog(
                    context: context,
                    builder: (BuildContext dialogContext) {
                      return AlertDialog(
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Confirm Subscription",
                              style: TextStyle(fontSize: 18),
                            ),
                            IconButton(
                              icon: const Icon(Icons.cancel),
                              onPressed: () {
                                Navigator.of(dialogContext).pop();
                              },
                            ),
                          ],
                        ),
                        content: Text(
                          "You are subscribing to the $planName plan for $planPrice.",
                        ),
                        actions: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              OutlinedButton(
                                onPressed: () {
                                  Navigator.of(dialogContext).pop();
                                  Navigator.pushNamed(
                                    context,
                                    RouteName.paymentScreen,
                                  );
                                },
                                child: const Text("Stripe"),
                              ),
                              OutlinedButton(
                                onPressed: () {
                                  Navigator.of(dialogContext).pop();
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        "Google Pay is not implemented yet.",
                                      ),
                                    ),
                                  );
                                },
                                child: const Text("Google Pay"),
                              ),
                              // OutlinedButton(
                              //   onPressed: () {
                              //     Navigator.of(dialogContext).pop();
                              //     ScaffoldMessenger.of(context).showSnackBar(
                              //       const SnackBar(
                              //         content: Text(
                              //           "PayPal is not implemented yet.",
                              //         ),
                              //       ),
                              //     );
                              //   },
                              //   child: const Text("PayPal"),
                              // ),
                            ],
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 10),

            // Payment Methods Section
            const Text(
              'Secure payments by trusted providers:',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Icon(Icons.payment, size: 30),
                Icon(Icons.credit_card, size: 30),
                Icon(Icons.paypal, size: 30),
              ],
            ),
          ],
        ),
      ),
    );
  }
}