import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:provider/provider.dart';
import '../../../../widget/primary_button.dart';
import '../../../cors/services/stripe_service.dart';
import '../../../cors/services/user_email_storage.dart';
import '../../../view_model/payment/stripe_payment_provider.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});

  @override
  _PaymentScreenState createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  bool _isCardComplete = false;
  final _cardFormController = CardFormEditController();

  @override
  void initState() {
    super.initState();
    // Listen to card form changes to update the completion state
    _cardFormController.addListener(() {
      setState(() {
        _isCardComplete = _cardFormController.details.complete;
      });
    });
  }

  @override
  void dispose() {
    _cardFormController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final stripeProvider = Provider.of<StripePaymentProvider>(context);
    final String planName =
        stripeProvider.selectedPlan == 1 ? "Monthly" : "Yearly";
    final double planAmount = stripeProvider.selectedPlan == 1 ? 4.99 : 49.99;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Payment'),
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Enter Payment Details',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            CardFormField(
              controller: _cardFormController,
              style: CardFormStyle(
                borderRadius: 15,
                backgroundColor: Colors.white,
                textColor: Colors.black,
                borderColor: Colors.blue,
                cursorColor: Colors.blue,
                textErrorColor: Colors.red,
                placeholderColor: Colors.grey,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Subscribing to: $planName Plan (\$${planAmount.toStringAsFixed(2)})',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            ValueListenableBuilder<bool>(
              valueListenable: StripeServices.instance.isLoading,
              builder: (context, isLoading, _) {
                return isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : SizedBox(
                      width: MediaQuery.of(context).size.width * 0.9,
                      child:
                          planName == "Monthly"
                              ? PrimaryButton(
                                text: 'Pay Now',
                                onPressed:
                                    _isCardComplete
                                        ? () async {
                                          try {
                                            final email =
                                                await UserEmailStorage.getUserEmail();
                                            // Use StripeServices to create payment method
                                            final paymentMethodId =
                                                await StripeServices.instance
                                                    .createPaymentMethod(
                                                      email:
                                                          'user@example.com', // Replace with actual user email
                                                    );

                                            if (paymentMethodId != null) {
                                              debugPrint(
                                                "The payment method id: $paymentMethodId",
                                              );
                                              await stripeProvider
                                                  .stripePaymentMonthly(
                                                    paymentMethodId,
                                                  );

                                              ScaffoldMessenger.of(
                                                context,
                                              ).showSnackBar(
                                                const SnackBar(
                                                  content: Text(
                                                    'Payment successful!',
                                                  ),
                                                  backgroundColor: Colors.green,
                                                ),
                                              );

                                              Navigator.pop(context);
                                            }
                                          } catch (e) {
                                            ScaffoldMessenger.of(
                                              context,
                                            ).showSnackBar(
                                              SnackBar(
                                                content:Text(
                                                'Payment Success',
                                              ),
                                              backgroundColor: Colors.green,
                                              ),
                                            );
                                          }
                                        }
                                        : null,
                              )
                              : PrimaryButton(
                                text: 'Pay Now',
                                onPressed:
                                    _isCardComplete
                                        ? () async {
                                          try {
                                            final email =
                                                await UserEmailStorage.getUserEmail();
                                            // Use StripeServices to create payment method
                                            final paymentMethodId =
                                                await StripeServices.instance
                                                    .createPaymentMethod(
                                                      email:
                                                          'user@example.com', // Replace with actual user email
                                                    );

                                            if (paymentMethodId != null) {
                                              debugPrint(
                                                "The payment method id: $paymentMethodId",
                                              );
                                              await stripeProvider
                                                  .stripePaymentYearly(
                                                    paymentMethodId,
                                                  );

                                              ScaffoldMessenger.of(
                                                context,
                                              ).showSnackBar(
                                                const SnackBar(
                                                  content: Text(
                                                    'Payment successful!',
                                                  ),
                                                  backgroundColor: Colors.green,
                                                ),
                                              );

                                              Navigator.pop(context);
                                            }
                                          } catch (e) {
                                            ScaffoldMessenger.of(
                                              context,
                                            ).showSnackBar(
                                              SnackBar(
                                                content: Text(
                                                  'Payment Success',
                                                ),
                                                backgroundColor: Colors.green,
                                              ),
                                            );
                                          }
                                        }
                                        : null,
                              ),
                    );
              },
            ),
          ],
        ),
      ),
    );
  }
}
