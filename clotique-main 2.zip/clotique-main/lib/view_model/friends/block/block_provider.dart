import 'package:flutter/material.dart';
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';
import '../../../data/model/friends/block/block_response.dart';

class BlockProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  BlockErrorResponse? _response;
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  BlockErrorResponse? get response => _response;
  String get errorMessage => _errorMessage;

  static String block(String userId) => '${ApiEndPoint.baseUrl}/blocks/$userId';

  Future<void> fetchBlock(String userId) async {
    debugPrint('Starting block for user: $userId');

    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final url = fetchBlock(userId);
      debugPrint('API URL: $url');

      final response = await _apiService.post(url as String, data: {});

      debugPrint('Response received: statusCode = ${response.statusCode}, data = ${response.data}');

      _isLoading = false;

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data is Map<String, dynamic>) {
          _response = BlockErrorResponse.fromJson(response.data);
          debugPrint('Parsed response: ${_response!.toJson()}');
        } else {
          _errorMessage = 'Unexpected data format: ${response.data.runtimeType}';
          debugPrint('Error: $_errorMessage');
        }
      } else {
        _errorMessage = 'Failed to block user: ${response.statusCode}';
        debugPrint('Error: $_errorMessage');
      }

      notifyListeners();
    } catch (e) {
      debugPrint('Exception caught: $e');
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
    }
  }
}