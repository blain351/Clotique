import 'package:flutter/material.dart';
import '../../../cors/services/api_services.dart';
import '../../../cors/constant/api_end_point.dart';

class AcceptFriendRequestProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  get response => null;

  // Accept Friend Request
  Future<AcceptFriendRequestResponse> fetchAcceptFriendRequest(String postId) async {
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final data = {
        "status" :'ACCEPTED',
      };
      // Get the URL for the API endpoint
      final url = ApiEndPoint.accept(postId);



      // Send the POST request with the URL and data
      final response = await _apiService.post(url, data: data);

      debugPrint('response hit +++++ ${response.data}');

      if (response.statusCode == 200) {
        return AcceptFriendRequestResponse.fromJson(response.data);
      } else {
        _errorMessage = 'Failed to accept the request';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    return AcceptFriendRequestResponse(success: false, message: _errorMessage);
  }
}

class AcceptFriendRequestResponse {
  final bool success;
  final String message;

  AcceptFriendRequestResponse({required this.success, required this.message});

  factory AcceptFriendRequestResponse.fromJson(Map<String, dynamic> json) {
    return AcceptFriendRequestResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? 'Error',
    );
  }
}
