import 'package:flutter/material.dart';
import '../../../cors/services/api_services.dart';
import '../../../data/model/friends/block_list/block_list_response.dart';
import '../../../cors/constant/api_end_point.dart';

class BlockListProvider extends ChangeNotifier {
  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  String _errorMessage = '';
  List<BlockListResponse> _blockedUsers = [];

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  List<BlockListResponse> get blockedUsers => _blockedUsers;

  // Add blocked user to the list
  void addBlockedUser(BlockListResponse blockedUser) {
    _blockedUsers.add(blockedUser);
    notifyListeners();
  }

  // Fetch the list of blocked users
  Future<void> fetchBlockList() async {
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final response = await _apiService.get(ApiEndPoint.blocklist);
      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data is List<dynamic>) {
          _blockedUsers = response.data
              .map((item) => BlockListResponse.fromJson(item))
              .toList();
        } else {
          _errorMessage = 'Unexpected response data format';
        }
      } else {
        _errorMessage = 'Failed to fetch blocked users';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Unblock user from the list
  Future<void> unblockUser(String userId) async {
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final response = await _apiService.post('${ApiEndPoint.baseUrl}/unblock/$userId', data: {});
      if (response.statusCode == 200 || response.statusCode == 201) {
        // Remove the user from the blocked list after unblocking
        _blockedUsers.removeWhere((user) => user.blocked?.id == userId);
        notifyListeners();
      } else {
        _errorMessage = 'Failed to unblock user';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
