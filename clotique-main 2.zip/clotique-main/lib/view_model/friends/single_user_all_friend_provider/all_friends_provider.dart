import 'package:flutter/material.dart';
import 'dart:convert';
import '../../../cors/constant/api_end_point.dart';  // Make sure ApiEndPoint is correctly imported
import '../../../cors/services/api_services.dart'; // Ensure ApiService is available
import '../../../data/model/friends/single_user_all_friend_response/all_friends_response.dart'; // Ensure the model is imported

class SingleUserAllFriendProvider extends ChangeNotifier {
  SingleUserAllFriendProvider() {
    fetchSingleUserAllFriend();
  }

  bool _isLoading = false;
  List<SingleUserAllFriendResponse> _friendsList = [];
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  List<SingleUserAllFriendResponse> get friendsList => _friendsList;
  String get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  get id => null;

  // Fetch all friends for a single user
  Future<void> fetchSingleUserAllFriend() async {
    debugPrint('Fetching all friends...');
    try {
      _isLoading = true;
      _errorMessage = '';
      notifyListeners();

      final response = await _apiService.get(ApiEndPoint.all);
      debugPrint('Response data type: ${response.data.runtimeType}');

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data is List<dynamic>) {
          final List<dynamic> data = response.data;
          _friendsList = data
              .map((jsonItem) => SingleUserAllFriendResponse.fromJson(jsonItem as Map<String, dynamic>))
              .toList();
        } else if (response.data is String) {
          final List<dynamic> data = json.decode(response.data);
          _friendsList = data
              .map((jsonItem) => SingleUserAllFriendResponse.fromJson(jsonItem as Map<String, dynamic>))
              .toList();
        } else {
          _errorMessage = 'Unexpected response data format';
        }

        debugPrint('Friends list loaded: ${_friendsList.length} items');
      } else {
        _errorMessage = 'Failed to load friends: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      debugPrint('Error fetching friends: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
