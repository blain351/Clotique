import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';

class DeletePostProvider extends ChangeNotifier {
  bool _isLoading = false;
  String? _errorMessage;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  Future<bool> deletePost(String postId) async {
    if (postId.isEmpty) {
      _errorMessage = 'Invalid post ID';
      _isLoading = false;
      notifyListeners();
      return false;
    }

    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response = await _apiService.delete(ApiEndPoint.deleteUserPostByPostId(postId));

      print('Delete Post Response: Status=${response.statusCode}, Data=${response.data}');

      if (response.statusCode == 200 || response.statusCode == 204) {
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Failed to delete post. Status: ${response.statusCode}, Message: ${response.data}';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Error deleting post: $e';
      if (e is DioException) {
        _errorMessage = 'Dio error: ${e.response?.statusCode} - ${e.response?.data}';
      }
      _isLoading = false;
      notifyListeners();
      print('Delete Post Error: $_errorMessage');
      return false;
    }
  }
}