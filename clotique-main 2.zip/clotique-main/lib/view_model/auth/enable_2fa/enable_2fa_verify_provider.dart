import 'package:flutter/material.dart';

import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';

class Enable2FAVerifyProvider extends ChangeNotifier {

  String _otp = '';
  static const int otpLength = 6;

  String get otp => _otp;

  void setOtp(String value) {
    _otp = value;
    notifyListeners();
  }

  bool get isOtpValid => _otp.length == otpLength;

  bool _isLoading = false;
  String? _errorMessage;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  final ApiService _apiService = ApiService();

  Future<bool> enable2faOtpVerify(String otp) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      final response = await _apiService.post(
        ApiEndPoint.enable2faOtpVerify,
        data: {
          'code': otp,
        },
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Failed to provide otp: ${response.statusCode}';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
    return false;
  }
}