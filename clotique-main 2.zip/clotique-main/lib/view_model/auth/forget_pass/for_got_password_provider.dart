import 'package:flutter/material.dart';
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/routes/routes_name.dart';
import '../../../cors/services/api_services.dart';

class ForgotPasswordProvider extends ChangeNotifier {
  String _email = '';

  String get email => _email;

  void setEmail(String value) {
    _email = value;
    notifyListeners();
  }

  bool get isValidEmail =>
      RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$").hasMatch(_email);

  bool get isFormValid => isValidEmail;

  String? get emailError {
    if (_email.isEmpty) return null;
    return isValidEmail ? null : 'Enter a valid email address';
  }

  Future<void> submit(BuildContext context) async {
    if (isFormValid) {
      final result = await forgotPassword(_email);
      if (result) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          Navigator.pushNamed(context, RouteName.confirmOtpScreen);
        });
      }
    }
  }

  bool _isLoading = false;
  String _errorMessage = '';

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;

  // API service
  final ApiService _apiService = ApiService();

  // Function to handle sign-up
  Future<bool> forgotPassword(String email) async {
    try {
      _isLoading = true;
      notifyListeners();

      // Prepare data
      final data = {
        'email': email,
      };

      final response = await _apiService.post(
        ApiEndPoint.forgotPassword,
        data: data,
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        _isLoading = false;
        notifyListeners();
        final success = response.data['success'];
        return success;

      } else {
        _errorMessage = 'Failed to proceed.';
        _isLoading = false;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
    }
    return false;
  }
}
