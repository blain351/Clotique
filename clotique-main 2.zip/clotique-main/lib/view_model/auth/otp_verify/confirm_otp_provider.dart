import 'package:flutter/material.dart';

class ConfirmOtpProvider extends ChangeNotifier {
  String _otp = '';
  static const int otpLength = 6;

  String get otp => _otp;

  void setOtp(String value) {
    _otp = value;
    notifyListeners();
  }

  String _token = '';
  String get token => _token;

  void setToken(String value) {
    _token = value;
    notifyListeners();
  }

  bool get isOtpComplete => _otp.length == otpLength;
}