import 'package:flutter/material.dart';
import '../../../cors/constant/api_end_point.dart';
import '../../../cors/services/api_services.dart';
import '../../../cors/services/user_id_storage.dart';
import '../../../data/model/auth/user/user_model.dart';

class UserDetailsProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';
  UserModel? _userModel;
  final UserIdStorage userIdStorage = UserIdStorage();

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  UserModel? get userModel => _userModel;

  final ApiService _apiService = ApiService();

  Future<bool> getUserDetails() async {
    try {
      _isLoading = true;
      notifyListeners();

      final response = await _apiService.get(ApiEndPoint.checkMe);

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data['data'] != null) {
          _userModel = UserModel.fromJson(response.data['data']);

          String userId = _userModel!.id;

          await userIdStorage.saveUserId(userId);

          debugPrint('User ID saved: $userId'); // Debugging log for userId

          _isLoading = false;
          notifyListeners();
          return true;
        } else {
          _errorMessage = 'User data is missing in the response';
          _isLoading = false;
          notifyListeners();
          return false;
        }
      } else {
        _errorMessage = 'Failed to fetch user details, status code: ${response.statusCode}';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }
}
