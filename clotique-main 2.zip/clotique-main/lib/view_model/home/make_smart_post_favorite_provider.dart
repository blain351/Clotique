import 'dart:convert';

import 'package:clotique/cors/services/token_storage.dart';
import 'package:clotique/data/model/home/daily_outfit_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../cors/constant/api_end_point.dart';

class MakeSmartPostFavoriteProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';
  bool _isFavorite = false;
  String _postId = '';

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  bool get isFavorite => _isFavorite;
  String get postId => _postId;

  final TokenStorage _tokenStorage = TokenStorage();

  Future<bool> makeSmartPostFavorite(String postId) async {
    _isLoading = true;
    _errorMessage = '';
    _isFavorite = false;
    _postId = postId;
    notifyListeners();

    final token = await _tokenStorage.getToken();

    try {
      final response = await http.patch(
        Uri.parse(ApiEndPoint.makeSmartPostFavorite(_postId)),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );
      debugPrint('Response received: statusCode = ${response.statusCode}, data = ${response.body}');
      if (response.statusCode == 200 || response.statusCode == 201) {
        _isLoading = false;
        _isFavorite = true;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Failed to make event post favorite, status code: ${response.statusCode}';
        _isLoading = false;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
      _isLoading = false;
      notifyListeners();
    }
    debugPrint('Error: $_errorMessage');
    debugPrint('IsFavorite: $_isFavorite');
    debugPrint('PostId: $_postId');
    return false;
  }
}