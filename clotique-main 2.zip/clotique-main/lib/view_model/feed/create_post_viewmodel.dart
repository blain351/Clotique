import 'dart:io';
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';
import '../../cors/services/token_storage.dart';
import '../../data/model/user_feed/create_post_response.dart';

class CreatePostViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String _errorMessage = '';
  String? _selectedImagePath;
  String _audience = 'Friends';
  CreatePostResponse? _createPostResponse;

  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  String get audience => _audience;
  String? get selectedImagePath => _selectedImagePath;
  CreatePostResponse? get createPostResponse => _createPostResponse;

  final ApiService _apiService = ApiService();

  Future<void> createPost(BuildContext context, String caption, String? imagePath) async {
    _isLoading = true;
    _errorMessage = '';
    _createPostResponse = null;
    notifyListeners();

    try {
      if (imagePath == null) {
        throw Exception('No image selected!');
      }

      final token = await TokenStorage().getToken();
      final uri = Uri.parse(ApiEndPoint.createPost);
      final request = http.MultipartRequest('POST', uri);

      // Add form fields
      request.fields['caption'] = caption;
      request.fields['privacy'] = _audience;

      // Add image file
      File imageFile = File(imagePath);
      final mimeType = lookupMimeType(imageFile.path) ?? 'image/jpeg';
      request.files.add(
        await http.MultipartFile.fromPath(
          'image',
          imageFile.path,
          contentType: MediaType.parse(mimeType),
        ),
      );

      if (token != null) {
        request.headers['Authorization'] = 'Bearer $token';
      }

      // Send request
      final streamedResp = await request.send();
      final resp = await http.Response.fromStream(streamedResp);
      debugPrint('Raw response body: ${resp.body}');

      // Check if response body is empty
      if (resp.body.isEmpty) {
        throw Exception('Empty response from server');
      }

      // Decode JSON safely
      dynamic jsonBody;
      try {
        jsonBody = json.decode(resp.body);
      } catch (e) {
        throw Exception('Failed to parse response: $e');
      }

      debugPrint('Response status: ${resp.statusCode}');
      debugPrint('Parsed response type: ${jsonBody.runtimeType}');

      if (resp.statusCode == 200 || resp.statusCode == 201) {
        // Handle successful response
        if (jsonBody is Map<String, dynamic>) {
          try {
            _createPostResponse = CreatePostResponse.fromJson(jsonBody);
            Fluttertoast.showToast(msg: _createPostResponse?.message ?? 'Post created successfully', gravity: ToastGravity.BOTTOM);
            Navigator.pop(context, true);
          } catch (e) {
            throw Exception('Failed to parse CreatePostResponse: $e');
          }
        } else if (jsonBody is String) {
          _createPostResponse = CreatePostResponse(message: jsonBody);
          Fluttertoast.showToast(msg: jsonBody, gravity: ToastGravity.BOTTOM);
          Navigator.pop(context, true);
        } else {
          throw Exception('Invalid response format: Expected JSON object or string');
        }
      } else {
        // Handle error response
        String errorMsg;
        if (jsonBody is Map<String, dynamic> && jsonBody.containsKey('message')) {
          errorMsg = jsonBody['message'].toString();
        } else if (jsonBody is String) {
          errorMsg = jsonBody;
        } else {
          errorMsg = 'Failed to create post';
        }
        _errorMessage = errorMsg;
        Fluttertoast.showToast(msg: errorMsg, gravity: ToastGravity.BOTTOM);
      }
    } catch (e) {
      _errorMessage = 'Error: ${e.toString()}';
      debugPrint('Error in createPost: $_errorMessage');
      Fluttertoast.showToast(msg: _errorMessage, gravity: ToastGravity.BOTTOM);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void setSelectedImage(String imagePath) {
    _selectedImagePath = imagePath;
    notifyListeners();
  }
}