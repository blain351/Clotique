import 'package:clotique/data/model/user_feed/comment_model.dart';
import 'package:flutter/material.dart';

import '../../cors/constant/api_end_point.dart';
import '../../cors/services/api_services.dart';

class GetAllCommentsProvider extends ChangeNotifier {
  bool _isLoading = false;
  String? _errorMessage;
  List<CommentModel> _comments = [];
  int _commentCount = 0;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  List<CommentModel> get comments => _comments;
  int get commentCount => _commentCount;

  final ApiService _apiService = ApiService();

  Future<void> getAllComments(String postId) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final response = await _apiService.get(
        ApiEndPoint.getAllCommentsById(postId),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.data['success']) {
          _comments = List<CommentModel>.from(
              response.data['data']['comments'].map((item) => CommentModel.fromJson(item))
          );
          _commentCount = _comments.length;
          notifyListeners();
        }
      } else {
        _errorMessage = 'Failed to load comments, please try again later.';
      }
    } catch (e) {
      _errorMessage = 'An error occurred: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
