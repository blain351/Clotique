import 'dart:convert';
import 'dart:io';
import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

import '../../cors/services/token_storage.dart';
import '../../data/model/wardrobe/all_wardrobe_model.dart';

class WardrobeScreenProvider extends ChangeNotifier {
  WardrobeScreenProvider() {
    getAllWardrobe();

  }

  final TokenStorage _tokenStorage = TokenStorage();
  bool _isLoading = false;
  String? _errorMessage;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<bool> createWardrobe(File imageFile, String description) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    final url = Uri.parse(ApiEndPoint.insertCloth);
    try {
      final token = await _tokenStorage.getToken();
      var request = http.MultipartRequest('POST', url);

      // Add headers
      request.headers['Authorization'] = 'Bearer $token';
      request.headers['Content-Type'] = 'multipart/form-data';

      // Add description field
      request.fields['description'] = description;

      // Add image file
      request.files.add(
        await http.MultipartFile.fromPath(
          'image', // Field name expected by the API
          imageFile.path,
          filename: imageFile.path.split('/').last,
        ),
      );

      // Send the request
      final response = await request.send();
      final responseBody = await http.Response.fromStream(response);

      if (response.statusCode == 200 || response.statusCode == 201) {
        _isLoading = false;
        notifyListeners();
        return true; // Indicate success
      } else {
        _errorMessage = 'Failed to save outfit: ${responseBody.body}';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (error) {
      _errorMessage = 'Error creating wardrobe: $error';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  late AllWardrobeModel _allWardrobeModel;

  AllWardrobeModel get getAllWardrobeModel => _allWardrobeModel;

  Future<void> getAllWardrobe() async {
    final url = Uri.parse(ApiEndPoint.getAllWardrobe);

    try {
      final token = await _tokenStorage.getToken();
      final response = await http.get(
        url,
        headers: {
          'Authorization': 'bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        _allWardrobeModel = AllWardrobeModel.fromJson(data);
        debugPrint(response.body);
        debugPrint("The ware drop description is ${_allWardrobeModel.data!.items![0].description}");
        debugPrint("Data fetch successfully");

        notifyListeners();
      } else {
        _errorMessage = 'Failed to load wardrobe items: ${response.body}';
      }
    } catch (error) {
      _errorMessage = 'Error fetching wardrobe: $error';
      debugPrint(error.toString());
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
