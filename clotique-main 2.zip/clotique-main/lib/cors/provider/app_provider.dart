import 'package:clotique/data/model/wardrobe/all_favourite_outfit_provider.dart';
import 'package:clotique/data/model/wardrobe/delete_one_favourite_outfit_provider.dart';
import 'package:clotique/view_model/ai_generate/ai_generate_viewmodel.dart';
import 'package:clotique/view_model/auth/check_me/user_details_provider.dart';
import 'package:clotique/view_model/auth/enable_2fa/enable_2fa_request_provider.dart';
import 'package:clotique/view_model/auth/enable_2fa/enable_2fa_verify_provider.dart';
import 'package:clotique/view_model/auth/sign_up/sign_up_provider.dart';
import 'package:clotique/view_model/auth/otp_verify/confirm_otp_provider.dart';
import 'package:clotique/view_model/feed/create_comment_provider.dart';
import 'package:clotique/view_model/feed/get_all_comments_provider.dart';
import 'package:clotique/view_model/feed/share_post_provider.dart';
import 'package:clotique/view_model/friends/block_list/block_list_provider.dart';
import 'package:clotique/view_model/friends/reject_request/reject_request_provider.dart';
import 'package:clotique/view_model/friends/block_list/block_list_provider.dart';
import 'package:clotique/view_model/friends/suggestions/single_user_suggestion_friend_provider.dart';
import 'package:clotique/view_model/feed/like_post_provider.dart';
import 'package:clotique/view_model/friends/unblock/unblock_provider.dart';
import 'package:clotique/view_model/home/daily_event_outfit_provider.dart';
import 'package:clotique/view_model/home/daily_smart_outfit_provider.dart';
import 'package:clotique/view_model/home/daily_weather_provider.dart';
import 'package:clotique/view_model/home/make_event_post_favorite_provider.dart';
import 'package:clotique/view_model/home/make_smart_post_favorite_provider.dart';
import 'package:clotique/view_model/notification/notification_provider.dart';
import 'package:clotique/view_model/profile/delete_post_provider.dart';
import 'package:clotique/view_model/profile/edit_post_provider.dart';
import 'package:clotique/view_model/profile/edit_profile_provider.dart';
import 'package:clotique/view_model/profile/get_user_post_provider.dart';
import 'package:clotique/view_model/profile/one_user_details_provider.dart';
import 'package:clotique/view_model/search/search_viewmodel.dart';
import 'package:provider/provider.dart';

import '../../view_model/auth/login_logout_provider/login_logout_provider.dart';
import '../../view_model/feed/feed_view_model.dart';

import '../../view_model/auth/forget_pass/for_got_password_provider.dart';
import '../../view_model/friends/accept_friend_request_provider/accept_request_provider.dart';
import '../../view_model/friends/all_pending_request_provider/pending_request_provider.dart';
import '../../view_model/friends/single_user_all_friend_provider/all_friends_provider.dart';
import '../../view_model/parent_screen_provider.dart';
import '../../view_model/auth/reset_pass/set_password_provider.dart';
import '../../view_model/payment/stripe_payment_provider.dart';
import '../../view_model/wardrobe/waredrob_screen_provider.dart';

class AppProviders {
  static List<ChangeNotifierProvider> getProviders() {
    return [
      ChangeNotifierProvider<ParentScreensProvider>(
        create: (context) => ParentScreensProvider(),
      ),
      ChangeNotifierProvider<ForgotPasswordProvider>(
        create: (context) => ForgotPasswordProvider(),
      ),
      ChangeNotifierProvider<SetPasswordProvider>(
        create: (context) => SetPasswordProvider(),
      ),
      ChangeNotifierProvider<SignUpProvider>(
        create: (context) => SignUpProvider(),
      ),
      ChangeNotifierProvider<LoginLogoutProvider>(
        create: (context) => LoginLogoutProvider(),
      ),
      ChangeNotifierProvider<UserDetailsProvider>(
        create: (context) => UserDetailsProvider(),
      ),
      ChangeNotifierProvider<FeedViewModel>(
        create: (context) => FeedViewModel(),
      ),
      ChangeNotifierProvider<ConfirmOtpProvider>(
        create: (context) => ConfirmOtpProvider(),
      ),
      ChangeNotifierProvider<DailyWeatherProvider>(
        create: (context) => DailyWeatherProvider(),
      ),
      ChangeNotifierProvider<WardrobeScreenProvider>(
        create: (context) => WardrobeScreenProvider(),
      ),
      ChangeNotifierProvider<DailyEventOutfitProvider>(
        create: (context) => DailyEventOutfitProvider(),
      ),
      ChangeNotifierProvider<DailySmartOutfitProvider>(
        create: (context) => DailySmartOutfitProvider(),
      ),
      ChangeNotifierProvider<NotificationProvider>(
        create: (context) => NotificationProvider(),
      ),
      ChangeNotifierProvider<SingleUserSuggestionFriendProvider>(
        create: (context) => SingleUserSuggestionFriendProvider(),
      ),
      ChangeNotifierProvider<LikePostProvider>(
        create: (context) => LikePostProvider(),
      ),
      ChangeNotifierProvider<SearchViewModel>(
        create: (context) => SearchViewModel(),
      ),
      ChangeNotifierProvider<CreateCommentProvider>(
        create: (context) => CreateCommentProvider(),
      ),
      ChangeNotifierProvider<GetAllCommentsProvider>(
        create: (context) => GetAllCommentsProvider(),
      ),
      ChangeNotifierProvider<EditProfileProvider>(
        create: (context) => EditProfileProvider(),
      ),
      ChangeNotifierProvider<AllPendingRequestProvider>(
        create: (context) => AllPendingRequestProvider(),
      ),
      ChangeNotifierProvider<AcceptFriendRequestProvider>(
        create: (context) => AcceptFriendRequestProvider(),
      ),
      ChangeNotifierProvider<SingleUserAllFriendProvider>(
        create: (context) => SingleUserAllFriendProvider(),
      ),
      ChangeNotifierProvider<BlockListProvider>(
        create: (context) => BlockListProvider(),
      ),
      ChangeNotifierProvider<UnblockProvider>(
        create: (context) => UnblockProvider(),
      ),
      ChangeNotifierProvider<GetUserPostProvider>(
        create: (context) => GetUserPostProvider(),
      ),
      ChangeNotifierProvider<DeletePostProvider>(
        create: (context) => DeletePostProvider(),
      ),
      ChangeNotifierProvider<BlockListProvider>(
        create: (context) => BlockListProvider(),
      ),
      ChangeNotifierProvider<UnblockProvider>(
        create: (context) => UnblockProvider(),
      ),
      // ChangeNotifierProvider<OneUserDetailsProvider>(
      //   create: (context) => OneUserDetailsProvider(),
      // ),
      // ChangeNotifierProvider<RejectedRequestProvider>(
      //   create: (context) => RejectedRequestProvider(
      //     removeRequestFromPendingList: (String postId) {
      //       context.read<AllPendingRequestProvider>().removeRequest(postId);
      //     },
      //   ),
      // ),

      ChangeNotifierProvider<EditPostProvider>(
        create: (context) => EditPostProvider(),
      ),
      ChangeNotifierProvider<Enable2faRequestProvider>(
        create: (context) => Enable2faRequestProvider(),
      ),
      ChangeNotifierProvider<Enable2FAVerifyProvider>(
        create: (context) => Enable2FAVerifyProvider(),
      ),
      ChangeNotifierProvider<SharePostProvider>(
        create: (context) => SharePostProvider(),
      ),
      // ChangeNotifierProvider<WebSocketService>(
      //   create: (context) => WebSocketService(),
      // ),
      ChangeNotifierProvider<MakeEventPostFavoriteProvider>(
        create: (context) => MakeEventPostFavoriteProvider(),
      ),
      ChangeNotifierProvider<MakeSmartPostFavoriteProvider>(
        create: (context) => MakeSmartPostFavoriteProvider(),
      ),
      ChangeNotifierProvider<AllFavouriteOutfitProvider>(
        create: (context) => AllFavouriteOutfitProvider(),
      ),
      ChangeNotifierProvider<DeleteOneFavouriteOutfitProvider>(
        create: (context) => DeleteOneFavouriteOutfitProvider(),
      ),
      ChangeNotifierProvider<AiGenerateViewModel>(
        create: (context) => AiGenerateViewModel(),
      ),
      ChangeNotifierProvider<StripePaymentProvider>(
        create: (context) => StripePaymentProvider(),
      ),
    ];
  }
}
