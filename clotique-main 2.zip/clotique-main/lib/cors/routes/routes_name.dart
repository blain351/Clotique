class RouteName {
  static const homeScreen = "homeScreen";
  static const parentScreen = "parentScreen";
  static const onboardingScreen = "onboardingScreen";
  static const loginOrSignup = "loginOrSignup";
  static const signUpScreen = "signUpScreen";
  static const loginScreen = "loginScreen";
  static const forgotPassword = "forgotPassword";
  static const confirmOtpScreen = "confirmOtpScreen";
  static const verify2faOtpScreen = "verify2faOtpScreen";
  static const setPassword = "setPassword";

  static const createPostScreen = "createPostScreen";
  static const compareOutfitScreen = "compareOutfitScreen";
  static const friendsScreen = "friendsScreen";
  static const friendsProfileScreen = "friendsProfileScreen";

  static const aiGenerator = "aiGenerator";
  static const settingsScreen = "settingsScreen";
  static const accountSettingsScreen = "accountSettingsScreen";
  static const allOutfitScreen = "allOutfitScreen";

  static const notificationScreen = "notificationScreen";
  static const commentScreen = "commentScreen";
  static const searchScreen = "searchScreen";
  static const feedScreen = "feedScreen";
  static const profileScreen = "profileScreen";
  static const editProfileScreen = "editProfileScreen";
  static const editPostScreen = "editPostScreen";
  static const allFriendsTab = "allFriends";
  static const reportUserPage = "reportUserPage";
  static const reportUserDetailPage = "reportUserDetailPage";
  static const friendScreen = "friendsScreen";
  static const blockedUsersTab = "blockedUsersTab";
  static const webSocket = "webSocket";
  static const paymentScreen = "paymentScreen";
  static const subscriptionScreen = "subscriptionScreen";

  static const allFriends = "allFriendsTab";
  static const String requestsTab = '/requests';
  static const String friendsProfile = '/friendProfile';
  static String singleUserAllFriendTab = '/singleUserAllFriendTab';
  static String AllFriends = '/AllFriends';
}