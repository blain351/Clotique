import 'package:clotique/cors/constant/api_end_point.dart';
import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';  // Add this import
import 'user_id_storage.dart';

class PushNotificationService {
  late IO.Socket socket;
  final UserIdStorage _userIdStorage = UserIdStorage();
  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  PushNotificationService() {
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    _initializeNotifications();
  }

  // Initialize local notifications
  Future<void> _initializeNotifications() async {
    const AndroidInitializationSettings androidSettings =
    AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initializationSettings =
    InitializationSettings(android: androidSettings);

    await flutterLocalNotificationsPlugin.initialize(initializationSettings);

    // Check and request permission for notifications
    await _checkAndRequestPermission();
  }

  // Check and request notification permission
  Future<void> _checkAndRequestPermission() async {
    // Check if the notification permission is granted
    PermissionStatus status = await Permission.notification.status;

    // If not granted, request permission
    if (!status.isGranted) {
      await _requestNotificationPermission();
    }
  }

  // Request notification permission
  Future<void> _requestNotificationPermission() async {
    final PermissionStatus status = await Permission.notification.request();

    if (status.isGranted) {
      print("Notification permission granted.");
    } else {
      print("Notification permission denied.");
    }
  }

  // This method now accepts BuildContext as a parameter
  Future<void> initializeSocket(BuildContext context) async {
    try {
      // Fetch the user ID from SharedPreferences
      String? userId = await _userIdStorage.getUserId();
      if (userId != null) {
        print('User ID fetched: $userId'); // Debugging log for userId

        // URL with userId as a query parameter
        final socketUrl = '${ApiEndPoint.socketUrl}?userId=$userId';

        socket = IO.io(
          socketUrl,  // Use URL with userId as query parameter
          IO.OptionBuilder()
              .setTransports(['websocket']) // Use WebSocket as transport
              .disableAutoConnect() // Disable auto-connect to manage it manually
              .build(),
        );

        // Connect to the server
        socket.connect();

        // Debugging: Check if socket is connecting
        // socket.onConnect((_) {
        //   print('Connected to socket server');
        //   socket.emit('sendNotification', {
        //     'userId': userId,  // Use userId from SharedPreferences
        //     'message': 'this is a test message',
        //   });
        // });

        // Debugging: If connection fails, catch it
        socket.onError((error) {
          print('Socket connection error: $error');
        });

        // Debugging: Listen for connection errors or disconnections
        socket.onDisconnect((_) {
          print('Disconnected from socket server');
        });

        // Listen for notifications
        socket.on('receiveNotification', (data) {
          print('Received notification: $data');

          // Show the notification
          _showNotification(data.toString());
        });

        // Additional debug: Check socket status
        socket.on('connect_error', (error) {
          print('Socket connection error: $error');
        });
      } else {
        print("User ID is not available.");
      }
    } catch (e) {
      print('Error while initializing socket: $e');
    }
  }

  // Show the local notification
  Future<void> _showNotification(String message) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'default_channel',
      'Default Notifications',
      importance: Importance.high,
      priority: Priority.high,
      ticker: 'ticker',
    );
    const NotificationDetails platformDetails = NotificationDetails(android: androidDetails);

    await flutterLocalNotificationsPlugin.show(
      0,
      'New Notification',
      message,
      platformDetails,
    );
  }
}




// import 'package:clotique/cors/constant/api_end_point.dart';
// import 'package:flutter/material.dart';
// import 'package:socket_io_client/socket_io_client.dart' as IO;
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:permission_handler/permission_handler.dart';  // Add this import
// import 'user_id_storage.dart';
//
// class PushNotificationService {
//   late IO.Socket socket;
//   final UserIdStorage _userIdStorage = UserIdStorage();
//   late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;
//
//   PushNotificationService() {
//     flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
//     _initializeNotifications();
//   }
//
//   // Initialize local notifications
//   Future<void> _initializeNotifications() async {
//     const AndroidInitializationSettings androidSettings =
//     AndroidInitializationSettings('@mipmap/ic_launcher');
//     const InitializationSettings initializationSettings =
//     InitializationSettings(android: androidSettings);
//
//     await flutterLocalNotificationsPlugin.initialize(initializationSettings);
//
//     // Check and request permission for notifications
//     await _checkAndRequestPermission();
//   }
//
//   // Check and request notification permission
//   Future<void> _checkAndRequestPermission() async {
//     // Check if the notification permission is granted
//     PermissionStatus status = await Permission.notification.status;
//
//     // If not granted, request permission
//     if (!status.isGranted) {
//       await _requestNotificationPermission();
//     }
//   }
//
//   // Request notification permission
//   Future<void> _requestNotificationPermission() async {
//     final PermissionStatus status = await Permission.notification.request();
//
//     if (status.isGranted) {
//       print("Notification permission granted.");
//     } else {
//       print("Notification permission denied.");
//     }
//   }
//
//   // This method now accepts BuildContext as a parameter
//   Future<void> initializeSocket(BuildContext context) async {
//     try {
//       // Fetch the user ID from SharedPreferences
//       String? userId = await _userIdStorage.getUserId();
//       if (userId != null) {
//         print('User ID fetched: $userId'); // Debugging log for userId
//
//         // URL with userId as a query parameter
//         final socketUrl = '${ApiEndPoint.socketUrl}?userId=$userId';
//
//         socket = IO.io(
//           socketUrl,  // Use URL with userId as query parameter
//           IO.OptionBuilder()
//               .setTransports(['websocket']) // Use WebSocket as transport
//               .disableAutoConnect() // Disable auto-connect to manage it manually
//               .build(),
//         );
//
//         // Connect to the server
//         socket.connect();
//
//         // Debugging: Check if socket is connecting
//         socket.onConnect((_) {
//           print('Connected to socket server');
//           socket.emit('sendNotification', {
//             'userId': userId,  // Use userId from SharedPreferences
//             'message': 'this is a test message',
//           });
//         });
//
//         // Debugging: If connection fails, catch it
//         socket.onError((error) {
//           print('Socket connection error: $error');
//         });
//
//         // Debugging: Listen for connection errors or disconnections
//         socket.onDisconnect((_) {
//           print('Disconnected from socket server');
//         });
//
//         // Listen for notifications
//         socket.on('receiveNotification', (data) {
//           print('Received notification: $data');
//
//           // Show the notification
//           _showNotification(data.toString());
//         });
//
//         // Additional debug: Check socket status
//         socket.on('connect_error', (error) {
//           print('Socket connection error: $error');
//         });
//       } else {
//         print("User ID is not available.");
//       }
//     } catch (e) {
//       print('Error while initializing socket: $e');
//     }
//   }
//
//   // Show the local notification
//   Future<void> _showNotification(String message) async {
//     const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
//       'default_channel',
//       'Default Notifications',
//       importance: Importance.high,
//       priority: Priority.high,
//       ticker: 'ticker',
//     );
//     const NotificationDetails platformDetails = NotificationDetails(android: androidDetails);
//
//     await flutterLocalNotificationsPlugin.show(
//       0,
//       'New Notification',
//       message,
//       platformDetails,
//     );
//   }
// }



// import 'package:clotique/cors/constant/api_end_point.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:socket_io_client/socket_io_client.dart' as IO;
// import 'package:flutter/material.dart';
// import 'user_id_storage.dart';
//
// class PushNotificationService {
//   late IO.Socket socket;
//   final UserIdStorage _userIdStorage = UserIdStorage();
//
//   // This method now accepts BuildContext as a parameter
//   Future<void> initializeSocket(BuildContext context) async {
//     try {
//       // Fetch the user ID from SharedPreferences
//       String? userId = await _userIdStorage.getUserId();
//       if (userId != null) {
//         print('User ID fetched: $userId'); // Debugging log for userId
//
//         // URL with userId as a query parameter
//         final socketUrl = '${ApiEndPoint.socketUrl}?userId=$userId';
//
//         socket = IO.io(
//           socketUrl,  // Use URL with userId as query parameter
//           IO.OptionBuilder()
//               .setTransports(['websocket']) // Use WebSocket as transport
//               .disableAutoConnect() // Disable auto-connect to manage it manually
//               .build(),
//         );
//
//         // Connect to the server
//         socket.connect();
//
//         // Debugging: Check if socket is connecting
//         socket.onConnect((_) {
//           print('Connected to socket server');
//           socket.emit('sendNotification', {
//             'userId': userId,  // Use userId from SharedPreferences
//             'message': 'this is a test message',
//           });
//         });
//
//         // Debugging: If connection fails, catch it
//         socket.onError((error) {
//           print('Socket connection error: $error');
//         });
//
//         // Debugging: Listen for connection errors or disconnections
//         socket.onDisconnect((_) {
//           print('Disconnected from socket server');
//         });
//
//         // Listen for notifications
//         socket.on('receiveNotification', (data) {
//           print('Received notification: $data');
//
//           Fluttertoast.showToast(
//             msg: data.toString(),
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//           );
//
//           // Handle the notification
//         //  _showNotification(context, data);
//         });
//
//         // Additional debug: Check socket status
//         socket.on('connect_error', (error) {
//           print('Socket connection error: $error');
//         });
//       } else {
//         print("User ID is not available.");
//       }
//     } catch (e) {
//       print('Error while initializing socket: $e');
//     }
//   }
// }